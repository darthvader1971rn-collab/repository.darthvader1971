# -*- coding: utf-8 -*-
import xbmc
import time

class CatchupTimeline:
    """
    Moduł zarządzający osią czasu dla materiałów archiwalnych (Catchup).
    Odpowiada za mapowanie danych EPG na odpowiednie przesunięcia czasowe.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł CatchupTimeline", xbmc.LOGINFO)

    def get_program_offset(self, start_time_unix):
        """
        Oblicza przesunięcie czasowe dla audycji względem obecnego czasu.
        
        :param start_time_unix: Czas rozpoczęcia programu z EPG (UNIX timestamp)
        :return: Przesunięcie w sekundach (wartość ujemna oznaczająca przeszłość)
        """
        current_time = int(time.time())
        offset = start_time_unix - current_time
        
        xbmc.log(f"[IPTV3] CatchupTimeline: Obliczono offset dla archiwum: {offset} sekund", xbmc.LOGDEBUG)
        return offset

    def is_within_catchup_window(self, start_time_unix, max_days):
        """
        Sprawdza, czy żądany program mieści się w dozwolonym oknie czasowym archiwum providera.
        
        :param start_time_unix: Czas rozpoczęcia programu z EPG
        :param max_days: Maksymalna liczba dni wstecz zdefiniowana w ustawieniach (settings.xml)
        :return: True jeśli program jest wciąż dostępny, False jeśli jest za stary
        """
        current_time = int(time.time())
        max_seconds_back = max_days * 24 * 60 * 60
        oldest_allowed_time = current_time - max_seconds_back
        
        if start_time_unix >= oldest_allowed_time:
            return True
        else:
            xbmc.log("[IPTV3] CatchupTimeline: Audycja poza oknem archiwum (zbyt stara).", xbmc.LOGWARNING)
            return False