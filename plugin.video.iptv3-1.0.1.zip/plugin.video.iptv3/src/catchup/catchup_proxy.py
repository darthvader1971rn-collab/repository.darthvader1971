# -*- coding: utf-8 -*-
import http.server
import socketserver
import urllib.parse
import threading
import xbmc
import time
import requests

# Wyłączenie ostrzeżeń o braku weryfikacji SSL w bibliotece requests
requests.packages.urllib3.disable_warnings()

PROXY_PORT = 8282

def log(msg):
    xbmc.log(f"[IPTV3 - CatchupProxy] {msg}", xbmc.LOGINFO)

def resolve_url(base, target):
    """Buduje poprawne linki absolutne dla list M3U8"""
    if target.startswith("http"):
        return target
    parsed_base = urllib.parse.urlparse(base)
    if target.startswith("/"):
        return f"{parsed_base.scheme}://{parsed_base.netloc}{target}"
    return f"{base.rsplit('/', 1)[0]}/{target}"

def get_media_playlist(url, headers):
    """
    Uderza pod podany URL. Jeśli napotka Master Playlist, 
    odnajduje w niej Media Playlist i rekursywnie podąża za nią.
    """
    try:
        resp = requests.get(url, headers=headers, verify=False, timeout=15)
        if resp.status_code != 200:
            log(f"Błąd HTTP {resp.status_code} dla: {url}")
            return None, None
        
        content = resp.text
        if "#EXT-X-STREAM-INF" in content:
            lines = content.splitlines()
            for i, line in enumerate(lines):
                if line.startswith("#EXT-X-STREAM-INF"):
                    for j in range(i+1, len(lines)):
                        if lines[j].strip() and not lines[j].startswith("#"):
                            sub_url = resolve_url(url, lines[j].strip())
                            return get_media_playlist(sub_url, headers)
        return content, url
    except Exception as e:
        log(f"Wyjątek podczas pobierania {url}: {e}")
        return None, None

class CatchupHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass # Wyciszamy systemowy spam w logach

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed_path.query)

        # Domyślny nagłówek
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

        # -----------------------------------------------------
        # TRASA 1: ZWROT SKLEJONEJ PLAYLISTY
        # -----------------------------------------------------
        if parsed_path.path == '/catchup.m3u8':
            base_url = params.get('url', [''])[0]
            start_utc = int(params.get('start', ['0'])[0])
            end_utc = int(params.get('end', ['0'])[0])

            if not base_url or start_utc == 0:
                self.send_response(400)
                self.end_headers()
                return

            if end_utc == 0:
                end_utc = start_utc + 10800

            actual_end_ts = min(end_utc, int(time.time()))
            interval = 3600
            current_utc = start_utc

            # Wyciągamy czysty URL i ew. ukryte nagłówki (np. |User-Agent=...)
            clean_url = base_url
            if '|' in base_url:
                parts = base_url.split('|', 1)
                clean_url = parts[0]
                for h in parts[1].split('&'):
                    if '=' in h:
                        k, v = h.split('=', 1)
                        headers[k] = urllib.parse.unquote(v)

            connector = "&" if "?" in clean_url else "?"

            master_playlist = [
                "#EXTM3U",
                "#EXT-X-VERSION:3",
                "#EXT-X-TARGETDURATION:12",
                "#EXT-X-MEDIA-SEQUENCE:0",
                "#EXT-X-PLAYLIST-TYPE:VOD"
            ]

            total_segments = 0

            # Sklejanie poszczególnych godzin (bloków)
            while current_utc < actual_end_ts:
                block_end = min(current_utc + interval, actual_end_ts)
                
                # UWAGA: Dodajemy parametry UTC do GŁÓWNEGO linku (brak błędu 404)
                block_url = f"{clean_url}{connector}utc={current_utc}&lutc={block_end}"
                
                content, final_url = get_media_playlist(block_url, headers)
                
                if content and final_url:
                    lines = content.splitlines()
                    segments_in_block = 0
                    
                    for line in lines:
                        line = line.strip()
                        if not line: continue
                            
                        # Obsługa kluczy szyfrujących Otopay
                        if line.startswith("#EXT-X-KEY"):
                            if 'URI="' in line:
                                parts = line.split('URI="')
                                uri_part = parts[1].split('"')[0]
                                abs_uri = resolve_url(final_url, uri_part)
                                enc_uri = urllib.parse.quote_plus(abs_uri)
                                proxy_key_url = f"http://127.0.0.1:{PROXY_PORT}/key?url={enc_uri}"
                                line = line.replace(f'URI="{uri_part}"', f'URI="{proxy_key_url}"')
                            master_playlist.append(line)
                            
                        elif line.startswith("#EXTINF") or line.startswith("#EXT-X-DISCONTINUITY"):
                            master_playlist.append(line)
                            
                        elif line.startswith("#"):
                            continue
                            
                        else:
                            # Przechwytujemy ścieżki plików .ts na adres naszego Proxy
                            abs_seg = resolve_url(final_url, line)
                            encoded_seg = urllib.parse.quote_plus(abs_seg)
                            local_seg_url = f"http://127.0.0.1:{PROXY_PORT}/segment?url={encoded_seg}"
                            master_playlist.append(local_seg_url)
                            segments_in_block += 1
                            total_segments += 1
                            
                    # Wstawiamy znacznik przejścia, żeby odtwarzacz nie zgłupiał przy sklejce
                    if segments_in_block > 0:
                        master_playlist.append("#EXT-X-DISCONTINUITY")
                
                current_utc += interval
            
            master_playlist.append("#EXT-X-ENDLIST")
            final_m3u8 = "\n".join(master_playlist)

            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            self.wfile.write(final_m3u8.encode('utf-8'))
            log(f"Sklejono playlistę (segmenty: {total_segments}).")

        # -----------------------------------------------------
        # TRASA 2: POBIERANIE WIDEO (.TS)
        # -----------------------------------------------------
        elif parsed_path.path == '/segment':
            seg_url = params.get('url', [''])[0]
            if not seg_url:
                self.send_response(400)
                self.end_headers()
                return

            try:
                resp = requests.get(seg_url, headers=headers, verify=False, stream=True, timeout=15)
                self.send_response(200)
                self.send_header('Content-Type', resp.headers.get('Content-Type', 'video/mp2t'))
                self.end_headers()
                
                # Strumieniowanie po 64KB (szybki transfer obrazu)
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        self.wfile.write(chunk)
            except Exception:
                pass # Ignoruj zgubione pakiety wideo

        # -----------------------------------------------------
        # TRASA 3: POBIERANIE KLUCZY SZYFRUJĄCYCH
        # -----------------------------------------------------
        elif parsed_path.path == '/key':
            key_url = params.get('url', [''])[0]
            if not key_url:
                self.send_response(400)
                self.end_headers()
                return

            try:
                resp = requests.get(key_url, headers=headers, verify=False, timeout=10)
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.end_headers()
                self.wfile.write(resp.content)
            except Exception:
                self.send_response(500)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

class CatchupProxy:
    def __init__(self):
        self.server = None
        self.thread = None

    def start(self):
        try:
            socketserver.TCPServer.allow_reuse_address = True
            self.server = socketserver.TCPServer(("127.0.0.1", PROXY_PORT), CatchupHandler)
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
            log(f"Wystartował na http://127.0.0.1:{PROXY_PORT}")
        except Exception as e:
            log(f"Błąd uruchamiania: {e}")

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            log("Zatrzymany.")

    def get_proxy_url(self, base_url, start_ts, end_ts):
        encoded_url = urllib.parse.quote_plus(base_url)
        return f"http://127.0.0.1:{PROXY_PORT}/catchup.m3u8?url={encoded_url}&start={start_ts}&end={end_ts}"