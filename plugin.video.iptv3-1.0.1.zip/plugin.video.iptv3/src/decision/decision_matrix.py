# -*- coding: utf-8 -*-

class DecisionMatrix:
    """
    Macierz decyzyjna (Decision Matrix).
    Definiuje progi jakościowe i techniczne reguły wyboru strumieni.
    """
    
    QUALITY_RULES = {
        '4K': {'min_speed_mbps': 25, 'priority': 1},
        'HD': {'min_speed_mbps': 8, 'priority': 2},
        'SD': {'min_speed_mbps': 2, 'priority': 3}
    }

    PROTOCOL_PRIORITY = ['dash', 'hls', 'ts']

    @classmethod
    def get_rule_for_quality(cls, quality_label):
        """Zwraca parametry techniczne dla danego poziomu jakości."""
        return cls.QUALITY_RULES.get(quality_label, cls.QUALITY_RULES['HD'])