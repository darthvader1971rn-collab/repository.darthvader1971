# -*- coding: utf-8 -*-
import xbmc

class PathSelector:
    """
    Selektor ścieżki (Path Selector).
    Określa, który protokół (HLS, DASH, TS) i który silnik renderujący
    będzie najstabilniejszy dla danej treści.
    """
    
    def __init__(self):
        pass

    def select_protocol(self, url):
        """Analizuje URL i dobiera odpowiedni protokół odtwarzania."""
        if ".m3u8" in url:
            return "hls"
        elif ".mpd" in url:
            return "dash"
        return "ts"