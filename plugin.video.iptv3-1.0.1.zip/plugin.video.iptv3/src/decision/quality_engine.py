# -*- coding: utf-8 -*-
import xbmc
from src.utils.config_handler import ConfigHandler

class QualityEngine:
    """Silnik wyboru jakości obrazu."""
    
    def __init__(self):
        self.config = ConfigHandler()

    def get_preferred_quality(self):
        # Pobiera ustawienie z settings.xml
        return self.config.get_string('preferred_quality') or "HD"