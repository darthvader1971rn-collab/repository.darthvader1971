# -*- coding: utf-8 -*-
import xbmc
from src.decision.quality_engine import QualityEngine
from src.decision.load_balancer import LoadBalancer

class DecisionEngine:
    """
    Główny silnik decyzyjny.
    Analizuje warunki sieciowe i preferencje użytkownika, 
    aby dobrać najlepszy możliwy wariant strumienia.
    """
    
    def __init__(self):
        self.quality = QualityEngine()
        self.balancer = LoadBalancer()
        xbmc.log("[IPTV3] Zainicjowano DecisionEngine", xbmc.LOGINFO)

    def get_final_stream(self, stream_options):
        """
        Podejmuje decyzję o wyborze konkretnego linku do odtworzenia.
        :param stream_options: Lista dostępnych wariantów strumienia
        """
        # 1. Wybierz jakość
        preferred = self.quality.get_preferred_quality()
        # 2. Wybierz najlepszy serwer
        server = self.balancer.get_best_server()
        
        xbmc.log(f"[IPTV3] DecisionEngine: Wybrano profil {preferred} na serwerze {server}", xbmc.LOGINFO)
        return stream_options[0] # Uproszczony wybór pierwszego dostępnego