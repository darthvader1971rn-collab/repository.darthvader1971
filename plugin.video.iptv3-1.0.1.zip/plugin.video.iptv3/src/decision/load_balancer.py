# -*- coding: utf-8 -*-
import xbmc
import random

class LoadBalancer:
    """
    Moduł równoważenia obciążenia (Load Balancer).
    Wybiera optymalny serwer wejściowy z dostępnej puli dostawcy.
    """
    
    def __init__(self, server_list=None):
        self.servers = server_list or []
        xbmc.log("[IPTV3] Zainicjowano LoadBalancer", xbmc.LOGINFO)

    def get_best_server(self):
        """
        Zwraca najlepszy dostępny serwer. 
        W wersji podstawowej używa algorytmu Random/Round-Robin.
        """
        if not self.servers:
            return None
        
        # Prosta logika losowania, aby rozłożyć ruch
        chosen = random.choice(self.servers)
        xbmc.log(f"[IPTV3] LoadBalancer: Wybrano serwer: {chosen}", xbmc.LOGDEBUG)
        return chosen