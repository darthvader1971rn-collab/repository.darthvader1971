# -*- coding: utf-8 -*-
import xbmc
from src.storage.file_manager import FileManager
from src.storage.history_logger import HistoryLogger

class StorageEngine:
    """
    Główny silnik magazynu (Storage Engine).
    Jednolity punkt dostępu do wszystkich operacji zapisu i odczytu trwałych danych.
    """
    
    def __init__(self, db_engine):
        self.files = FileManager()
        self.history = HistoryLogger(db_engine)
        xbmc.log("[IPTV3] Silnik StorageEngine gotowy do pracy.", xbmc.LOGINFO)

    def cleanup_all(self):
        """Uruchamia procedury czyszczenia starych danych z cache i logów."""
        xbmc.log("[IPTV3] StorageEngine: Rozpoczęto sprzątanie zasobów...", xbmc.LOGDEBUG)
        # Logika usuwania plików starszych niż X dni