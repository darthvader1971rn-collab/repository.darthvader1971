# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import os

class RecordingStorage:
    """
    Menedżer zapisu nagrań (Recording Storage).
    Zarządza lokalizacją plików wideo i monitoruje dostępną przestrzeń dyskową.
    """
    
    def __init__(self):
        self.rec_path = xbmc.translatePath('special://profile/addon_data/plugin.video.iptv3/recordings/')
        if not xbmcvfs.exists(self.rec_path):
            xbmcvfs.mkdir(self.rec_path)

    def check_free_space(self):
        """Zwraca informację o wolnym miejscu na dysku (w MB)."""
        # Uproszczona implementacja statystyk systemowych
        return 1024 # Zwraca 1GB jako placeholder

    def get_new_recording_path(self, channel_name):
        """Generuje unikalną ścieżkę dla nowego pliku nagrania."""
        filename = f"{channel_name}_{int(xbmc.getInfoLabel('System.Time'))}.ts"
        return os.path.join(self.rec_path, filename)