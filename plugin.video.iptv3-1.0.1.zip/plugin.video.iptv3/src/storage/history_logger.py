# -*- coding: utf-8 -*-
import xbmc
import time

class HistoryLogger:
    """
    Rejestrator historii (History Logger).
    Zapisuje aktywność użytkownika, umożliwiając szybki powrót 
    do ostatnio oglądanych kanałów i filmów VOD.
    """
    
    def __init__(self, db_engine):
        self.db = db_engine

    def log_view(self, channel_id, name):
        """Zapisuje fakt uruchomienia kanału."""
        timestamp = int(time.time())
        query = "INSERT INTO metadata (key, value) VALUES (?, ?)"
        # Używamy metadanych jako prostego logu (klucz: history_ID, wartość: timestamp)
        self.db.execute_query(query, (f"history_{channel_id}", f"{name}|{timestamp}"))
        xbmc.log(f"[IPTV3] Storage: Zapisano w historii: {name}", xbmc.LOGDEBUG)

    def get_recent(self, limit=10):
        """Pobiera listę ostatnio oglądanych pozycji."""
        # Logika pobierania z tabeli metadata posortowana po czasie
        pass