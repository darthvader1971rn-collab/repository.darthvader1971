# -*- coding: utf-8 -*-
import xbmc

class CatchupStorage:
    """
    Magazyn danych Catchup (Archiwum TV).
    Zarządza informacjami o dostępności audycji archiwalnych 
    i przechowuje punkty wstrzymania odtwarzania.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano CatchupStorage", xbmc.LOGINFO)

    def save_resume_point(self, program_id, seconds):
        """Zapisuje moment, w którym przerwano oglądanie audycji z archiwum."""
        xbmc.log(f"[IPTV3] Catchup: Zapisano punkt {seconds}s dla audycji {program_id}", xbmc.LOGDEBUG)

    def get_resume_point(self, program_id):
        """Zwraca czas w sekundach, od którego należy wznowić program."""
        return 0