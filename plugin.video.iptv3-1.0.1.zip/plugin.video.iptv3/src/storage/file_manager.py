# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import os

class FileManager:
    """
    Menedżer plików (File Manager).
    Zarządza strukturą katalogów wtyczki i dba o porządek w systemie plików.
    """
    
    def __init__(self):
        self.addon_path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.iptv3/')
        self._ensure_dirs()

    def _ensure_dirs(self):
        """Tworzy niezbędne foldery, jeśli nie istnieją."""
        dirs = ['backups', 'logs', 'playlists']
        for d in dirs:
            path = os.path.join(self.addon_path, d)
            if not xbmcvfs.exists(path):
                xbmcvfs.mkdir(path)

    def write_file(self, filename, content):
        """Zapisuje tekst do pliku w folderze wtyczki."""
        path = os.path.join(self.addon_path, filename)
        with xbmcvfs.File(path, 'w') as f:
            return f.write(content)

    def get_file_size(self, filename):
        """Zwraca rozmiar pliku w bajtach."""
        path = os.path.join(self.addon_path, filename)
        stat = xbmcvfs.Stat(path)
        return stat.st_size() if xbmcvfs.exists(path) else 0