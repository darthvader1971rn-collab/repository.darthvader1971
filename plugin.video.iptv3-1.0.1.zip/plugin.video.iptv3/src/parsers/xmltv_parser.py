# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import xbmc
import gzip
import lzma

from src.utils.time_utils import TimeUtils


class XmltvParser:
    """
    Parser danych EPG (XMLTV Parser).
    Obsługuje formaty: XML, XML.GZ, XML.XZ.
    Zwraca:
        {
            "channels": { display-name.lower(): channel_id },
            "programs": [ ... ]
        }
    """

    def __init__(self):
        self.time_utils = TimeUtils()
        xbmc.log("[IPTV3] Zainicjowano moduł XmltvParser", xbmc.LOGINFO)

    # ---------------------------------------------------------
    # ROZPOZNANIE I ROZPAKOWANIE FORMATU
    # ---------------------------------------------------------
    def _decode_epg_bytes(self, raw_bytes):
        """
        Rozpoznaje format EPG i zwraca czysty XML jako string.
        Obsługuje: XML, GZ, XZ.
        """
        if not raw_bytes:
            xbmc.log("[IPTV3] XmltvParser: Brak danych wejściowych.", xbmc.LOGERROR)
            return None

        # 1) GZIP
        if raw_bytes[:2] == b"\x1f\x8b":
            xbmc.log("[IPTV3] XmltvParser: Wykryto format GZIP.", xbmc.LOGINFO)
            try:
                return gzip.decompress(raw_bytes).decode("utf-8", errors="ignore")
            except Exception as e:
                xbmc.log(f"[IPTV3] XmltvParser: Błąd dekompresji GZ: {e}", xbmc.LOGERROR)
                return None

        # 2) XZ
        if raw_bytes[:6] in (b"\xfd7zXZ\x00", b"\xfd\x37\x7a\x58\x5a\x00"):
            xbmc.log("[IPTV3] XmltvParser: Wykryto format XZ.", xbmc.LOGINFO)
            try:
                return lzma.decompress(raw_bytes).decode("utf-8", errors="ignore")
            except Exception as e:
                xbmc.log(f"[IPTV3] XmltvParser: Błąd dekompresji XZ: {e}", xbmc.LOGERROR)
                return None

        # 3) Zwykły XML
        xbmc.log("[IPTV3] XmltvParser: Wykryto czysty XML.", xbmc.LOGINFO)
        try:
            return raw_bytes.decode("utf-8", errors="ignore")
        except Exception as e:
            xbmc.log(f"[IPTV3] XmltvParser: Błąd dekodowania XML: {e}", xbmc.LOGERROR)
            return None

    # ---------------------------------------------------------
    # PARSOWANIE XMLTV
    # ---------------------------------------------------------
    def parse(self, raw_bytes, cutoff_time=0):
        """
        Parsuje treść XMLTV i wyodrębnia kanały oraz programy.
        Filtruje audycje archiwalne starsze niż cutoff_time.
        """
        if not raw_bytes:
            return None

        # --- NAPRAWA: Rozpakowanie i dekodowanie GZIP/XZ przed parsowaniem ---
        xml_content = self._decode_epg_bytes(raw_bytes)
        if not xml_content:
            xbmc.log("[IPTV3] XmltvParser: Dekodowanie EPG zwróciło pusty wynik.", xbmc.LOGERROR)
            return None

        try:
            root = ET.fromstring(xml_content)
            result = {"channels": {}, "programs": []}
            
            # 1. Mapowanie kanałów
            for chan in root.findall('channel'):
                c_id = chan.get('id')
                disp_node = chan.find('display-name')
                if c_id and disp_node is not None:
                    result["channels"][disp_node.text.lower()] = c_id

            # 2. Parsowanie programów z filtrowaniem
            programs = []
            skipped_count = 0
            
            for prog in root.findall('programme'):
                channel_id = prog.get('channel')
                start_raw = prog.get('start')
                stop_raw = prog.get('stop')

                if not channel_id or not start_raw or not stop_raw:
                    continue

                stop_unix = self.time_utils.xmltv_to_unix(stop_raw)

                # DYNAMICZNE FILTROWANIE ARCHIWUM
                if cutoff_time > 0 and stop_unix < cutoff_time:
                    skipped_count += 1
                    continue

                start_unix = self.time_utils.xmltv_to_unix(start_raw)
                title_node = prog.find('title')
                desc_node = prog.find('desc')
                icon_node = prog.find('icon')

                title = title_node.text if title_node is not None and title_node.text else "Brak tytułu"
                description = desc_node.text if desc_node is not None and desc_node.text else ""
                image_url = icon_node.get('src') if icon_node is not None else ""

                programs.append({
                    'channel_id': channel_id,
                    'title': title,
                    'description': description,
                    'start_time': start_unix,
                    'end_time': stop_unix,
                    'image': image_url
                })

            result["programs"] = programs
            xbmc.log(f"[IPTV3] XmltvParser: Przetworzono {len(programs)} wpisów (odfiltrowano {skipped_count} archiwalnych).", xbmc.LOGINFO)
            return result

        except Exception as e:
            xbmc.log(f"[IPTV3] XmltvParser: Krytyczny błąd parsowania XML: {e}", xbmc.LOGERROR)
            return None