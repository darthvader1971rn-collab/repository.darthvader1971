# -*- coding: utf-8 -*-
import xbmc
import re

class MetadataEngine:
    """
    Silnik metadanych (Metadata Engine).
    Odpowiada za wzbogacanie informacji o audycjach i kanałach 
    o dodatkowe grafiki, opisy i oceny.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł MetadataEngine", xbmc.LOGINFO)

    def enrich_program_info(self, program_data):
        """
        Analizuje dane programu i próbuje przypisać im dodatkowe tagi.
        
        :param program_data: Słownik z danymi audycji z XmltvParser
        :return: Wzbogacony słownik danych
        """
        title = program_data.get('title', '')
        
        # Prosta logika wykrywania filmów na podstawie słów kluczowych
        movie_keywords = ['film', 'premiera', 'kino', 'thriller', 'komedia']
        if any(word in title.lower() for word in movie_keywords):
            program_data['type'] = 'movie'
            # Tutaj w przyszłości można dodać wywołanie API zewnętrznego (np. TMDB)
        else:
            program_data['type'] = 'broadcast'

        return program_data

    def get_thumbnail_for_channel(self, channel_name):
        """
        Próbuje dopasować ikonę kanału, jeśli dostawca jej nie dostarczył.
        Wykorzystuje lokalną bazę piconów lub zasoby systemowe.
        """
        # Placeholder dla logiki dopasowywania ikon
        return None

    def clean_title(self, raw_title):
        """
        Oczyszcza tytuł z niepotrzebnych znaczników (np. [HD], (N), (S1E02)).
        Pomaga w lepszym dopasowaniu metadanych z baz zewnętrznych.
        """
        clean = re.sub(r'\[.*?\]|\(.*?\)', '', raw_title)
        return clean.strip()