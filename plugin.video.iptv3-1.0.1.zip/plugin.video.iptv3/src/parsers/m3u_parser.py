# -*- coding: utf-8 -*-
import re
import os
import urllib.request
import xbmc

class M3uParser:
    """
    Parser list odtwarzania M3U (M3U Parser).
    Obsługuje:
        - URL (http/https)
        - pliki lokalne
    Wyodrębnia metadane kanałów z surowych plików M3U.
    """

    def __init__(self):
        # Regex do wyciągania atrybutów z linii #EXTINF
        self.attr_regex = re.compile(r'([a-z-]+)="([^"]*)"', re.IGNORECASE)

        # Regex do wyciągania url-tvg z nagłówka
        self.epg_regex = re.compile(r'url-tvg="([^"]+)"', re.IGNORECASE)

        xbmc.log("[IPTV3] Zainicjowano moduł M3uParser", xbmc.LOGINFO)

    # ---------------------------------------------------------
    # WCZYTYWANIE ŹRÓDŁA (URL lub PLIK)
    # ---------------------------------------------------------
    def load_source(self, source):
        """
        Wczytuje M3U z URL lub z pliku lokalnego.
        Zwraca zawartość jako string UTF-8.
        """

        try:
            # --- URL ---
            if source.startswith("http://") or source.startswith("https://"):
                xbmc.log(f"[IPTV3] Pobieranie M3U z URL: {source}", xbmc.LOGINFO)
                req = urllib.request.Request(source, headers={"User-Agent": "Mozilla/5.0"})
                raw = urllib.request.urlopen(req, timeout=10).read()  # bytes
                return raw.decode("utf-8", errors="ignore")

            # --- PLIK LOKALNY ---
            if os.path.exists(source):
                xbmc.log(f"[IPTV3] Wczytywanie M3U z pliku: {source}", xbmc.LOGINFO)
                with open(source, "r", encoding="utf-8", errors="ignore") as f:
                    return f.read()

            xbmc.log(f"[IPTV3] Nie znaleziono źródła M3U: {source}", xbmc.LOGERROR)
            return ""

        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd wczytywania M3U: {e}", xbmc.LOGERROR)
            return ""

    # ---------------------------------------------------------
    # WYCIĄGANIE URL EPG
    # ---------------------------------------------------------
    def extract_epg_url(self, content):
        """
        Wyciąga URL EPG z nagłówka M3U (#EXTM3U ...)
        """
        if not content:
            return None

        first_line = content.split("\n", 1)[0]

        match = self.epg_regex.search(first_line)
        if match:
            epg_url = match.group(1)
            xbmc.log(f"[IPTV3] Wykryto URL EPG: {epg_url}", xbmc.LOGINFO)
            return epg_url

        xbmc.log("[IPTV3] Brak url-tvg w nagłówku M3U", xbmc.LOGWARNING)
        return None

    # ---------------------------------------------------------
    # PARSOWANIE M3U
    # ---------------------------------------------------------
    def parse(self, content):
        """
        Parsuje treść pliku M3U i zwraca listę słowników z danymi kanałów.
        """
        channels = []
        if not content:
            return channels

        # Wyciągamy URL EPG
        self.epg_url = self.extract_epg_url(content)

        lines = content.splitlines()
        current_channel = {}

        for line in lines:
            line = line.strip()

            if line.startswith('#EXTINF:'):
                # Wyciągamy nazwę kanału (tekst po ostatnim przecinku)
                name = line.split(',')[-1].strip()
                current_channel = {'name': name}

                # Wyciągamy atrybuty (tvg-id, tvg-name, tvg-logo, group-title, timeshift)
                attrs = self.attr_regex.findall(line)
                for key, value in attrs:

                    if key == 'tvg-id':
                        current_channel['tvg_id'] = value

                    elif key == 'tvg-name':
                        current_channel['tvg_name'] = value

                    elif key == 'tvg-logo':
                        current_channel['logo_url'] = value

                    elif key == 'group-title':
                        current_channel['group_name'] = value
                        
                    # --- NOWOŚĆ: WYCIĄGANIE TIMESHIFT ---
                    elif key == 'timeshift':
                        try:
                            current_channel['timeshift'] = int(value)
                        except ValueError:
                            current_channel['timeshift'] = 0

            elif line.startswith('http') or line.startswith('rtmp'):
                if current_channel:
                    current_channel['stream_url'] = line

                    # --- LOGIKA NADAWANIA ID KANAŁU ---
                    if 'tvg_id' in current_channel and current_channel['tvg_id']:
                        # Najlepszy przypadek — lista ma tvg-id
                        current_channel['channel_id'] = current_channel['tvg_id']

                    elif 'tvg_name' in current_channel and current_channel['tvg_name']:
                        # Lista nie ma tvg-id, ale ma tvg-name → używamy go
                        current_channel['channel_id'] = current_channel['tvg_name']

                    else:
                        # Ostateczny fallback
                        current_channel['channel_id'] = current_channel['name'].replace(" ", "_")

                    channels.append(current_channel)
                    current_channel = {}

        xbmc.log(f"[IPTV3] M3uParser: Przetworzono {len(channels)} kanałów.", xbmc.LOGINFO)
        return channels