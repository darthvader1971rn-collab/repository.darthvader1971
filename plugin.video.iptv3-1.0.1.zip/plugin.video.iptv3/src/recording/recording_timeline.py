# -*- coding: utf-8 -*-
import xbmc
import time

class RecordingTimeline:
    """
    Moduł zarządzający osią czasu dla nagrań (Recording Timeline).
    Odpowiada za harmonogramowanie zapisu, pilnowanie czasu trwania
    oraz synchronizację z danymi EPG.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł RecordingTimeline", xbmc.LOGINFO)

    def calculate_duration(self, start_time_unix, end_time_unix):
        """
        Oblicza wymagany czas nagrywania na podstawie przedziału EPG.
        
        :param start_time_unix: Czas rozpoczęcia audycji (UNIX)
        :param end_time_unix: Czas zakończenia audycji (UNIX)
        :return: Czas trwania w sekundach
        """
        duration = end_time_unix - start_time_unix
        xbmc.log(f"[IPTV3] RecordingTimeline: Obliczono czas trwania nagrania: {duration} sekund", xbmc.LOGDEBUG)
        return duration if duration > 0 else 0

    def get_remaining_time(self, end_time_unix):
        """
        Sprawdza, ile czasu pozostało do końca zaplanowanego nagrania.
        
        :param end_time_unix: Zaplanowany czas zakończenia
        :return: Pozostały czas w sekundach
        """
        current_time = int(time.time())
        remaining = end_time_unix - current_time
        return remaining if remaining > 0 else 0

    def is_time_to_stop(self, end_time_unix, margin_seconds=300):
        """
        Weryfikuje, czy nagrywanie powinno zostać zakończone, uwzględniając margines na opóźnienia.
        
        :param end_time_unix: Teoretyczny czas zakończenia z EPG
        :param margin_seconds: Dodatkowy margines czasu (domyślnie 5 minut) zapobiegający ucięciu końcówki
        :return: True, jeśli nagranie powinno się zakończyć
        """
        current_time = int(time.time())
        # Dodajemy margines do czasu zakończenia
        actual_end_time = end_time_unix + margin_seconds
        
        if current_time >= actual_end_time:
            xbmc.log("[IPTV3] RecordingTimeline: Osiągnięto czas zakończenia nagrania (z uwzględnieniem marginesu).", xbmc.LOGINFO)
            return True
            
        return False