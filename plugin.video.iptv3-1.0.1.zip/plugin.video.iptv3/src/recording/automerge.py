# -*- coding: utf-8 -*-
import xbmc
import os

class AutoMerge:
    """
    Moduł odpowiedzialny za automatyczne łączenie podzielonych plików wideo (AutoMerge).
    Scalania mniejsze fragmenty (.ts) w jeden plik wyjściowy po zakończeniu nagrywania.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł AutoMerge", xbmc.LOGINFO)

    def merge_files(self, file_list, output_path):
        """
        Łączy listę plików wideo w jeden plik wynikowy.
        
        :param file_list: Lista ścieżek do plików składowych (np. ['part1.ts', 'part2.ts'])
        :param output_path: Ścieżka docelowa dla połączonego pliku (np. 'caly_film.ts')
        :return: True, jeśli łączenie zakończyło się sukcesem, w przeciwnym razie False
        """
        if not file_list:
            xbmc.log("[IPTV3] AutoMerge: Pusta lista plików do połączenia.", xbmc.LOGWARNING)
            return False
            
        xbmc.log(f"[IPTV3] AutoMerge: Rozpoczynam łączenie {len(file_list)} plików do {output_path}", xbmc.LOGINFO)
        
        # Docelowo znajdzie się tutaj mechanizm łączący pliki binarne (.ts) 
        # lub wywołanie procesu zewnętrznego (np. FFmpeg).
        # W przypadku standardowych plików MPEG-TS wystarczy często dopisywanie bajtów.
        
        try:
            # Szkielet łączenia binarnego
            pass
            
            xbmc.log("[IPTV3] AutoMerge: Łączenie plików zakończone pomyślnie.", xbmc.LOGINFO)
            return True
            
        except Exception as e:
            xbmc.log(f"[IPTV3] AutoMerge: Błąd podczas łączenia plików: {e}", xbmc.LOGERROR)
            return False

    def cleanup_parts(self, file_list):
        """
        Usuwa pliki składowe po pomyślnym połączeniu.
        """
        for file_path in file_list:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                xbmc.log(f"[IPTV3] AutoMerge: Nie udało się usunąć pliku {file_path}: {e}", xbmc.LOGWARNING)