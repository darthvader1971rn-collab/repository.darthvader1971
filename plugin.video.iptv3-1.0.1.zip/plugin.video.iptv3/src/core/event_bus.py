# -*- coding: utf-8 -*-
import xbmc

class EventBus:
    """
    Szyna Zdarzeń (Event Bus).
    Centralny punkt komunikacji asynchronicznej między modułami.
    Pozwala na nadawanie i odbieranie sygnałów systemowych bez ścisłego powiązania kodu.
    """
    
    _instance = None
    _subscribers = {}

    def __new__(cls):
        """Singleton: Zapewnia, że w całej wtyczce istnieje tylko jedna szyna zdarzeń."""
        if cls._instance is None:
            cls._instance = super(EventBus, cls).__new__(cls)
            xbmc.log("[IPTV3] Zainicjowano centralną szynę zdarzeń (EventBus).", xbmc.LOGINFO)
        return cls._instance

    def subscribe(self, event_type, callback):
        """
        Rejestruje funkcję, która ma zostać wywołana po wystąpieniu zdarzenia.
        
        :param event_type: Nazwa zdarzenia (np. 'player_started')
        :param callback: Funkcja do wywołania
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)
        xbmc.log(f"[IPTV3] EventBus: Nowy subskrybent dla zdarzenia: {event_type}", xbmc.LOGDEBUG)

    def emit(self, event_type, data=None):
        """
        Rozsyła informację o zdarzeniu do wszystkich zainteresowanych modułów.
        
        :param event_type: Nazwa zdarzenia
        :param data: Opcjonalne dane przesyłane wraz ze zdarzeniem
        """
        if event_type in self._subscribers:
            for callback in self._subscribers[event_type]:
                try:
                    callback(data)
                except Exception as e:
                    xbmc.log(f"[IPTV3] EventBus ERROR: Błąd podczas obsługi {event_type}: {str(e)}", xbmc.LOGERROR)
        
        xbmc.log(f"[IPTV3] EventBus: Wyemitowano zdarzenie {event_type}", xbmc.LOGDEBUG)

    def clear_all(self):
        """Resetuje wszystkie powiązania (używane przy zamykaniu wtyczki)."""
        self._subscribers = {}
        xbmc.log("[IPTV3] EventBus: Wyszczyszczono listę subskrypcji.", xbmc.LOGINFO)