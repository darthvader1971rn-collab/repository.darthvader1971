# -*- coding: utf-8 -*-
import os
import time
import threading
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import urllib.parse

from api.auth_manager import AuthManager
from parsers.m3u_parser import M3uParser
from parsers.xmltv_parser import XmltvParser
from database.db_engine import DbEngine
from player.player_engine import PlayerEngine
from utils.config_handler import ConfigHandler


# Na samej górze pliku, pod resztą importów z 'parsers' dodaj:
from api.tmdb_scraper import TmdbScraper

class MainEngine:
    """
    Silnik Główny IPTV 3.0
    """

    def __init__(self):
        xbmc.log("[IPTV3] MainEngine: Rozpoczynam pełną inicjalizację komponentów...", xbmc.LOGINFO)

        addon = xbmcaddon.Addon()
        addon_id = addon.getAddonInfo('id')

        # Wyznaczanie ścieżki profilu użytkownika
        profile_path = xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}")
        if not os.path.exists(profile_path):
            try:
                os.makedirs(profile_path)
                xbmc.log(f"[IPTV3] Utworzono folder danych: {profile_path}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[IPTV3] Krytyczny błąd folderu: {e}", xbmc.LOGERROR)

        self.profile_path = profile_path
        self.db_path = os.path.join(profile_path, "iptv3.db")

        # Inicjalizacja modułów
        try:
            self.config = ConfigHandler()
            self.auth = AuthManager()
            self.db = DbEngine(self.db_path)
            self.player = PlayerEngine()
            self.m3u_parser = M3uParser()
            self.xmltv = XmltvParser()
            
            from epg.epg_engine import EpgEngine
            self.epg = EpgEngine(self.profile_path)
            
            # --- NOWOŚĆ: Inicjalizacja Scrapera TMDb ---
            self.tmdb = TmdbScraper(self.profile_path)
            
            xbmc.log("[IPTV3] Moduły pomocnicze zainicjalizowane.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd ładowania modułów: {e}", xbmc.LOGERROR)
            raise

        # Wczytywanie kluczowych ustawień
        self.m3u_url = self.config.get_string("provider_m3u_url")
        self.epg_url_1 = self.config.get_string("epg_url_1")
        self.epg_url_2 = self.config.get_string("epg_url_2")
        
        # USER-AGENT
        self.user_agent = self.config.get_string("provider_user_agent")
        if not self.user_agent or "Mozilla" in self.user_agent:
            self.user_agent = "TiviMate/4.7.0 (Linux; Android 11)"

        self.epg_url = None
        self.channels_loaded = False

        xbmc.log("[IPTV3] Konstruktor zakończył pracę.", xbmc.LOGINFO)


    # ---------------------------------------------------------
    # PROCEDURA STARTOWA
    # ---------------------------------------------------------
    def startup(self):
        xbmc.log("[IPTV3] MainEngine: Startup procedur...", xbmc.LOGINFO)

        try:
            login_ok = self.auth.login()
        except Exception as e:
            xbmc.log(f"[IPTV3] Wyjątek logowania: {e}", xbmc.LOGERROR)
            return False

        if not login_ok:
            xbmc.log("[IPTV3] Autoryzacja odrzucona.", xbmc.LOGERROR)
            return False

        xbmc.log("[IPTV3] Autoryzacja pomyślna.", xbmc.LOGINFO)

        try:
            self.db.initialize()
            
            # --- INTELIGENTNA MIGRACJA (BEZ BŁĘDÓW DUPLIKATÓW) ---
            cursor = self.db.fetch_all("PRAGMA table_info(channels)")
            existing_cols = [col['name'] for col in cursor]
            
            # Kolumny, które dodajemy tylko jeśli ich nie ma
            if "logo" not in existing_cols:
                self.db.execute_query("ALTER TABLE channels ADD COLUMN logo TEXT")
                xbmc.log("[IPTV3] Dodano kolumnę 'logo'.", xbmc.LOGINFO)

            if "group_name" not in existing_cols:
                self.db.execute_query("ALTER TABLE channels ADD COLUMN group_name TEXT")
                xbmc.log("[IPTV3] Dodano kolumnę 'group_name'.", xbmc.LOGINFO)

            if "sort_index" not in existing_cols:
                self.db.execute_query("ALTER TABLE channels ADD COLUMN sort_index INTEGER")
                xbmc.log("[IPTV3] Dodano kolumnę 'sort_index'.", xbmc.LOGINFO)

            if "is_favorite" not in existing_cols:
                self.db.execute_query("ALTER TABLE channels ADD COLUMN is_favorite INTEGER DEFAULT 0")
                xbmc.log("[IPTV3] Dodano kolumnę 'is_favorite'.", xbmc.LOGINFO)

            if "is_vod" not in existing_cols:
                self.db.execute_query("ALTER TABLE channels ADD COLUMN is_vod INTEGER DEFAULT 0")
                xbmc.log("[IPTV3] Dodano kolumnę 'is_vod'.", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd bazy: {e}", xbmc.LOGERROR)
            return False

        # 3. Automatyczne ładowanie danych M3U
        self._auto_load_m3u()
        
        # --- URUCHOMIENIE ROBOTA W TLE ---
        self.start_background_scraper()
        
        return True


    # ---------------------------------------------------------
    # ŁADOWANIE LISTY M3U I EPG
    # ---------------------------------------------------------
    def _auto_load_m3u(self):
        import re 
        if not self.m3u_url: return

        # 1. Sprawdzanie cache ORAZ tego, czy baza fizycznie posiada kanały
        pr_path = os.path.join(self.profile_path, "epg_programs.json")
        if os.path.exists(pr_path):
            if (time.time() - os.path.getmtime(pr_path)) < 86400:
                # Zabezpieczenie: Sprawdzamy czy tabela channels nie jest pusta
                try:
                    count = self.db.fetch_all("SELECT COUNT(*) as c FROM channels")[0]['c']
                    if count > 0:
                        xbmc.log("[IPTV3] Dane EPG/M3U aktualne (Cache).", xbmc.LOGINFO)
                        self.channels_loaded = True
                        return
                except:
                    pass

        xbmc.log(f"[IPTV3] Pobieranie: {self.m3u_url}", xbmc.LOGINFO)
        
        # 2. Pobieranie z oszustwem User-Agent, by ominąć blokady dostawcy
        content = ""
        try:
            import requests
            headers = {'User-Agent': getattr(self, 'user_agent', 'TiviMate/4.7.0 (Linux; Android 11)')}
            if self.m3u_url.startswith("http"):
                resp = requests.get(self.m3u_url, headers=headers, timeout=20)
                if resp.status_code == 200:
                    content = resp.text
                else:
                    xbmc.log(f"[IPTV3] Błąd HTTP {resp.status_code} przy pobieraniu M3U", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd pobierania requests: {e}", xbmc.LOGERROR)

        # Fallback do starej metody
        if not content:
            content = self.m3u_parser.load_source(self.m3u_url)
            
        if not content: 
            xbmc.log("[IPTV3] Brak zawartości pliku M3U.", xbmc.LOGERROR)
            return

        channels = self.m3u_parser.parse(content)
        self.epg_url = getattr(self.m3u_parser, "epg_url", None)

        # 3. NAJWAŻNIEJSZE ZABEZPIECZENIE: Nie kasujemy bazy, jeśli pobrało 0 kanałów!
        if not channels or len(channels) == 0:
            xbmc.log("[IPTV3] Parsowanie zwróciło 0 kanałów! Przerywam aktualizację, chronię starą bazę.", xbmc.LOGERROR)
            return

        try:
            self.db.execute_query("DELETE FROM channels")
            for idx, ch in enumerate(channels, start=1):
                url = ch.get("stream_url")
                if not url: continue

                # Oznaczanie VOD
                is_vod = 1 if (".mp4" in url or ".mkv" in url or ".avi" in url) else 0

                # --- NAPRAWA KRYTYCZNEGO BŁĘDU REGEX DLA ANDROIDA ---
                raw_name = ch.get("name", "")
                
                # Znacznik (?i) musi być na samym początku stringa!
                clean_name = re.sub(r'(?i)^(pl|po)(?:\s*[:|]\s*|\s+i\s+|\s+)', '', raw_name)
                # Usuwa osierocone myślniki, dwukropki i spacje na początku, jeśli zostały
                clean_name = re.sub(r'^[\-:\s]+', '', clean_name)

                self.db.execute_query(
                    """INSERT INTO channels 
                       (channel_id, name, stream_url, tvg_name, tvg_id, logo, group_name, sort_index, is_favorite, is_vod) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (idx, clean_name, url, ch.get("tvg_name", ""), ch.get("tvg_id", ""), 
                     ch.get("logo_url", ""), ch.get("group_name", "Inne"), idx, 0, is_vod)
                )
            self.channels_loaded = True
            xbmc.log(f"[IPTV3] Pomyślnie zapisano {len(channels)} kanałów.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd synchro bazy: {e}", xbmc.LOGERROR)

        # --- OBLICZANIE CUTOFF_TIME DLA EPG NA PODSTAWIE USTAWIEŃ KODI ---
        addon = xbmcaddon.Addon()
        enable_catchup = addon.getSetting("enable_catchup") == "true"
        try:
            catchup_days = int(addon.getSetting("catchup_days") or "3")
        except ValueError:
            catchup_days = 3
            
        now = int(time.time())
        if not enable_catchup:
            # Catchup wyłączony - zachowujemy programy tylko do 12 godzin wstecz
            cutoff_time = now - (12 * 3600)
            xbmc.log("[IPTV3] Catchup wyłączony. Pobieram tylko bieżące audycje.", xbmc.LOGINFO)
        else:
            # Catchup włączony - ucinamy wszystko starsze niż wybrana liczba dni
            cutoff_time = now - (catchup_days * 86400)
            xbmc.log(f"[IPTV3] Catchup włączony: {catchup_days} dni wstecz.", xbmc.LOGINFO)

        # 4. Pobieranie EPG i przekazanie blokady do parsera
        epg_bytes = self.download_epg()
        if epg_bytes:
            parsed_epg = self.xmltv.parse(epg_bytes, cutoff_time=cutoff_time)
            try:
                ch_json = os.path.join(self.profile_path, "epg_channels.json")
                pr_json = os.path.join(self.profile_path, "epg_programs.json")
                with xbmcvfs.File(ch_json, 'w') as f: f.write(json.dumps(parsed_epg["channels"]))
                with xbmcvfs.File(pr_json, 'w') as f: f.write(json.dumps(parsed_epg["programs"]))
            except: pass
    
    def download_epg(self):
        url = self.epg_url or self.epg_url_1 or self.epg_url_2
        if not url: return None
        try:
            import requests
            r = requests.get(url, timeout=15, verify=False)
            return r.content
        except: return None

    def download_epg(self):
        url = self.epg_url or self.epg_url_1 or self.epg_url_2
        if not url: return None
        try:
            import requests
            r = requests.get(url, timeout=15, verify=False)
            return r.content
        except: return None


    # ---------------------------------------------------------
    # ODTWARZANIE (NAPRAWA BŁĘDU 406 I HLS)
    # ---------------------------------------------------------
    def play_channel(self, channel_id):
        xbmc.log(f"[IPTV3] Żądanie odtworzenia kanału ID: {channel_id}", xbmc.LOGINFO)

        try:
            results = self.db.fetch_all("SELECT * FROM channels WHERE channel_id = ?", (channel_id,))
            if not results: return

            ch = dict(results[0])
            stream_url = ch.get('stream_url')
            
            # --- INTELIGENTNE ROZSZERZENIA ---
            # Dopisujemy .ts tylko jeśli link nie ma ŻADNEGO znanego rozszerzenia
            url_lower = stream_url.lower()
            if not any(ext in url_lower for ext in ['.m3u8', '.ts', '.mp4', '.mkv', '.avi', '.mpd']):
                if ch.get('is_vod') == 0:
                    stream_url += ".ts"

            # Dynamiczny Referer na podstawie hosta linku
            parsed_host = urllib.parse.urlparse(stream_url)
            host_url = f"{parsed_host.scheme}://{parsed_host.netloc}/"

            if "|" not in stream_url:
                ua = urllib.parse.quote(self.user_agent)
                ref = urllib.parse.quote(host_url)
                stream_url += f"|User-Agent={ua}&Referer={ref}"

            listitem = xbmcgui.ListItem(label=ch.get('name'))
            if ch.get('logo'):
                listitem.setArt({'icon': ch.get('logo'), 'thumb': ch.get('logo')})

            # Obsługa FFmpegDirect (Odporny na 406)
            listitem.setProperty('inputstream', 'inputstream.ffmpegdirect')
            listitem.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')

            # EPG do OSD
            matched_id = self.epg.match_epg_id(ch.get('name'), ch.get('tvg_name'), ch.get('tvg_id'))
            if matched_id:
                prog = self.epg.get_current_program(matched_id)
                if prog:
                    listitem.setInfo('video', {'title': prog['title'], 'plot': prog['description']})

            xbmc.log(f"[IPTV3] Start Live Stream: {stream_url}", xbmc.LOGINFO)
            self.player.play_stream(stream_url, listitem)

        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd play_channel: {e}", xbmc.LOGERROR)

    # ---------------------------------------------------------
    # WYMUSZENIE AKTUALIZACJI M3U / EPG
    # ---------------------------------------------------------
    def force_update(self):
        """
        Wymusza odświeżenie list M3U i EPG.
        Czyści stare pliki cache i uruchamia ponowne pobieranie.
        """
        xbmc.log("[IPTV3] MainEngine: Ręczne wymuszenie aktualizacji list.", xbmc.LOGINFO)
        
        # 1. Usuwamy pliki cache (które normalnie blokują pobieranie przez 24h)
        ch_json = os.path.join(self.profile_path, "epg_channels.json")
        pr_json = os.path.join(self.profile_path, "epg_programs.json")
        
        if os.path.exists(ch_json):
            os.remove(ch_json)
        if os.path.exists(pr_json):
            os.remove(pr_json)
            
        # 2. Resetujemy flagę wczytania
        self.channels_loaded = False
        
        # 3. Uruchamiamy pobieranie od nowa
        self._auto_load_m3u()
        
        # 4. Wyświetlamy powiadomienie na ekranie
        xbmcgui.Dialog().notification("IPTV 3.0", "Lista i EPG zostały odświeżone!", xbmcgui.NOTIFICATION_INFO, 3000)
    
    # ---------------------------------------------------------
    # CICHY SCRAPER W TLE (BACKGROUND WORKER)
    # ---------------------------------------------------------
    def start_background_scraper(self):
        """Uruchamia pobieranie okładek w tle, odciążając główny wątek (TV fix)."""
        if not self.tmdb.api_key:
            xbmc.log("[IPTV3] Brak klucza TMDb. Robot nie startuje.", xbmc.LOGINFO)
            return
            
        window = xbmcgui.Window(10000)
        if window.getProperty("iptv3_scraper_running") == "true":
            return
            
        # Zabezpieczenie przed dublowaniem wątków
        window.setProperty("iptv3_scraper_running", "true")

        # ZMIANA DLA TV: Usunęliśmy zapytanie SQL stąd. Nie obciążamy procesora przy starcie.
        # Odpalamy robota bez podawania mu tytułów od razu. Sam je sobie znajdzie po "drzemce".
        thread = threading.Thread(target=self._tmdb_scraper_worker)
        thread.daemon = True  
        thread.start()

    def _tmdb_scraper_worker(self):
        """Praca wykonywana w tle - powolne odpytywanie TMDb po opóźnieniu dla TV."""
        monitor = xbmc.Monitor()
        
        # 1. DRZEMKA DLA TELEWIZORA: Czekamy 10 sekund, żeby interfejs zdążył się płynnie załadować
        xbmc.log("[IPTV3] Scraper w tle: Oczekiwanie 10 sekund na start...", xbmc.LOGINFO)
        if monitor.waitForAbort(10):
            xbmcgui.Window(10000).clearProperty("iptv3_scraper_running")
            return
            
        try:
            # 2. Odciążamy główny wątek - pytamy bazę dopiero, gdy TV "odetchnie"
            query = "SELECT DISTINCT name FROM channels WHERE is_vod = 1"
            rows = self.db.fetch_all(query)
            titles = [r["name"] for r in rows]
            
            if not titles:
                xbmc.log("[IPTV3] Scraper w tle: Brak filmów VOD do przetworzenia.", xbmc.LOGINFO)
                return
                
            xbmc.log(f"[IPTV3] Scraper w tle: Zaczynam sprawdzanie {len(titles)} filmów.", xbmc.LOGINFO)

            # 3. Pętla pobierająca
            for title in titles:
                # Bezpieczne sprawdzanie zamykania Kodi
                if monitor.abortRequested():
                    break

                self.tmdb.get_movie_info(title)
                
                # Czekamy 0.5 sekundy między zapytaniami do API
                if monitor.waitForAbort(0.5):
                    break

            xbmc.log("[IPTV3] Cichy scraper TMDb w tle zakończył pracę pomyślnie.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd scrapera w tle: {e}", xbmc.LOGERROR)
        finally:
            # Zawsze zwalniamy blokadę działania na końcu!
            xbmcgui.Window(10000).clearProperty("iptv3_scraper_running")
    
    def shutdown(self):
        try:
            self.db.close()
            xbmc.log("[IPTV3] Baza zamknięta pomyślnie.", xbmc.LOGINFO)
        except: pass