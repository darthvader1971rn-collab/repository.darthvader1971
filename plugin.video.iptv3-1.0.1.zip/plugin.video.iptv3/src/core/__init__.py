import os, sys

src_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if src_root not in sys.path:
    sys.path.insert(0, src_root)
