# -*- coding: utf-8 -*-
import xbmc
import threading
import time

class ServiceWorker(threading.Thread):
    """
    Pracownik systemowy (Service Worker).
    Działa w osobnym wątku, obsługując zadania w tle: 
    aktualizację EPG, sprawdzanie stanu sieci i konserwację bazy.
    """
    
    def __init__(self):
        super(ServiceWorker, self).__init__()
        self.daemon = True  # Wątek zakończy się razem z wtyczką
        self.is_running = True
        xbmc.log("[IPTV3] Zainicjowano wątek ServiceWorker.", xbmc.LOGINFO)

    def run(self):
        """Pętla główna pracownika tła."""
        xbmc.log("[IPTV3] ServiceWorker: Rozpoczęto monitorowanie zadań w tle.", xbmc.LOGDEBUG)
        
        while self.is_running:
            # Tutaj wykonujemy okresowe zadania
            self._update_epg_task()
            
            # Odpoczynek wątku (np. sprawdzanie co 10 minut)
            # Używamy monitora Kodi, aby reagować na zamknięcie systemu
            if xbmc.Monitor().waitForAbort(600):
                self.stop()
                break

    def _update_epg_task(self):
        """Cykliczne sprawdzanie i pobieranie danych EPG."""
        xbmc.log("[IPTV3] ServiceWorker: Sprawdzanie dostępności aktualizacji EPG...", xbmc.LOGDEBUG)
        # Logika sprawdzania timestampu w tabeli metadata
        pass

    def stop(self):
        """Zatrzymuje bezpiecznie pracę wątku."""
        self.is_running = False
        xbmc.log("[IPTV3] ServiceWorker: Zatrzymano zadania w tle.", xbmc.LOGINFO)

    def trigger_immediate_sync(self):
        """Wymusza natychmiastową synchronizację danych (np. po zmianie ustawień)."""
        xbmc.log("[IPTV3] ServiceWorker: Wymuszono natychmiastową synchronizację.", xbmc.LOGINFO)
        # Wywołanie metod aktualizacji poza harmonogramem