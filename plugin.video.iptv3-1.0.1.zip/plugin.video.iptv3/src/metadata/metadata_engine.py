# -*- coding: utf-8 -*-
import xbmc

class MetadataEngine:
    """
    Główny silnik zarządzający metadanymi (Metadata Engine).
    Odpowiada za pobieranie, wzbogacanie i udostępnianie dodatkowych informacji
    o kanałach i audycjach (np. opisy, gatunki, obsada, oceny).
    """
    
    def __init__(self):
        # Słownik do lokalnego buforowania metadanych, by nie pytać API za każdym razem
        self.metadata_cache = {}
        xbmc.log("[IPTV3] Zainicjowano moduł MetadataEngine", xbmc.LOGINFO)

    def get_channel_metadata(self, channel_id):
        """
        Pobiera rozszerzone metadane dla konkretnego kanału.
        
        :param channel_id: Identyfikator kanału
        :return: Słownik z metadanymi (np. pełna nazwa, kategoria, domyślna ikona) lub pusty słownik
        """
        if channel_id in self.metadata_cache:
            return self.metadata_cache[channel_id]
            
        # W przyszłości dodamy tu logikę wyciągania metadanych z zaawansowanych tagów
        # w pliku M3U (np. tvg-logo, group-title) lub z zewnętrznych baz danych.
        return {}

    def enrich_program_data(self, program_data):
        """
        Wzbogaca podstawowe dane z EPG o dodatkowe informacje szczegółowe.
        Wykorzystywane przez odtwarzacz do OSD oraz przez moduł nagrywania.
        
        :param program_data: Podstawowy słownik z danymi programu (z EpgEngine)
        :return: Wzbogacony słownik
        """
        if not program_data:
            return {}
            
        title = program_data.get('title', 'Nieznany tytuł')
        xbmc.log(f"[IPTV3] MetadataEngine: Próba wzbogacenia danych dla audycji '{title}'", xbmc.LOGDEBUG)
        
        # Tworzymy kopię, by bezpiecznie modyfikować dane bez wpływu na główne źródło EPG
        enriched_data = program_data.copy()
        
        # Tutaj w przyszłości znajdzie się logika pobierająca dodatkowe informacje, 
        # np. z zewnętrznych API filmowych (TMDB, OMDB) na podstawie tytułu.
        
        return enriched_data