# -*- coding: utf-8 -*-
import xbmc
import os

class PiconManager:
    """
    Moduł zarządzający ikonami kanałów (PICON Manager).
    Odpowiada za pobieranie, buforowanie i dopasowywanie logotypów
    do odpowiednich stacji telewizyjnych na podstawie ich ID lub nazwy.
    """
    
    def __init__(self):
        # W przyszłości: ścieżka do lokalnego folderu z zapisanymi ikonami
        self.picon_dir = ""
        xbmc.log("[IPTV3] Zainicjowano moduł PiconManager", xbmc.LOGINFO)

    def get_picon(self, channel_id, channel_name, provider_logo_url=""):
        """
        Zwraca ścieżkę do ikony kanału (lokalną lub zewnętrzny URL).
        
        :param channel_id: Unikalny identyfikator kanału (np. z pliku XMLTV)
        :param channel_name: Nazwa stacji telewizyjnej (do ewentualnego szukania po nazwie)
        :param provider_logo_url: Adres URL ikony dostarczony w m3u przez Providera
        :return: Ścieżka do pliku lub adres URL grafiki
        """
        # Najpierw sprawdzamy, czy mamy zapisaną lepszą jakość ikony lokalnie
        local_picon = self._check_local_storage(channel_id, channel_name)
        
        if local_picon:
            return local_picon
            
        # Jeśli nie mamy lokalnej, używamy URL od dostawcy
        if provider_logo_url:
            xbmc.log(f"[IPTV3] PiconManager: Użyto domyślnego URL ikony dla '{channel_name}'", xbmc.LOGDEBUG)
            return provider_logo_url
            
        return ""

    def _check_local_storage(self, channel_id, channel_name):
        """
        Wewnętrzna metoda przeszukująca lokalny katalog w poszukiwaniu ikony
        (np. pliku nazwa_kanalu.png).
        """
        if not self.picon_dir or not os.path.exists(self.picon_dir):
            return None
            
        # Tu znajdzie się mechanizm normalizacji nazw (np. usunięcie spacji, znaków specjalnych)
        # i sprawdzanie czy plik istnieje na dysku.
        return None