# -*- coding: utf-8 -*-
import xbmc

class MetadataMerge:
    """
    Moduł odpowiedzialny za łączenie i rozwiązywanie konfliktów metadanych (Metadata Merge).
    Scala informacje pobrane z różnych źródeł (np. EPG, TMDB, lokalna baza) w jeden spójny obiekt.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł MetadataMerge", xbmc.LOGINFO)

    def merge_data(self, primary_data, secondary_data):
        """
        Scala dwa słowniki z metadanymi, dając priorytet danym z głównego źródła.
        
        :param primary_data: Główne źródło danych (np. bogate dane z TMDB lub ręczne nadpisania)
        :param secondary_data: Zapasowe źródło danych (np. podstawowe opisy z pliku XMLTV)
        :return: Połączony słownik zawierający najpełniejsze informacje
        """
        xbmc.log("[IPTV3] MetadataMerge: Rozpoczęto scalanie pakietów metadanych", xbmc.LOGDEBUG)
        
        if not primary_data:
            return secondary_data or {}
            
        if not secondary_data:
            return primary_data
            
        # Tworzymy kopię danych zapasowych jako bazę
        merged = secondary_data.copy()
        
        # Nadpisujemy bazę danymi z głównego źródła
        for key, value in primary_data.items():
            # Nadpisz tylko wtedy, gdy wartość z primary_data faktycznie istnieje i nie jest pusta
            if value:
                merged[key] = value
                
        return merged