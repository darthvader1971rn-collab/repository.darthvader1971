# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class PlaybackEngine:
    """
    Główny silnik odtwarzania dla IPTV 3.0.
    Odpowiada za inicjację, monitorowanie i kontrolę strumienia wideo.
    """
    
    def __init__(self):
        # Inicjalizacja wbudowanego odtwarzacza Kodi
        self.player = xbmc.Player()
        xbmc.log("[IPTV3] Zainicjowano moduł PlaybackEngine", xbmc.LOGINFO)

    def play_stream(self, url, title="Nieznany kanał", metadata=None):
        """
        Rozpoczyna odtwarzanie wskazanego strumienia.
        
        :param url: Adres URL strumienia (M3U / zdekodowany CDN)
        :param title: Nazwa kanału/materiału do wyświetlenia w OSD
        :param metadata: Opcjonalny słownik z metadanymi (np. opis EPG, ikona)
        """
        xbmc.log(f"[IPTV3] PlaybackEngine: Próba odtworzenia strumienia: {url}", xbmc.LOGINFO)
        
        # Tworzenie obiektu ListItem wymaganego przez Kodi do odtwarzania
        listitem = xbmcgui.ListItem(title, path=url)
        
        # Dodawanie metadanych, jeśli zostały przekazane (np. z modułu MetadataEngine)
        if metadata:
            if 'icon' in metadata:
                listitem.setArt({'icon': metadata['icon'], 'thumb': metadata['icon']})
            if 'plot' in metadata:
                listitem.setInfo('video', {'plot': metadata['plot']})
                
        # Uruchomienie odtwarzania
        self.player.play(url, listitem)

    def stop_playback(self):
        """Zatrzymuje aktualnie odtwarzany materiał."""
        if self.player.isPlaying():
            self.player.stop()
            xbmc.log("[IPTV3] PlaybackEngine: Odtwarzanie zatrzymane przez użytkownika/system.", xbmc.LOGINFO)

    def is_playing(self):
        """Sprawdza, czy odtwarzacz jest obecnie aktywny."""
        return self.player.isPlaying()