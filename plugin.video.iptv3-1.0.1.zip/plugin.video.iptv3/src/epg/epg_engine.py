# -*- coding: utf-8 -*-
import os
import json
import time
import xbmc
import xbmcvfs


class EpgEngine:
    """
    Silnik EPG 3.0
    Odpowiada za:
    - ładowanie EPG z JSON
    - dopasowanie kanałów M3U → EPG
    - zwracanie aktualnego programu
    - zwracanie listy programów
    - generowanie timeline
    """

    def __init__(self, profile_path):
        self.profile_path = profile_path

        # kanały:
        # self.channels: klucz (np. znormalizowana nazwa / tvg-id w lowercase) → epg_id
        self.channels = {}
        # lista wszystkich programów
        self.programs = []
        # mapa: epg_id → lista programów
        self.prog_map = {}

        xbmc.log("[IPTV3] EpgEngine: inicjalizacja...", xbmc.LOGINFO)

        # sprawdzenie epg_raw.xml
        self._check_epg_raw_xml()

        # ładowanie JSON
        self._load_epg()

    # ---------------------------------------------------------
    # NORMALIZACJA NAZW
    # ---------------------------------------------------------
    def normalize(self, name):
        """Ujednolica nazwy kanałów usuwając znaczniki HD i znaki specjalne."""
        if not name: return ""
        n = name.lower()
        n = n.replace(" hd", "").replace(" uhd", "").replace(" 4k", "").replace(" fhd", "").replace(" sd", "")
        for char in [".", "+", "-", "|", ":", "[", "]"]: 
            n = n.replace(char, " ")
        return " ".join(n.split())

    # ---------------------------------------------------------
    # WALIDACJA epg_raw.xml
    # ---------------------------------------------------------
    def _check_epg_raw_xml(self):
        raw_path = os.path.join(self.profile_path, "epg_raw.xml")
        if not xbmcvfs.exists(raw_path):
            return

        try:
            with xbmcvfs.File(raw_path, 'r') as f:
                head = f.read(200)
        except:
            return

        # jeśli nie zaczyna się od "<", to nie XML
        if not head.lstrip().startswith("<"):
            xbmc.log("[IPTV3] Ostrzeżenie: epg_raw.xml nie wygląda na XML!", xbmc.LOGWARNING)

    # ---------------------------------------------------------
    # ŁADOWANIE EPG Z JSON I OBSŁUGA LIST ALIASÓW
    # ---------------------------------------------------------
    def _load_epg(self):
        ch_path = os.path.join(self.profile_path, "epg_channels.json")
        pr_path = os.path.join(self.profile_path, "epg_programs.json")

        if not xbmcvfs.exists(ch_path) or not xbmcvfs.exists(pr_path):
            xbmc.log("[IPTV3] EpgEngine: Brak plików EPG.", xbmc.LOGWARNING)
            return

        try:
            with xbmcvfs.File(ch_path, 'r') as f:
                raw_channels = json.loads(f.read())

            # Budujemy bezpieczną mapę kanałów z wypakowywaniem list
            self.channels = {}
            if isinstance(raw_channels, dict):
                for k, v in raw_channels.items():
                    self.channels[self.normalize(k)] = v
            elif isinstance(raw_channels, list):
                for ch in raw_channels:
                    cid = ch.get("id") or ch.get("channel_id")
                    disp = ch.get("display_name") or ch.get("name")
                    if cid:
                        self.channels[str(cid).lower()] = cid
                        if disp:
                            if isinstance(disp, list):
                                for d in disp:
                                    n = self.normalize(d)
                                    if n: self.channels[n] = cid
                            else:
                                n = self.normalize(disp)
                                if n: self.channels[n] = cid

            with xbmcvfs.File(pr_path, 'r') as f:
                self.programs = json.loads(f.read())

            # budujemy mapę epg_id → lista programów
            for p in self.programs:
                cid = p.get("channel_id")
                if not cid:
                    continue
                self.prog_map.setdefault(cid, []).append(p)

            # sortujemy programy w każdej liście po czasie
            for cid in self.prog_map:
                self.prog_map[cid].sort(key=lambda x: x.get("start_time", 0))

            xbmc.log(f"[IPTV3] EpgEngine: Załadowano {len(self.channels)} kanałów (unikalnych kluczy).", xbmc.LOGINFO)
            xbmc.log(f"[IPTV3] EpgEngine: Załadowano {len(self.programs)} programów EPG.", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[IPTV3] EpgEngine: Błąd ładowania EPG: {e}", xbmc.LOGERROR)

    # ---------------------------------------------------------
    # DOPASOWANIE KANAŁU M3U → EPG (wysokopoziomowe API)
    # ---------------------------------------------------------
    def match_epg_channel(self, m3u_channel, epg_channels=None):
        """
        m3u_channel: dict z polami:
            - "name"
            - "tvg_name"
            - "tvg_id"
        """
        name = (m3u_channel.get("name") or "").strip()
        tvg_name = (m3u_channel.get("tvg_name") or "").strip()
        tvg_id = (m3u_channel.get("tvg_id") or "").strip()

        epg_id = self.match_epg_id(name=name, tvg_name=tvg_name, tvg_id=tvg_id)

        xbmc.log(
            f"[IPTV3] EpgEngine: match_epg_channel → name='{name}', tvg_name='{tvg_name}', tvg_id='{tvg_id}', epg_id='{epg_id}'",
            xbmc.LOGDEBUG
        )

        return epg_id

    # ---------------------------------------------------------
    # DOPASOWANIE KANAŁU M3U → EPG (NOWY TWARDY RDZEŃ)
    # ---------------------------------------------------------
    def match_epg_id(self, name, tvg_name="", tvg_id=""):
        """
        Bezpieczne dopasowanie bez "zgadywania" krótkich wyrazów w długich.
        """
        # 1. Priorytet: Twarde dopasowanie tvg-id
        if tvg_id:
            raw_id = str(tvg_id).lower()
            if raw_id in self.channels:
                return self.channels[raw_id]

        # 2. Zebranie potencjalnych nazw
        cands = []
        if tvg_name: cands.append(self.normalize(tvg_name))
        if name: cands.append(self.normalize(name))

        for cand_norm in cands:
            if not cand_norm: continue
            
            # Bezpośrednie sprawdzenie (znormalizowanej nazwy)
            if cand_norm in self.channels:
                return self.channels[cand_norm]
                
            # FAZA 1: Usunięcie spacji dla rozróżnienia (TVN24 vs TVN 24)
            cand_strict = cand_norm.replace(" ", "")
            for epg_name, cid in self.channels.items():
                if cand_strict == epg_name.replace(" ", ""):
                    return cid

        # FAZA 2: Ostre sprawdzanie zbioru słów (zapobiega myleniu "TVN" z "TVN 24")
        for cand_norm in cands:
            if not cand_norm: continue
            cand_words = set(cand_norm.split())
            for epg_name, cid in self.channels.items():
                if cand_words.issubset(set(epg_name.split())):
                    return cid

        return None

    # ---------------------------------------------------------
    # AKTUALNY PROGRAM
    # ---------------------------------------------------------
    def get_current_program(self, epg_id):
        now = int(time.time())

        if epg_id not in self.prog_map:
            return None

        for p in self.prog_map[epg_id]:
            if p["start_time"] <= now <= p["end_time"]:
                return p

        return None

    # ---------------------------------------------------------
    # NASTĘPNY PROGRAM
    # ---------------------------------------------------------
    def get_next_program(self, epg_id):
        now = int(time.time())

        if epg_id not in self.prog_map:
            return None

        for p in self.prog_map[epg_id]:
            if p["start_time"] > now:
                return p

        return None

    # ---------------------------------------------------------
    # WSZYSTKIE PROGRAMY DLA KANAŁU
    # ---------------------------------------------------------
    def get_programs_for_channel(self, epg_id):
        return self.prog_map.get(epg_id, [])

    # ---------------------------------------------------------
    # TIMELINE (lista bloków czasowych)
    # ---------------------------------------------------------
    def get_timeline(self, epg_id):
        """
        Zwraca listę:
        [
            { "title": ..., "start": ..., "end": ... },
            ...
        ]
        """
        if epg_id not in self.prog_map:
            return []

        timeline = []
        for p in self.prog_map[epg_id]:
            timeline.append({
                "title": p["title"],
                "start": p["start_time"],
                "end": p["end_time"]
            })

        return timeline