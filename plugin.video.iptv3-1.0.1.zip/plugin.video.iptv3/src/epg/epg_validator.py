# -*- coding: utf-8 -*-
import xbmc

class EpgValidator:
    """
    Moduł odpowiedzialny za walidację danych EPG (EPG Validator).
    Sprawdza poprawność struktury, formatu czasu oraz eliminuje uszkodzone wpisy.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł EpgValidator", xbmc.LOGINFO)

    def validate_program(self, program_data):
        """
        Sprawdza, czy pojedynczy wpis programu zawiera wszystkie niezbędne dane.
        
        :param program_data: Słownik z danymi programu (tytuł, start, stop)
        :return: True, jeśli wpis jest poprawny, False w przypadku błędów
        """
        if not program_data:
            return False
            
        # Wymagane klucze, bez których program nie ma sensu
        required_keys = ['title', 'start_time', 'end_time']
        for key in required_keys:
            if key not in program_data or not program_data[key]:
                # Używamy LOGDEBUG, aby nie zaśmiecać głównego logu przy setkach drobnych błędów z XML
                xbmc.log(f"[IPTV3] EpgValidator: Brakuje kluczowego pola '{key}' w danych programu.", xbmc.LOGDEBUG)
                return False
                
        # Sprawdzenie logiki czasu (czy start nie jest później lub równy stop)
        if program_data.get('start_time') >= program_data.get('end_time'):
            xbmc.log(f"[IPTV3] EpgValidator: Błąd logiki czasu dla programu '{program_data.get('title')}'.", xbmc.LOGDEBUG)
            return False
            
        return True

    def clean_epg_data(self, epg_dict):
        """
        Przechodzi przez cały słownik EPG i usuwa z niego nieprawidłowe wpisy.
        Metoda wywoływana przez EpgEngine po załadowaniu i przeparsowaniu pliku.
        
        :param epg_dict: Surowe dane EPG
        :return: Oczyszczony słownik EPG gotowy do użycia
        """
        xbmc.log("[IPTV3] EpgValidator: Rozpoczęto czyszczenie i walidację danych EPG...", xbmc.LOGINFO)
        cleaned_dict = {}
        
        # W przyszłości dodamy tu pętle iterujące po kanałach i ich ramówkach.
        # Wykorzystamy validate_program() do oceny każdego wpisu i przepiszemy
        # do cleaned_dict tylko poprawne audycje.
        
        xbmc.log("[IPTV3] EpgValidator: Zakończono walidację EPG.", xbmc.LOGINFO)
        return cleaned_dict