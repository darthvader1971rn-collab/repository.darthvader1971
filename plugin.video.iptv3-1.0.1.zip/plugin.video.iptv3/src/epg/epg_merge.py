# -*- coding: utf-8 -*-
import xbmc

class EpgMerge:
    """
    Moduł odpowiedzialny za łączenie danych z wielu źródeł EPG (EPG Merge).
    Pozwala na uzupełnianie brakujących programów z zapasowych plików XMLTV.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł EpgMerge", xbmc.LOGINFO)

    def merge_sources(self, primary_epg_data, fallback_epg_data):
        """
        Scala dane z głównego i zapasowego źródła EPG.
        
        :param primary_epg_data: Słownik z danymi z podstawowego EPG
        :param fallback_epg_data: Słownik z danymi z zapasowego EPG
        :return: Połączony słownik zawierający najpełniejsze dostępne dane
        """
        xbmc.log("[IPTV3] EpgMerge: Rozpoczęto scalanie danych z wielu źródeł EPG...", xbmc.LOGINFO)
        
        if not primary_epg_data:
            xbmc.log("[IPTV3] EpgMerge: Główne źródło jest puste, używam tylko zapasowego.", xbmc.LOGWARNING)
            return fallback_epg_data or {}
            
        if not fallback_epg_data:
            return primary_epg_data
            
        merged_data = primary_epg_data.copy()
        
        # W przyszłości znajdzie się tu logika iterująca po kanałach z fallback_epg_data.
        # Jeśli jakiegoś kanału (lub godzin w ramówce) nie ma w merged_data,
        # zostaną one dopisywane z listy zapasowej.
        
        xbmc.log("[IPTV3] EpgMerge: Scalanie zakończone sukcesem.", xbmc.LOGINFO)
        return merged_data

    def deduplicate(self, merged_data):
        """
        Usuwa ewentualne duplikaty audycji (np. te same programy nachodzące na siebie czasowo),
        które mogły powstać podczas łączenia nie do końca spójnych źródeł.
        """
        # Mechanizm czyszczący pokrywające się wpisy
        return merged_data