import os, sys

# absolutna ścieżka do folderu src
src_root = os.path.dirname(os.path.abspath(__file__))

# dodaj src do sys.path, jeśli nie ma
if src_root not in sys.path:
    sys.path.insert(0, src_root)
