# -*- coding: utf-8 -*-
import xbmc

class Logger:
    """
    Zaawansowany moduł logowania (Logger).
    Ujednolica format komunikatów wtyczki w logach Kodi.
    """
    
    def __init__(self, prefix="[IPTV3]"):
        self.prefix = prefix
        xbmc.log(f"{self.prefix} Inicjalizacja systemu logowania.", xbmc.LOGINFO)

    def _log(self, message, level):
        """Wewnętrzna metoda wysyłająca sformatowany tekst do Kodi."""
        formatted_message = f"{self.prefix} {message}"
        xbmc.log(formatted_message, level)

    def info(self, message):
        """Loguje informację ogólną (LOGINFO)."""
        self._log(message, xbmc.LOGINFO)

    def warning(self, message):
        """Loguje ostrzeżenie (LOGWARNING)."""
        self._log(f"WARNING: {message}", xbmc.LOGWARNING)

    def error(self, message):
        """Loguje błąd (LOGERROR)."""
        self._log(f"ERROR: {message}", xbmc.LOGERROR)

    def debug(self, message):
        """
        Loguje informację techniczną (LOGDEBUG).
        Widoczna tylko przy włączonym trybie debugowania w Kodi.
        """
        self._log(f"DEBUG: {message}", xbmc.LOGDEBUG)

    def trace(self, module_name, function_name, message):
        """
        Specjalistyczne logowanie ścieżki wykonania (Trace).
        Pomaga namierzyć, w którym dokładnie miejscu kodu wystąpił problem.
        """
        trace_msg = f"[{module_name} -> {function_name}] {message}"
        self.debug(trace_msg)