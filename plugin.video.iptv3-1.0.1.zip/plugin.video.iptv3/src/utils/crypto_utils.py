# -*- coding: utf-8 -*-
import xbmc
import hashlib
import base64

class CryptoUtils:
    """
    Moduł narzędzi kryptograficznych (Crypto Utils).
    Zajmuje się haszowaniem danych, kodowaniem Base64 oraz bezpiecznym
    przechowywaniem tokenów dostawcy.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł CryptoUtils", xbmc.LOGINFO)

    def to_md5(self, text):
        """Generuje skrót MD5 z podanego tekstu (często wymagany przez API IPTV)."""
        if not text:
            return ""
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def base64_encode(self, plain_text):
        """Koduje tekst do formatu Base64."""
        try:
            sample_string_bytes = plain_text.encode("ascii")
            base64_bytes = base64.b64encode(sample_string_bytes)
            return base64_bytes.decode("ascii")
        except Exception as e:
            xbmc.log(f"[IPTV3] CryptoUtils: Błąd kodowania Base64: {str(e)}", xbmc.LOGERROR)
            return plain_text

    def base64_decode(self, encoded_text):
        """Dekoduje tekst z formatu Base64."""
        try:
            base64_bytes = encoded_text.encode("ascii")
            string_bytes = base64.b64decode(base64_bytes)
            return string_bytes.decode("ascii")
        except Exception as e:
            xbmc.log(f"[IPTV3] CryptoUtils: Błąd dekodowania Base64: {str(e)}", xbmc.LOGERROR)
            return encoded_text

    def obfuscate_password(self, password):
        """
        Prosta metoda maskująca hasło w logach, 
        aby nie było widoczne w czystej formie podczas debugowania.
        """
        if len(password) < 3:
            return "***"
        return f"{password[:2]}****{password[-1:]}"