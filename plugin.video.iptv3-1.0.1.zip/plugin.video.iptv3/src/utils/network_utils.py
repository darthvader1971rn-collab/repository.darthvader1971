# -*- coding: utf-8 -*-
import xbmc
import urllib.request
import urllib.error
import socket

class NetworkUtils:
    """
    Moduł narzędzi sieciowych (Network Utils).
    Odpowiada za bezpieczne wykonywanie zapytań HTTP, sprawdzanie łączności
    oraz zarządzanie nagłówkami połączeń.
    """
    
    def __init__(self):
        # Domyślny User-Agent, aby uniknąć blokowania przez serwery IPTV
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        xbmc.log("[IPTV3] Zainicjowano moduł NetworkUtils", xbmc.LOGINFO)

    def check_internet(self, host="8.8.8.8", port=53, timeout=3):
        """
        Szybkie sprawdzenie, czy urządzenie ma dostęp do internetu.
        Domyślnie próbuje połączyć się z DNS Google.
        """
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
            return True
        except socket.error:
            xbmc.log("[IPTV3] NetworkUtils: Brak połączenia z internetem!", xbmc.LOGWARNING)
            return False

    def get_data(self, url, headers=None):
        """
        Pobiera surowe dane (tekstowe) z podanego adresu URL.
        
        :param url: Adres źródłowy (np. link do M3U)
        :param headers: Opcjonalne dodatkowe nagłówki HTTP
        :return: Treść odpowiedzi lub None w przypadku błędu
        """
        if not headers:
            headers = {'User-Agent': self.user_agent}
            
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req) as response:
                xbmc.log(f"[IPTV3] NetworkUtils: Pobieranie danych z {url} zakończone sukcesem.", xbmc.LOGDEBUG)
                return response.read().decode('utf-8')
        except urllib.error.URLError as e:
            xbmc.log(f"[IPTV3] NetworkUtils: Błąd podczas pobierania danych: {str(e)}", xbmc.LOGERROR)
            return None

    def download_file(self, url, destination_path):
        """
        Pobiera plik binarny (np. ikonę picon lub archiwum EPG) i zapisuje go na dysku.
        """
        try:
            urllib.request.urlretrieve(url, destination_path)
            return True
        except Exception as e:
            xbmc.log(f"[IPTV3] NetworkUtils: Nie udało się zapisać pliku: {str(e)}", xbmc.LOGERROR)
            return False