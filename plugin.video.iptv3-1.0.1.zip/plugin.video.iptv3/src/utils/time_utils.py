# -*- coding: utf-8 -*-
import time
from datetime import datetime, timedelta, timezone

class TimeUtils:
    """
    Moduł narzędzi czasowych (Time Utils).
    Odpowiada za konwersję formatów dat XMLTV → UNIX timestamp,
    obliczanie czasu trwania audycji oraz synchronizację między strefami czasowymi.
    """

    def __init__(self):
        pass

    def get_now_unix(self):
        """Zwraca aktualny czas systemowy w formacie UNIX (int)."""
        return int(time.time())

    # ---------------------------------------------------------
    # KONWERSJA XMLTV → UNIX
    # ---------------------------------------------------------
    def xmltv_to_unix(self, xmltv_string):
        """
        Poprawna konwersja XMLTV → UNIX timestamp.
        Omija zbugowane w Kodi 'datetime.strptime', parsując ciąg znaków ręcznie.
        """
        import time
        import calendar
        from datetime import datetime

        if not xmltv_string:
            return 0

        try:
            # Oczyszczamy string z ewentualnych myślników i dwukropków
            clean_str = xmltv_string.replace("-", "").replace(":", "")
            
            # Rozdzielamy datę i strefę
            parts = clean_str.split()
            date_part = parts[0]
            tz_part = parts[1] if len(parts) > 1 else None

            # Ręczne wyciąganie elementów daty na podstawie długości
            l = len(date_part)
            if l < 8:
                return 0  # Minimalnie potrzebujemy YYYYMMDD
                
            year = int(date_part[0:4])
            month = int(date_part[4:6])
            day = int(date_part[6:8])
            hour = int(date_part[8:10]) if l >= 10 else 0
            minute = int(date_part[10:12]) if l >= 12 else 0
            second = int(date_part[12:14]) if l >= 14 else 0

            # Tworzymy bezpieczny obiekt datetime z gotowych liczb
            dt = datetime(year, month, day, hour, minute, second)
            
            # Traktujemy datę jako UTC i pobieramy timestamp
            base_timestamp = calendar.timegm(dt.timetuple())

            # Obsługa strefy czasowej
            if tz_part:
                if tz_part.startswith(("+", "-")):
                    sign = 1 if tz_part[0] == "+" else -1
                    tz_clean = tz_part[1:].replace(":", "")
                    
                    if len(tz_clean) >= 4:
                        hours = int(tz_clean[0:2])
                        minutes = int(tz_clean[2:4])
                        # Obliczamy offset w sekundach
                        offset_seconds = sign * (hours * 3600 + minutes * 60)
                        
                        # Odejmujemy offset
                        return base_timestamp - offset_seconds

                if tz_part in ("Z", "UTC"):
                    return base_timestamp

            # Brak strefy → traktujemy jako lokalny czas systemu
            return int(time.mktime(dt.timetuple()))

        except Exception as e:
            import xbmc
            xbmc.log(f"[IPTV3] TimeUtils: Błąd parsowania daty EPG '{xmltv_string}' - {e}", xbmc.LOGERROR)
            return 0

    # ---------------------------------------------------------
    # FORMATOWANIE
    # ---------------------------------------------------------
    def format_to_hm(self, unix_timestamp):
        """Zamienia UNIX timestamp na czytelną godzinę i minutę (np. 20:15)."""
        return time.strftime('%H:%M', time.localtime(unix_timestamp))

    # ---------------------------------------------------------
    # CZAS TRWANIA
    # ---------------------------------------------------------
    def get_duration_minutes(self, start_unix, end_unix):
        """Oblicza czas trwania audycji w minutach."""
        if end_unix <= start_unix:
            return 0
        return int((end_unix - start_unix) / 60)

    # ---------------------------------------------------------
    # CZY PROGRAM TRWA TERAZ
    # ---------------------------------------------------------
    def is_program_running(self, start_unix, end_unix):
        """Sprawdza, czy aktualny czas mieści się w widełkach start-stop audycji."""
        now = self.get_now_unix()
        return start_unix <= now <= end_unix