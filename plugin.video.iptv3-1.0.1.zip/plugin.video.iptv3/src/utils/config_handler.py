# -*- coding: utf-8 -*-
import xbmcaddon
import xbmc

class ConfigHandler:
    """
    Moduł zarządzający konfiguracją (Config Handler).
    Umożliwia łatwy odczyt i zapis ustawień z pliku settings.xml wtyczki.
    """
    
    def __init__(self):
        # Pobieramy instancję naszej wtyczki
        self.addon = xbmcaddon.Addon()
        xbmc.log("[IPTV3] Zainicjowano moduł ConfigHandler", xbmc.LOGINFO)

    def get_string(self, setting_id):
        """Pobiera ustawienie jako tekst (string)."""
        return self.addon.getSetting(setting_id)

    def get_bool(self, setting_id):
        """Pobiera ustawienie jako wartość logiczną (bool)."""
        return self.addon.getSettingBool(setting_id)

    def get_int(self, setting_id):
        """Pobiera ustawienie jako liczbę całkowitą (int)."""
        try:
            return self.addon.getSettingInt(setting_id)
        except:
            return 0

    def set_value(self, setting_id, value):
        """
        Zapisuje nową wartość w ustawieniach wtyczki.
        
        :param setting_id: ID ustawienia z settings.xml
        :param value: Wartość do zapisania (zostanie skonwertowana na string)
        """
        self.addon.setSetting(setting_id, str(value))
        xbmc.log(f"[IPTV3] ConfigHandler: Zmieniono ustawienie '{setting_id}'", xbmc.LOGDEBUG)

    def get_all_settings(self):
        """
        W przyszłości: Metoda zwracająca pełny słownik konfiguracji 
        do celów diagnostycznych w DebugCenter.
        """
        pass