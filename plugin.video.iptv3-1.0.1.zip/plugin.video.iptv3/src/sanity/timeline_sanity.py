# -*- coding: utf-8 -*-
import xbmc
import time

class TimelineSanity:
    """
    Weryfikator osi czasu (Timeline Sanity).
    Odpowiada za poprawność logiczną harmonogramu EPG. 
    Chroni przed błędami wyświetlania czasu i nakładaniem się audycji.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano TimelineSanity - Strażnik Harmonogramu aktywny.", xbmc.LOGINFO)

    def validate_program_times(self, start_unix, end_unix):
        """
        Sprawdza, czy ramy czasowe audycji są logiczne.
        """
        if not start_unix or not end_unix:
            return False
            
        # 1. Czy koniec jest po początku?
        if end_unix <= start_unix:
            xbmc.log(f"[IPTV3] Sanity: Błąd czasu! Koniec ({end_unix}) jest przed startem ({start_unix}).", xbmc.LOGWARNING)
            return False
            
        # 2. Czy czas trwania nie jest absurdalny? (np. więcej niż 24h dla jednego programu)
        duration = end_unix - start_unix
        if duration > 86400:
            xbmc.log(f"[IPTV3] Sanity: Audycja trwa ponad 24h. Prawdopodobny błąd danych EPG.", xbmc.LOGDEBUG)
            return False
            
        return True

    def get_current_progress(self, start_unix, end_unix):
        """
        Oblicza procentowe zaawansowanie aktualnej audycji.
        Zwraca wartość 0-100.
        """
        now = int(time.time())
        if now < start_unix: return 0
        if now > end_unix: return 100
        
        total = end_unix - start_unix
        elapsed = now - start_unix
        return int((elapsed / float(total)) * 100)

    def is_gap_present(self, last_end_unix, next_start_unix):
        """
        Wykrywa "dziury" w programie TV między dwiema audycjami.
        """
        if last_end_unix == 0: return False
        
        diff = next_start_unix - last_end_unix
        if diff > 60: # Dziura większa niż minuta
            xbmc.log(f"[IPTV3] Sanity: Wykryto lukę w EPG: {diff} sekund.", xbmc.LOGDEBUG)
            return True
        return False