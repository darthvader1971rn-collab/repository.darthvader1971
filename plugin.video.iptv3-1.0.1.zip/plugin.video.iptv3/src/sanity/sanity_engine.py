# -*- coding: utf-8 -*-
import xbmc
import re

class SanityEngine:
    """
    Silnik Spójności (Sanity Engine).
    Główny moduł weryfikujący poprawność struktur danych w locie.
    Chroni system przed awariami spowodowanymi błędnymi danymi wejściowymi.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano SanityEngine - Strażnik Spójności aktywny.", xbmc.LOGINFO)

    def validate_channel_data(self, channel_dict):
        """
        Sprawdza, czy obiekt kanału posiada wszystkie wymagane pola
        i czy nie są one puste.
        """
        required_keys = ['name', 'stream_url', 'channel_id']
        for key in required_keys:
            if key not in channel_dict or not channel_dict[key]:
                xbmc.log(f"[IPTV3] Sanity: Brak kluczowego pola '{key}' w danych kanału!", xbmc.LOGWARNING)
                return False
        return True

    def check_url_integrity(self, url):
        """
        Weryfikuje, czy URL strumienia ma poprawną strukturę (http/https/rtmp).
        """
        if not url or not isinstance(url, str):
            return False
            
        pattern = re.compile(r'^(http|https|rtmp|rtsp)://', re.IGNORECASE)
        if not pattern.match(url):
            xbmc.log(f"[IPTV3] Sanity: Wykryto niebezpieczny lub błędny URL: {url}", xbmc.LOGERROR)
            return False
        return True

    def perform_system_check(self):
        """
        Globalny test "zdrowia" wtyczki. Sprawdza połączenie z kluczowymi 
        modułami i dostępność zasobów systemowych.
        """
        # Tutaj w przyszłości dodamy testy zajętości pamięci lub miejsca na dysku
        xbmc.log("[IPTV3] Sanity: System Check - Status: OK", xbmc.LOGDEBUG)
        return True

    def sanitize_string(self, text):
        """
        Oczyszcza teksty (np. tytuły programów) z ukrytych znaków sterujących,
        które mogłyby "rozbić" interfejs Kodi.
        """
        if not text:
            return ""
        return "".join(char for char in text if ord(char) >= 32)