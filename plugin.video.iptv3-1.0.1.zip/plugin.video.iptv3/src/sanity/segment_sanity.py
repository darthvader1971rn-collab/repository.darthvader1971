# -*- coding: utf-8 -*-
import xbmc

class SegmentSanity:
    """
    Weryfikator segmentów (Segment Sanity).
    Sprawdza ciągłość i poprawność techniczną fragmentów strumienia (HLS/DASH).
    Zapobiega błędom "skaczącego" obrazu i przerwom w transmisji.
    """
    
    def __init__(self):
        self.last_sequence = -1
        xbmc.log("[IPTV3] Zainicjowano SegmentSanity - Monitoring ciągłości aktywny.", xbmc.LOGINFO)

    def check_continuity(self, sequence_number):
        """
        Sprawdza, czy kolejny segment ma poprawny numer sekwencyjny.
        
        :param sequence_number: Numer aktualnego segmentu
        :return: True jeśli zachowana jest ciągłość, False w przypadku "dziury"
        """
        if self.last_sequence == -1:
            # Pierwszy segment w sesji
            self.last_sequence = sequence_number
            return True
            
        expected = self.last_sequence + 1
        if sequence_number != expected:
            xbmc.log(f"[IPTV3] Sanity ALERT: Brak ciągłości! Oczekiwano: {expected}, Otrzymano: {sequence_number}", xbmc.LOGWARNING)
            self.last_sequence = sequence_number
            return False
            
        self.last_sequence = sequence_number
        return True

    def verify_segment_size(self, size_bytes):
        """
        Sprawdza, czy pobrany segment nie jest podejrzanie mały lub pusty.
        """
        min_size = 1024 # Minimum 1KB dla poprawnego fragmentu wideo
        if size_bytes < min_size:
            xbmc.log(f"[IPTV3] Sanity: Wykryto pusty lub uszkodzony segment ({size_bytes} bajtów).", xbmc.LOGERROR)
            return False
        return True

    def reset_monitor(self):
        """Resetuje stan monitoringu (np. przy przełączeniu kanału)."""
        self.last_sequence = -1
        xbmc.log("[IPTV3] SegmentSanity: Reset monitora ciągłości.", xbmc.LOGDEBUG)