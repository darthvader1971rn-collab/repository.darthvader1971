# -*- coding: utf-8 -*-
import xbmc

class AudioSyncEngine:
    """
    Moduł precyzyjnej synchronizacji audio (Audio Sync Engine).
    Automatycznie koryguje opóźnienia dźwięku względem obrazu 
    w celu eliminacji efektu braku synchronizacji.
    """
    
    def __init__(self):
        # Domyślne przesunięcie (0.0 = brak korekty)
        self.current_delay = 0.0
        xbmc.log("[IPTV3] Zainicjowano moduł AudioSyncEngine", xbmc.LOGINFO)

    def set_audio_delay(self, delay_seconds):
        """
        Ustawia przesunięcie audio bezpośrednio w odtwarzaczu Kodi.
        
        :param delay_seconds: Opóźnienie w sekundach (np. 0.5 lub -0.5)
        """
        self.current_delay = delay_seconds
        # Wywołanie systemowej komendy Kodi do zmiany opóźnienia audio
        xbmc.executebuiltin(f"AudioDelay({delay_seconds})")
        xbmc.log(f"[IPTV3] AudioSyncEngine: Ustawiono opóźnienie dźwięku na {delay_seconds}s", xbmc.LOGDEBUG)

    def auto_correct(self, drift_value):
        """
        Automatycznie koryguje synchronizację na podstawie wykrytego dryfu.
        
        :param drift_value: Wartość dryfu przekazana z modułu DriftCorrection
        """
        # Jeśli dryf jest znaczący, aplikujemy korektę
        if abs(drift_value) > 0.1:
            # Przykładowa logika: odwracamy dryf, aby wyrównać poziomy
            new_delay = -drift_value
            self.set_audio_delay(new_delay)
            xbmc.log(f"[IPTV3] AudioSyncEngine: Wykonano autokorektę o {new_delay}s", xbmc.LOGINFO)

    def reset_sync(self):
        """Resetuje wszelkie przesunięcia audio do stanu początkowego (0s)."""
        self.set_audio_delay(0.0)
        xbmc.log("[IPTV3] AudioSyncEngine: Zresetowano synchronizację audio.", xbmc.LOGDEBUG)

    def get_current_delay(self):
        """Zwraca aktualnie ustawione opóźnienie."""
        return self.current_delay