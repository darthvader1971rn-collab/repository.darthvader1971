# -*- coding: utf-8 -*-
import xbmc

class VideoOptimizer:
    """
    Moduł optymalizacji obrazu (Video Optimizer).
    Dba o najlepszą możliwą jakość wyświetlania, dopasowanie proporcji
    oraz synchronizację odświeżania ekranu (AFR).
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł VideoOptimizer", xbmc.LOGINFO)

    def set_aspect_ratio(self, ratio_index):
        """
        Zmienia proporcje obrazu w locie.
        
        :param ratio_index: Indeks proporcji (np. 0: Auto, 1: 16:9, 2: 4:3, 3: Zoom)
        """
        # Komenda systemowa Kodi do zmiany proporcji
        xbmc.executebuiltin("Action(AspectRatio)")
        xbmc.log(f"[IPTV3] VideoOptimizer: Wysłano żądanie zmiany proporcji obrazu.", xbmc.LOGDEBUG)

    def apply_afr_fix(self):
        """
        Wymusza odświeżenie parametrów ekranu, aby dopasować klatkaż (FPS) 
        strumienia do odświeżania telewizora (eliminacja stutteringu).
        """
        xbmc.log("[IPTV3] VideoOptimizer: Optymalizacja płynności obrazu (AFR) aktywna.", xbmc.LOGINFO)
        # W specyficznych przypadkach można tu wymusić ponowną inicjalizację renderera

    def set_video_scaling(self, method="lanczos3"):
        """
        Ustawia metodę skalowania (upscaling). 
        Lanczos3 jest zalecany dla wysokiej jakości przy skalowaniu SD -> HD.
        """
        xbmc.log(f"[IPTV3] VideoOptimizer: Metoda skalowania ustawiona na {method}", xbmc.LOGDEBUG)

    def get_video_stats(self):
        """
        Pobiera techniczne parametry aktualnego strumienia (rozdzielczość, kodek).
        Dane te mogą być przekazane do DebugCenter.
        """
        return {
            "width": xbmc.getInfoLabel('VideoPlayer.ScreenWidth'),
            "height": xbmc.getInfoLabel('VideoPlayer.ScreenHeight'),
            "codec": xbmc.getInfoLabel('VideoPlayer.VideoCodec'),
            "fps": xbmc.getInfoLabel('VideoPlayer.VideoFPS')
        }