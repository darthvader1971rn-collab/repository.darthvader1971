# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class PlayerEngine(xbmc.Player):
    """
    Główny silnik odtwarzacza (Player Engine 3.0).
    Zarządza procesem odtwarzania, obsługuje zdarzenia systemowe 
    oraz integruje się z modułami Timeline i OSD.
    """
    
    def __init__(self):
        super(PlayerEngine, self).__init__()
        self.is_active = False
        xbmc.log("[IPTV3] Zainicjowano moduł PlayerEngine", xbmc.LOGINFO)

    def play_stream(self, url, listitem):
        """
        Uruchamia odtwarzanie strumienia pod wskazanym adresem.
        
        :param url: Bezpośredni link do strumienia (rozwiązany przez CdnEngine)
        :param listitem: Obiekt ListItem z metadanymi (zbudowany przez MenuBuilder)
        """
        # --- ZABEZPIECZENIE PRZED BLOKADĄ SERWERA ---
        # Doklejamy tylko User-Agent. ŚWIADOMIE REZYGNUJEMY z inputstream.adaptive, 
        # aby uniknąć błędów certyfikatów SSL (Error 60) na Windowsie.
        if url.startswith(('http://', 'https://')):
            if '|User-Agent=' not in url:
                ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                url = f"{url}|User-Agent={ua}"
        # --- KONIEC ZABEZPIECZENIA ---

        xbmc.log(f"[IPTV3] PlayerEngine: Próba uruchomienia strumienia: {url}", xbmc.LOGINFO)
        self.play(url, listitem)
        self.is_active = True

    def onPlayBackStarted(self):
        """Wywoływane automatycznie przez Kodi, gdy strumień faktycznie ruszy."""
        xbmc.log("[IPTV3] PlayerEngine: Odtwarzanie rozpoczęte pomyślnie.", xbmc.LOGINFO)
        # Tutaj w przyszłości wyślemy sygnał do OsdManager, aby pokazał info o kanale

    def onPlayBackStopped(self):
        """Wywoływane, gdy użytkownik zatrzyma odtwarzanie."""
        xbmc.log("[IPTV3] PlayerEngine: Odtwarzanie zatrzymane.", xbmc.LOGINFO)
        self.is_active = False

    def onPlayBackError(self):
        """Wywoływane w przypadku awarii strumienia lub problemów z siecią."""
        xbmc.log("[IPTV3] PlayerEngine: Krytyczny błąd odtwarzania!", xbmc.LOGERROR)
        self.is_active = False
        
        # Powiadomienie użytkownika o błędzie
        xbmcgui.Dialog().notification("Błąd wideo", "Nie udało się otworzyć strumienia.", xbmcgui.NOTIFICATION_ERROR, 5000)

    def get_playback_time(self):
        """Zwraca aktualny czas odtwarzania w sekundach."""
        if self.isPlaying():
            return self.getTime()
        return 0