# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class BufferManager:
    """
    Menedżer buforowania (Buffer Manager).
    Implementuje Anti-Stutter Logic w celu zapewnienia płynności 
    odtwarzania przy niestabilnych połączeniach sieciowych.
    """
    
    def __init__(self):
        self.is_buffering = False
        xbmc.log("[IPTV3] Zainicjowano moduł BufferManager", xbmc.LOGINFO)

    def optimize_settings(self, cache_size_mb=100):
        """
        Dostosowuje zaawansowane parametry buforowania Kodi.
        
        :param cache_size_mb: Rozmiar bufora w megabajtach (pobierany z ustawień)
        """
        # Wartość w bajtach dla silnika Kodi
        buffer_bytes = cache_size_mb * 1024 * 1024
        xbmc.log(f"[IPTV3] BufferManager: Optymalizacja rozmiaru cache: {cache_size_mb}MB", xbmc.LOGDEBUG)
        
        # Ustawienie właściwości, które mogą być odczytane przez InputStream.Adaptive
        xbmcgui.Window(10000).setProperty('IPTV3.BufferSize', str(buffer_bytes))

    def monitor_fill_level(self):
        """
        Monitoruje poziom wypełnienia bufora w czasie rzeczywistym.
        Zwraca procentową wartość (0-100).
        """
        try:
            fill_level = xbmc.getInfoLabel('Player.BufferLevel')
            return int(fill_level.replace('%', '')) if fill_level else 100
        except:
            return 100

    def handle_low_bandwidth(self):
        """
        Reaguje na krytycznie niski poziom bufora.
        Może wymusić krótką pauzę, aby pozwolić na doładowanie danych.
        """
        current_fill = self.monitor_fill_level()
        
        if current_fill < 5 and not self.is_buffering:
            xbmc.log("[IPTV3] BufferManager: Wykryto krytyczny poziom bufora. Aktywacja Anti-Stutter Logic.", xbmc.LOGWARNING)
            self.is_buffering = True
            # Możliwość wywołania pauzy systemowej: xbmc.executebuiltin("PlayerControl(Pause)")
            return True
            
        if current_fill > 80 and self.is_buffering:
            xbmc.log("[IPTV3] BufferManager: Bufor odbudowany. Wznowienie.", xbmc.LOGINFO)
            self.is_buffering = False
            
        return False

    def get_status(self):
        """Zwraca słownik ze statystykami buforowania dla DebugCenter."""
        return {
            "Buffer Fill": f"{self.monitor_fill_level()}%",
            "Anti-Stutter Active": "TAK" if self.is_buffering else "NIE"
        }