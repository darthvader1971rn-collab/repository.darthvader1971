# -*- coding: utf-8 -*-
import xbmc

class CdnEngine:
    """
    Moduł odpowiedzialny za zarządzanie ruchem i routingiem (CDN Engine).
    Pozwala na optymalizację połączenia poprzez wymuszanie konkretnych serwerów
    oraz obsługę dynamicznych przekierowań strumieni.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł CdnEngine", xbmc.LOGINFO)

    def resolve_url(self, raw_url, routing_preference=0):
        """
        Modyfikuje adres strumienia w zależności od preferencji regionalnych użytkownika.
        
        :param raw_url: Surowy adres URL przypisany do kanału przez Providera
        :param routing_preference: Wartość z settings.xml (0: Auto, 1: Force EU, 2: Force US)
        :return: Zoptymalizowany adres URL gotowy dla odtwarzacza
        """
        if not raw_url:
            return None
            
        xbmc.log(f"[IPTV3] CdnEngine: Próba optymalizacji URL (Routing pref: {routing_preference})", xbmc.LOGDEBUG)
        
        # Tworzymy kopię url do modyfikacji
        optimized_url = raw_url
        
        # Docelowo znajdzie się tutaj mechanizm, który np. podmienia główną domenę
        # dostawcy na domenę regionalną, jeśli dostawca taką obsługuje.
        # Przykład: 
        # if routing_preference == 1:
        #     optimized_url = raw_url.replace("auto.provider.tv", "eu.provider.tv")
        
        return optimized_url

    def handle_redirects(self, url):
        """
        Sprawdza adres URL pod kątem ukrytych przekierowań (np. kod HTTP 301/302).
        Odtwarzacze takie jak Kodi czasem gubią się przy skomplikowanych łańcuchach przekierowań,
        więc ten moduł "odwinie" link do ostatecznego pliku wideo (.m3u8 / .ts).
        
        :param url: Wejściowy adres URL
        :return: Ostateczny, bezpośredni adres do strumienia
        """
        # Miejsce na implementację zapytań HEAD/GET wyciągających nagłówek 'Location'
        return url