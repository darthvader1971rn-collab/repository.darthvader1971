# -*- coding: utf-8 -*-
import xbmc
import time

class TokenValidator:
    """
    Weryfikator tokenów (Token Validator).
    Sprawdza ważność kluczy sesji i automatycznie inicjuje 
    ich odświeżanie przed wygaśnięciem.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano TokenValidator", xbmc.LOGINFO)

    def is_token_valid(self, token_data):
        """
        Sprawdza, czy token jest technicznie poprawny i czy nie wygasł.
        """
        if not token_data or 'exp' not in token_data:
            return False
            
        # Sprawdzamy czy do wygaśnięcia zostało więcej niż 5 minut (300 sek)
        now = int(time.time())
        if token_data['exp'] - now < 300:
            xbmc.log("[IPTV3] Security: Token wygaśnie lada moment. Wymagane odświeżenie.", xbmc.LOGWARNING)
            return False
            
        return True