# -*- coding: utf-8 -*-
import xbmc

class DrmHandler:
    """
    Obsługa systemów DRM (Digital Rights Management).
    Konfiguruje parametry dla InputStream.Adaptive, umożliwiając 
    odtwarzanie treści zabezpieczonych (Widevine, PlayReady).
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł DrmHandler", xbmc.LOGINFO)

    def get_license_config(self, drm_type, license_url):
        """
        Przygotowuje słownik konfiguracji DRM dla ListItem.
        
        :param drm_type: Typ DRM (np. 'widevine', 'playready')
        :param license_url: URL do serwera licencji
        """
        if not license_url:
            return {}

        # Mapowanie typów DRM na protokoły akceptowane przez Kodi
        drm_map = {
            'widevine': 'com.widevine.alpha',
            'playready': 'com.microsoft.playready'
        }

        config = {
            'inputstream.adaptive.manifest_type': 'mpd',
            'inputstream.adaptive.license_type': drm_map.get(drm_type.lower(), ''),
            'inputstream.adaptive.license_key': license_url + '||R{SSM}|'
        }
        
        xbmc.log(f"[IPTV3] DrmHandler: Skonfigurowano licencję {drm_type}", xbmc.LOGDEBUG)
        return config