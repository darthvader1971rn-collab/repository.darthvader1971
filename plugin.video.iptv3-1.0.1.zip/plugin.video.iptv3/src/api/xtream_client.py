# -*- coding: utf-8 -*-
import xbmc
import json
from src.utils.network_utils import NetworkUtils

class XtreamClient:
    """
    Klient API dla serwerów Xtream Codes.
    Obsługuje logowanie, pobieranie list odtwarzania oraz metadanych 
    bezpośrednio z panelu dostawcy.
    """
    
    def __init__(self, base_url, username, password):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.network = NetworkUtils()
        self.api_url = f"{self.base_url}/player_api.php"
        xbmc.log(f"[IPTV3] Zainicjowano XtreamClient dla: {self.base_url}", xbmc.LOGINFO)

    def authenticate(self):
        """
        Sprawdza poprawność danych logowania i pobiera informacje o koncie.
        """
        url = f"{self.api_url}?username={self.username}&password={self.password}"
        response = self.network.get_data(url)
        
        if response:
            try:
                data = json.loads(response)
                # Sprawdzamy czy w odpowiedzi są dane użytkownika (auth=1)
                if data.get('user_info', {}).get('auth') == 1:
                    xbmc.log("[IPTV3] XtreamClient: Autoryzacja udana.", xbmc.LOGINFO)
                    return data
            except Exception as e:
                xbmc.log(f"[IPTV3] XtreamClient: Błąd dekodowania JSON: {str(e)}", xbmc.LOGERROR)
        
        xbmc.log("[IPTV3] XtreamClient: Autoryzacja nieudana.", xbmc.LOGWARNING)
        return None

    def get_live_categories(self):
        """Pobiera listę kategorii telewizji na żywo."""
        url = f"{self.api_url}?username={self.username}&password={self.password}&action=get_live_categories"
        response = self.network.get_data(url)
        return json.loads(response) if response else []

    def get_live_streams(self, category_id=None):
        """
        Pobiera listę kanałów (wszystkich lub z konkretnej kategorii).
        """
        url = f"{self.api_url}?username={self.username}&password={self.password}&action=get_live_streams"
        if category_id:
            url += f"&category_id={category_id}"
            
        response = self.network.get_data(url)
        return json.loads(response) if response else []

    def get_vod_streams(self, category_id=None):
        """Pobiera listę filmów VOD."""
        url = f"{self.api_url}?username={self.username}&password={self.password}&action=get_vod_streams"
        if category_id:
            url += f"&category_id={category_id}"
            
        response = self.network.get_data(url)
        return json.loads(response) if response else []