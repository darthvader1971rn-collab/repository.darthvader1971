# -*- coding: utf-8 -*-
import os
import json
import time
import re
import urllib.parse
import xbmc
import xbmcaddon

class TmdbScraper:
    """
    Moduł do pobierania okładek i opisów z The Movie Database (TMDb).
    Posiada wbudowany system pamięci podręcznej (Cache), aby oszczędzać API.
    """

    def __init__(self, profile_path):
        self.addon = xbmcaddon.Addon()
        # Pobieramy klucz z ustawień wtyczki
        self.api_key = self.addon.getSetting("tmdb_api_key") 
        
        # Folder na pobrane opisy (żeby nie pobierać dwa razy tego samego)
        self.cache_dir = os.path.join(profile_path, "tmdb_cache")
        if not os.path.exists(self.cache_dir):
            try:
                os.makedirs(self.cache_dir)
            except Exception as e:
                xbmc.log(f"[IPTV3] Błąd tworzenia folderu cache TMDb: {e}", xbmc.LOGERROR)

    def _clean_title(self, title):
        """Czyści tytuł ze śmieci typu [VOD], FHD, NAPISY, PL:, PO: itp."""
        if not title: return ""
        
        # 1. Usuwa wszystko w nawiasach [] i () np. [VOD], (2023)
        clean = re.sub(r'\[.*?\]|\(.*?\)', '', title)
        
        # 2. Usuwa przedrostki typu "PL:", "PO:", "PL ", "PO " z samego początku tytułu
        clean = re.sub(r'^(?i)(pl|po)[\s:\-]+', '', clean)
        
        # 3. Usuwa osierocone myślniki i dwukropki na samym początku
        clean = re.sub(r'^[\-:]\s*', '', clean)
        
        # 4. Usuwa popularne tagi techniczne ze środka i końca tytułu
        clean = re.sub(r'(?i)\b(fhd|hd|4k|1080p|720p|vod|pl|multisub|dubbing|lektor|napisy)\b', '', clean)
        
        # 5. Zastępuje wielokrotne spacje pojedynczą i usuwa białe znaki na końcach
        return ' '.join(clean.split())

    def get_movie_info(self, raw_title, use_network=True):
        """Pobiera dane o filmie. Udaje przeglądarkę Chrome, aby ominąć blokady API."""
        if not self.api_key:
            return None
            
        clean_title = self._clean_title(raw_title)
        if not clean_title or len(clean_title) < 2:
            return None
            
        safe_filename = "".join([c for c in clean_title if c.isalpha() or c.isdigit() or c==' ']).rstrip()
        cache_file = os.path.join(self.cache_dir, f"{safe_filename}.json")
        
        # 1. SPRAWDZANIE CACHE
        if os.path.exists(cache_file):
            if (time.time() - os.path.getmtime(cache_file)) < 2592000: # 30 dni
                try:
                    with open(cache_file, 'r', encoding='utf-8') as f:
                        return json.load(f)
                except Exception:
                    pass

        if not use_network:
            return None

        # 2. POBIERANIE (Z OSZUSTWEM USER-AGENT)
        xbmc.log(f"[IPTV3] TMDb: Szukam danych dla: {clean_title}", xbmc.LOGINFO)
        try:
            import requests
            import urllib.parse
            api_key_clean = self.api_key.strip()
            query_encoded = urllib.parse.quote(clean_title)
            
            # Udajemy Chrome na Windows 10
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
            
            search_urls = [
                f"https://api.themoviedb.org/3/search/movie?api_key={api_key_clean}&query={query_encoded}&language=pl-PL",
                f"https://api.themoviedb.org/3/search/multi?api_key={api_key_clean}&query={query_encoded}&language=pl-PL",
                f"https://api.themoviedb.org/3/search/movie?api_key={api_key_clean}&query={query_encoded}",
                f"https://api.themoviedb.org/3/search/multi?api_key={api_key_clean}&query={query_encoded}"
            ]
            
            movie = None
            api_error = False
            
            for url in search_urls:
                resp = requests.get(url, headers=headers, timeout=5)
                
                # Jeśli błąd autoryzacji lub limit zapytań
                if resp.status_code != 200:
                    xbmc.log(f"[IPTV3] TMDb BŁĄD API {resp.status_code} dla: {clean_title}", xbmc.LOGERROR)
                    api_error = True
                    continue # Próbuj następnego URL, chociaż pewnie też wywali błąd
                    
                data_json = resp.json()
                if 'results' in data_json and len(data_json['results']) > 0:
                    for item in data_json['results']:
                        media_type = item.get('media_type', 'movie')
                        if media_type in ['movie', 'tv']:
                            movie = item
                            break
                    if movie:
                        break # Znaleziono, przerywamy szukanie
            
            # 3. ZAPISYWANIE WYNIKÓW
            if movie:
                title = movie.get('title') or movie.get('name') or clean_title
                plot = movie.get('overview', 'Brak szczegółowego opisu w TMDb.')
                poster_path = movie.get('poster_path')
                backdrop_path = movie.get('backdrop_path')
                date = movie.get('release_date') or movie.get('first_air_date') or ''
                
                data = {
                    'title': title,
                    'plot': plot,
                    'poster': f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else "",
                    'fanart': f"https://image.tmdb.org/t/p/w1280{backdrop_path}" if backdrop_path else "",
                    'rating': movie.get('vote_average', 0.0),
                    'year': str(date)[:4] if date else ""
                }
                
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                return data
                
            elif not api_error:
                # Tylko jeśli API odpowiedziało poprawnie, ale fizycznie nie znalazło filmu
                xbmc.log(f"[IPTV3] TMDb: Faktyczny brak wyników dla '{clean_title}'.", xbmc.LOGINFO)
                empty_data = {'title': clean_title, 'plot': 'Film niedostępny w bazie TMDb.'}
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump(empty_data, f, ensure_ascii=False)
                return empty_data
            else:
                xbmc.log(f"[IPTV3] TMDb: Blokada zapisu pustego cache dla '{clean_title}' ze wzgledu na blad API.", xbmc.LOGWARNING)
                
        except Exception as e:
            xbmc.log(f"[IPTV3] TMDb: Blad polaczenia dla '{clean_title}': {e}", xbmc.LOGERROR)
            
        return None