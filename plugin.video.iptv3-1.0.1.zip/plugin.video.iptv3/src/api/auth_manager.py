# -*- coding: utf-8 -*-
import xbmc
from api.xtream_client import XtreamClient
from api.stalker_client import StalkerClient
from utils.config_handler import ConfigHandler


class AuthManager:
    """
    Menedżer autoryzacji (Auth Manager).
    Odpowiada za wybór odpowiedniego protokołu komunikacji (M3U/Xtream/Stalker)
    oraz zarządzanie sesjami użytkownika.
    """

    def __init__(self):
        self.config = ConfigHandler()
        self.client = None
        self.provider_type = self.config.get_string('provider_type')  # 0:M3U, 1:Xtream, 2:Stalker
        xbmc.log(f"[IPTV3] Zainicjowano AuthManager. Typ dostawcy: {self.provider_type}", xbmc.LOGINFO)

    def get_client(self):
        """
        Inicjalizuje i zwraca odpowiedniego klienta API na podstawie ustawień.
        """
        if self.client:
            return self.client

        if self.provider_type == "1":  # Xtream Codes
            url = self.config.get_string('xtream_url')
            user = self.config.get_string('xtream_user')
            password = self.config.get_string('xtream_pass')
            self.client = XtreamClient(url, user, password)

        elif self.provider_type == "2":  # Stalker Portal
            url = self.config.get_string('stalker_url')
            mac = self.config.get_string('stalker_mac')
            self.client = StalkerClient(url, mac)

        return self.client

    def login(self):
        xbmc.log("[IPTV3] AuthManager.login() start", xbmc.LOGINFO)

        # --- Pobranie klienta ---
        try:
            client = self.get_client()
            xbmc.log(f"[IPTV3] Client: {client}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[IPTV3] WYJĄTEK w get_client(): {e}", xbmc.LOGERROR)
            return False

        # --- Tryb M3U ---
        if not client:
            xbmc.log("[IPTV3] Tryb M3U – logowanie pominięte", xbmc.LOGINFO)
            return True

        # --- Logowanie Xtream ---
        try:
            if isinstance(client, XtreamClient):
                xbmc.log("[IPTV3] Logowanie Xtream...", xbmc.LOGINFO)
                result = client.authenticate()
                xbmc.log(f"[IPTV3] Wynik authenticate(): {result}", xbmc.LOGINFO)
                return result is not None

            # --- Logowanie Stalker ---
            elif isinstance(client, StalkerClient):
                xbmc.log("[IPTV3] Logowanie Stalker...", xbmc.LOGINFO)
                result = client.do_handshake()
                xbmc.log(f"[IPTV3] Wynik handshake(): {result}", xbmc.LOGINFO)
                return result

        except Exception as e:
            xbmc.log(f"[IPTV3] WYJĄTEK podczas logowania: {e}", xbmc.LOGERROR)
            return False

        return False

    def is_session_valid(self):
        """
        Sprawdza, czy obecna sesja jest nadal aktywna.
        """
        if isinstance(self.client, StalkerClient):
            return self.client.token is not None
        return True
