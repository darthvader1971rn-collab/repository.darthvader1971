# -*- coding: utf-8 -*-
import xbmc
import json
from utils.network_utils import NetworkUtils

class StalkerClient:
    """
    Klient API dla portalów Stalker (Middleware).
    Obsługuje autoryzację opartą na adresach MAC oraz komunikację 
    z serwerami typu Ministra/Stalker.
    """
    
    def __init__(self, portal_url, mac_address):
        self.portal_url = portal_url.rstrip('/')
        self.mac = mac_address
        self.network = NetworkUtils()
        self.token = None
        self.api_url = f"{self.portal_url}/server/load.php"
        xbmc.log(f"[IPTV3] Zainicjowano StalkerClient dla MAC: {self.mac}", xbmc.LOGINFO)

    def _get_common_headers(self):
        """Generuje nagłówki wymagane przez portale Stalker."""
        headers = {
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 sb2 embedded Safari/533.3',
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'Cookie': f'mac={self.mac};'
        }
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        return headers

    def do_handshake(self):
        """Inicjalizuje sesję z portalem (handshake)."""
        url = f"{self.api_url}?type=stb&action=handshake"
        response = self.network.get_data(url, headers=self._get_common_headers())
        
        if response:
            try:
                data = json.loads(response)
                # Wyciągamy token sesji z odpowiedzi
                self.token = data.get('js', {}).get('token')
                if self.token:
                    xbmc.log(f"[IPTV3] StalkerClient: Uzyskano token sesji.", xbmc.LOGINFO)
                    return True
            except Exception as e:
                xbmc.log(f"[IPTV3] StalkerClient: Błąd handshake: {str(e)}", xbmc.LOGERROR)
        
        return False

    def get_profile(self):
        """Pobiera profil użytkownika i informacje o subskrypcji."""
        url = f"{self.api_url}?type=stb&action=get_profile"
        response = self.network.get_data(url, headers=self._get_common_headers())
        return json.loads(response) if response else {}

    def get_all_channels(self):
        """Pobiera pełną listę kanałów z portalu."""
        url = f"{self.api_url}?type=itv&action=get_all_channels"
        response = self.network.get_data(url, headers=self._get_common_headers())
        
        if response:
            try:
                data = json.loads(response)
                return data.get('js', {}).get('data', [])
            except:
                return []
        return []

    def get_link(self, cmd):
        """
        Pobiera bezpośredni link do strumienia dla konkretnego kanału.
        
        :param cmd: Komenda/ID kanału (np. 'ffrt http://...')
        """
        url = f"{self.api_url}?type=itv&action=create_link&cmd={cmd}"
        response = self.network.get_data(url, headers=self._get_common_headers())
        
        if response:
            try:
                data = json.loads(response)
                return data.get('js', {}).get('cmd')
            except:
                return None
        return None