# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon

class ChannelEditorWindow(xbmcgui.WindowXML):
    """
    Okno edytora kanałów i grup.
    Umożliwia zmianę kolejności (sort_index), przypisywanie do grup i zarządzanie ulubionymi.
    """
    def __init__(self, *args, **kwargs):
        super(ChannelEditorWindow, self).__init__(*args, **kwargs)
        self.engine = kwargs.get('engine')
        self.group_list = None
        self.channel_list = None
        self.current_group = None
        self.channels = []
        self.addon = xbmcaddon.Addon()

    def onInit(self):
        xbmc.log("[IPTV3] ChannelEditorWindow: Inicjalizacja...", xbmc.LOGINFO)
        self.group_list = self.getControl(100) # ID listy grup (lewa strona)
        self.channel_list = self.getControl(200) # ID listy kanałów (prawa strona)

        # Załaduj grupy przy starcie
        self.load_groups()

    def load_groups(self):
        """Pobiera i wyświetla listę grup z bazy."""
        if not self.group_list:
            return

        self.group_list.reset()
        
        # Specjalna grupa dla ulubionych
        li_fav = xbmcgui.ListItem(label="⭐ Ulubione")
        li_fav.setProperty("group_name", "__FAVORITES__")
        self.group_list.addItem(li_fav)

        # Pobieranie grup z bazy
        query = "SELECT DISTINCT group_name FROM channels WHERE group_name IS NOT NULL AND group_name != '' ORDER BY group_name ASC"
        try:
            rows = self.engine.db.fetch_all(query)
            for row in rows:
                group_name = row["group_name"]
                li = xbmcgui.ListItem(label=group_name)
                li.setProperty("group_name", group_name)
                self.group_list.addItem(li)
        except Exception as e:
            xbmc.log(f"[IPTV3] ChannelEditorWindow: Błąd ładowania grup: {e}", xbmc.LOGERROR)

        # Domyślnie zaznacz pierwszą grupę (lub Ulubione, jeśli to pierwsza pozycja) i załaduj jej kanały
        if self.group_list.size() > 0:
            self.group_list.selectItem(0)
            self.on_group_selected()

    def load_channels(self, group_name):
        """Pobiera i wyświetla kanały dla wybranej grupy z dynamiczną numeracją."""
        if not self.channel_list:
            return

        self.channel_list.reset()
        self.channels = []
        self.current_group = group_name

        query = "SELECT * FROM channels"
        params = []

        # Wybieramy kolumnę sortowania w zależności od tego, czy jesteśmy w Ulubionych
        if group_name == "__FAVORITES__":
            query += " WHERE is_favorite = 1 ORDER BY fav_sort_index ASC"
            col_idx = "fav_sort_index"
        elif group_name:
            query += " WHERE group_name = ? ORDER BY sort_index ASC"
            params.append(group_name)
            col_idx = "sort_index"
        else:
            query += " ORDER BY sort_index ASC"
            col_idx = "sort_index"

        try:
            rows = self.engine.db.fetch_all(query, tuple(params))
            for row in rows:
                channel = dict(row)
                self.channels.append(channel)
                
                name = channel.get("name", "Nieznany")
                is_fav = channel.get("is_favorite", 0)
                display_name = f"⭐ {name}" if is_fav == 1 else name
                
                li = xbmcgui.ListItem(label=display_name)
                li.setProperty("channel_id", str(channel.get("channel_id", "")))
                
                # POPRAWKA: Wyświetlamy numer z właściwej kolumny (ogólny LUB ulubiony)
                li.setLabel2(str(channel.get(col_idx, "")))
                
                self.channel_list.addItem(li)
        except Exception as e:
            xbmc.log(f"[IPTV3] ChannelEditorWindow: Błąd ładowania kanałów: {e}", xbmc.LOGERROR)

    def on_group_selected(self):
        """Obsługa zmiany zaznaczenia na liście grup."""
        selected_item = self.group_list.getSelectedItem()
        if selected_item:
            group_name = selected_item.getProperty("group_name")
            self.load_channels(group_name)

    def onAction(self, action):
        """Obsługa nawigacji."""
        action_id = action.getId()
        
        # Zamknięcie okna
        if action_id in (9, 10, 92):
            self.close()
            
        # Nawigacja - jeśli zmienimy grupę, odświeżamy listę kanałów
        elif action_id in (1, 2, 3, 4):
            xbmc.sleep(50) # Krótkie opóźnienie dla pewności, że kursor się przesunął
            focused_id = self.getFocusId()
            if focused_id == 100: # Lista grup
                self.on_group_selected()
                
        # Menu kontekstowe (edycja)
        elif action_id in (117, 101):
            focused_id = self.getFocusId()
            if focused_id == 200: # Edycja tylko na liście kanałów
                self.handle_context_menu()

    def handle_context_menu(self):
        """Menu opcji edycji dla konkretnego kanału."""
        selected_pos = self.channel_list.getSelectedPosition()
        if selected_pos < 0 or selected_pos >= len(self.channels):
            return

        channel = self.channels[selected_pos]
        channel_id = channel['channel_id']
        current_name = channel.get('name', 'Nieznany')
        
        options = [
            "Przesuń w górę",
            "Przesuń w dół",
            "Zmień pozycję (wpisz numer)",
            "Przenieś do innej grupy",
            "⭐ Dodaj / Usuń z Ulubionych"
        ]
        
        dialog = xbmcgui.Dialog()
        ret = dialog.contextmenu(options)
        
        if ret == 0:
            self.move_channel(selected_pos, -1)
        elif ret == 1:
            self.move_channel(selected_pos, 1)
        elif ret == 2:
            self.change_position_manual(channel_id, current_name)
        elif ret == 3:
            self.change_group(channel_id, current_name)
        elif ret == 4:
            self.toggle_favorite(channel_id)

    # --- FUNKCJE EDYCJI ---

    def move_channel(self, current_pos, direction):
        """Przesuwa kanał o 1 pozycję w górę (-1) lub w dół (+1)."""
        new_pos = current_pos + direction
        
        # Sprawdzamy granice listy
        if new_pos < 0 or new_pos >= len(self.channels):
            return

        # Pobieramy dane obu kanałów
        ch1 = self.channels[current_pos]
        ch2 = self.channels[new_pos]

        id1 = ch1['channel_id']
        idx1 = ch1['sort_index']
        
        id2 = ch2['channel_id']
        idx2 = ch2['sort_index']

        # Zamieniamy ich sort_index w bazie
        try:
            self.engine.db.execute_query("UPDATE channels SET sort_index = ? WHERE channel_id = ?", (idx2, id1))
            self.engine.db.execute_query("UPDATE channels SET sort_index = ? WHERE channel_id = ?", (idx1, id2))
            
            # Odświeżamy listę i przywracamy zaznaczenie
            self.load_channels(self.current_group)
            self.channel_list.selectItem(new_pos)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd podczas przesuwania kanału: {e}", xbmc.LOGERROR)

    def change_position_manual(self, channel_id, channel_name):
        """Zmiana pozycji na konkretny numer wpisany z klawiatury."""
        dialog = xbmcgui.Dialog()
        new_pos_str = dialog.numeric(0, f"Podaj nowy numer dla: {channel_name}")
        
        if new_pos_str:
            try:
                new_pos = int(new_pos_str)
                # Robimy "lukę" przesuwając inne kanały w dół
                self.engine.db.execute_query("UPDATE channels SET sort_index = sort_index + 1 WHERE sort_index >= ?", (new_pos,))
                # Wstawiamy nasz kanał
                self.engine.db.execute_query("UPDATE channels SET sort_index = ? WHERE channel_id = ?", (new_pos, channel_id))
                
                self.load_channels(self.current_group)
                xbmcgui.Dialog().notification("IPTV 3.0", f"Zmieniono pozycję na: {new_pos}", xbmcgui.NOTIFICATION_INFO, 2000)
            except Exception as e:
                 xbmc.log(f"[IPTV3] Błąd zmiany pozycji manualnej: {e}", xbmc.LOGERROR)

    def change_group(self, channel_id, channel_name):
        """Przenosi kanał do innej grupy (lub nowej)."""
        query = "SELECT DISTINCT group_name FROM channels WHERE group_name IS NOT NULL AND group_name != '' ORDER BY group_name ASC"
        rows = self.engine.db.fetch_all(query)
        groups = [r["group_name"] for r in rows]
        
        options = ["[ ➕ UTWÓRZ NOWĄ GRUPĘ ]"] + groups
        
        dialog = xbmcgui.Dialog()
        ret = dialog.select(f"Wybierz grupę dla {channel_name}", options)
        
        if ret == 0:
            new_group = dialog.input("Wpisz nazwę nowej grupy:")
            if new_group:
                self.engine.db.execute_query("UPDATE channels SET group_name = ? WHERE channel_id = ?", (new_group, channel_id))
                self.load_groups() # Odśwież listę grup (pojawiła się nowa)
                self.load_channels(self.current_group) # Odśwież obecną listę kanałów (kanał zniknie, bo zmienił grupę)
                xbmcgui.Dialog().notification("IPTV 3.0", f"Przeniesiono do nowej grupy: {new_group}", xbmcgui.NOTIFICATION_INFO, 2000)
                
        elif ret > 0:
            selected_group = options[ret]
            self.engine.db.execute_query("UPDATE channels SET group_name = ? WHERE channel_id = ?", (selected_group, channel_id))
            self.load_channels(self.current_group) # Odśwież obecną listę
            xbmcgui.Dialog().notification("IPTV 3.0", f"Przeniesiono do: {selected_group}", xbmcgui.NOTIFICATION_INFO, 2000)

    def toggle_favorite(self, channel_id):
        """Zmienia status Ulubionych."""
        res = self.engine.db.fetch_all("SELECT is_favorite FROM channels WHERE channel_id = ?", (channel_id,))
        if not res: return
        
        current_state = res[0]['is_favorite']
        new_state = 0 if current_state == 1 else 1
        
        self.engine.db.execute_query("UPDATE channels SET is_favorite = ? WHERE channel_id = ?", (new_state, channel_id))
        self.load_channels(self.current_group)
        xbmcgui.Dialog().notification("IPTV 3.0", "Zaktualizowano Ulubione", xbmcgui.NOTIFICATION_INFO, 2000)# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon

class ChannelEditorWindow(xbmcgui.WindowXML):
    """
    Okno edytora kanałów i grup.
    Umożliwia zmianę kolejności (sort_index), przypisywanie do grup i zarządzanie ulubionymi.
    """
    def __init__(self, *args, **kwargs):
        super(ChannelEditorWindow, self).__init__(*args, **kwargs)
        self.engine = kwargs.get('engine')
        self.group_list = None
        self.channel_list = None
        self.current_group = None
        self.channels = []
        self.addon = xbmcaddon.Addon()

    def onInit(self):
        xbmc.log("[IPTV3] ChannelEditorWindow: Inicjalizacja...", xbmc.LOGINFO)
        self.group_list = self.getControl(100) # ID listy grup (lewa strona)
        self.channel_list = self.getControl(200) # ID listy kanałów (prawa strona)

        # --- AUTO-NAPRAWA LUK W NUMERACJI (Zlikwiduje obecny bałagan) ---
        self.reindex_all_channels()

        # Załaduj grupy przy starcie
        self.load_groups()
        
    def reindex_all_channels(self):
        """Łata luki w numeracji zachowując kolejność dla obu list niezależnie"""
        try:
            # Reindeksacja ogólna
            rows = self.engine.db.fetch_all("SELECT channel_id FROM channels ORDER BY sort_index ASC")
            for i, row in enumerate(rows):
                self.engine.db.execute_query("UPDATE channels SET sort_index = ? WHERE channel_id = ?", (i + 1, row['channel_id']))
            # Reindeksacja ulubionych
            favs = self.engine.db.fetch_all("SELECT channel_id FROM channels WHERE is_favorite = 1 ORDER BY fav_sort_index ASC")
            for i, row in enumerate(favs):
                self.engine.db.execute_query("UPDATE channels SET fav_sort_index = ? WHERE channel_id = ?", (i + 1, row['channel_id']))
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd reindeksacji: {e}", xbmc.LOGERROR)

    def load_groups(self):
        """Pobiera i wyświetla listę grup z bazy."""
        if not self.group_list:
            return

        self.group_list.reset()
        
        # Specjalna grupa dla ulubionych
        li_fav = xbmcgui.ListItem(label="⭐ Ulubione")
        li_fav.setProperty("group_name", "__FAVORITES__")
        self.group_list.addItem(li_fav)

        # Pobieranie grup z bazy
        query = "SELECT DISTINCT group_name FROM channels WHERE group_name IS NOT NULL AND group_name != '' ORDER BY group_name ASC"
        try:
            rows = self.engine.db.fetch_all(query)
            for row in rows:
                group_name = row["group_name"]
                li = xbmcgui.ListItem(label=group_name)
                li.setProperty("group_name", group_name)
                self.group_list.addItem(li)
        except Exception as e:
            xbmc.log(f"[IPTV3] ChannelEditorWindow: Błąd ładowania grup: {e}", xbmc.LOGERROR)

        # Domyślnie zaznacz pierwszą grupę (lub Ulubione, jeśli to pierwsza pozycja) i załaduj jej kanały
        if self.group_list.size() > 0:
            self.group_list.selectItem(0)
            self.on_group_selected()

    def load_channels(self, group_name):
        """Pobiera i wyświetla kanały dla wybranej grupy z dynamiczną numeracją."""
        if not self.channel_list:
            return

        self.channel_list.reset()
        self.channels = []
        self.current_group = group_name

        query = "SELECT * FROM channels"
        params = []

        # Wybieramy kolumnę sortowania w zależności od tego, czy jesteśmy w Ulubionych
        if group_name == "__FAVORITES__":
            query += " WHERE is_favorite = 1 ORDER BY fav_sort_index ASC"
            col_idx = "fav_sort_index"
        elif group_name:
            query += " WHERE group_name = ? ORDER BY sort_index ASC"
            params.append(group_name)
            col_idx = "sort_index"
        else:
            query += " ORDER BY sort_index ASC"
            col_idx = "sort_index"

        try:
            rows = self.engine.db.fetch_all(query, tuple(params))
            for row in rows:
                channel = dict(row)
                self.channels.append(channel)
                
                name = channel.get("name", "Nieznany")
                is_fav = channel.get("is_favorite", 0)
                display_name = f"⭐ {name}" if is_fav == 1 else name
                
                li = xbmcgui.ListItem(label=display_name)
                li.setProperty("channel_id", str(channel.get("channel_id", "")))
                
                # POPRAWKA: Wyświetlamy numer z właściwej kolumny (ogólny LUB ulubiony)
                li.setLabel2(str(channel.get(col_idx, "")))
                
                self.channel_list.addItem(li)
        except Exception as e:
            xbmc.log(f"[IPTV3] ChannelEditorWindow: Błąd ładowania kanałów: {e}", xbmc.LOGERROR)

    def on_group_selected(self):
        """Obsługa zmiany zaznaczenia na liście grup."""
        selected_item = self.group_list.getSelectedItem()
        if selected_item:
            group_name = selected_item.getProperty("group_name")
            self.load_channels(group_name)

    def onAction(self, action):
        """Obsługa nawigacji."""
        action_id = action.getId()
        
        # Zamknięcie okna
        if action_id in (9, 10, 92):
            self.close()
            
        # Nawigacja - jeśli zmienimy grupę, odświeżamy listę kanałów
        elif action_id in (1, 2, 3, 4):
            xbmc.sleep(50) # Krótkie opóźnienie dla pewności, że kursor się przesunął
            focused_id = self.getFocusId()
            if focused_id == 100: # Lista grup
                self.on_group_selected()
                
        # Menu kontekstowe (edycja)
        elif action_id in (117, 101):
            focused_id = self.getFocusId()
            if focused_id == 200: # Edycja tylko na liście kanałów
                self.handle_context_menu()

    def handle_context_menu(self):
        """Menu opcji edycji dla konkretnego kanału."""
        selected_pos = self.channel_list.getSelectedPosition()
        if selected_pos < 0 or selected_pos >= len(self.channels):
            return

        channel = self.channels[selected_pos]
        channel_id = channel['channel_id']
        current_name = channel.get('name', 'Nieznany')
        
        # Pobieramy właściwy index w zależności od wyświetlanej listy
        col_idx = "fav_sort_index" if self.current_group == "__FAVORITES__" else "sort_index"
        current_idx = channel.get(col_idx, 0)
        
        options = [
            "Przesuń w górę",
            "Przesuń w dół",
            "Zmień pozycję (wpisz numer)",
            "Przenieś do innej grupy",
            "⭐ Dodaj / Usuń z Ulubionych"
        ]
        
        dialog = xbmcgui.Dialog()
        ret = dialog.contextmenu(options)
        
        if ret == 0: self.move_channel(selected_pos, -1)
        elif ret == 1: self.move_channel(selected_pos, 1)
        elif ret == 2: self.change_position_manual(channel_id, current_name, current_idx)
        elif ret == 3: self.change_group(channel_id, current_name)
        elif ret == 4: self.toggle_favorite(channel_id)

    # --- FUNKCJE EDYCJI ---

    def move_channel(self, current_pos, direction):
        """Przesuwa kanał o 1 pozycję w górę (-1) lub w dół (+1)."""
        new_pos = current_pos + direction
        if new_pos < 0 or new_pos >= len(self.channels): return

        ch1 = self.channels[current_pos]
        ch2 = self.channels[new_pos]

        # Określamy, którą kolumnę aktualizujemy
        col = "fav_sort_index" if self.current_group == "__FAVORITES__" else "sort_index"

        try:
            self.engine.db.execute_query(f"UPDATE channels SET {col} = ? WHERE channel_id = ?", (ch2[col], ch1['channel_id']))
            self.engine.db.execute_query(f"UPDATE channels SET {col} = ? WHERE channel_id = ?", (ch1[col], ch2['channel_id']))
            self.load_channels(self.current_group)
            self.channel_list.selectItem(new_pos)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd podczas przesuwania kanału: {e}", xbmc.LOGERROR)

    def change_position_manual(self, channel_id, channel_name, old_pos):
        """Zmiana pozycji na konkretny numer bez tworzenia luk (uwzględnia Ulubione)."""
        dialog = xbmcgui.Dialog()
        new_pos_str = dialog.numeric(0, f"Podaj nowy numer dla: {channel_name}")
        
        if new_pos_str:
            try:
                new_pos = int(new_pos_str)
                if new_pos == old_pos: return
                
                # Zabezpieczenie przed wpisaniem zera
                if new_pos < 1: new_pos = 1

                # Sprawdzamy, na jakiej liście aktualnie jesteśmy
                col = "fav_sort_index" if self.current_group == "__FAVORITES__" else "sort_index"

                if new_pos < old_pos:
                    # Przesuwamy kanały w dół, by zrobić miejsce wyżej
                    self.engine.db.execute_query(f"UPDATE channels SET {col} = {col} + 1 WHERE {col} >= ? AND {col} < ?", (new_pos, old_pos))
                else:
                    # Przesuwamy kanały w górę, by zrobić miejsce niżej
                    self.engine.db.execute_query(f"UPDATE channels SET {col} = {col} - 1 WHERE {col} > ? AND {col} <= ?", (old_pos, new_pos))
                
                # Wstawiamy kanał w czyste miejsce
                self.engine.db.execute_query(f"UPDATE channels SET {col} = ? WHERE channel_id = ?", (new_pos, channel_id))
                
                self.load_channels(self.current_group)
                xbmcgui.Dialog().notification("IPTV 3.0", f"Zmieniono pozycję na: {new_pos}", xbmcgui.NOTIFICATION_INFO, 2000)
            except Exception as e:
                 xbmc.log(f"[IPTV3] Błąd zmiany pozycji manualnej: {e}", xbmc.LOGERROR)

    def change_group(self, channel_id, channel_name):
        """Przenosi kanał do innej grupy (lub nowej)."""
        query = "SELECT DISTINCT group_name FROM channels WHERE group_name IS NOT NULL AND group_name != '' ORDER BY group_name ASC"
        rows = self.engine.db.fetch_all(query)
        groups = [r["group_name"] for r in rows]
        
        options = ["[ ➕ UTWÓRZ NOWĄ GRUPĘ ]"] + groups
        
        dialog = xbmcgui.Dialog()
        ret = dialog.select(f"Wybierz grupę dla {channel_name}", options)
        
        if ret == 0:
            new_group = dialog.input("Wpisz nazwę nowej grupy:")
            if new_group:
                self.engine.db.execute_query("UPDATE channels SET group_name = ? WHERE channel_id = ?", (new_group, channel_id))
                self.load_groups() # Odśwież listę grup (pojawiła się nowa)
                self.load_channels(self.current_group) # Odśwież obecną listę kanałów (kanał zniknie, bo zmienił grupę)
                xbmcgui.Dialog().notification("IPTV 3.0", f"Przeniesiono do nowej grupy: {new_group}", xbmcgui.NOTIFICATION_INFO, 2000)
                
        elif ret > 0:
            selected_group = options[ret]
            self.engine.db.execute_query("UPDATE channels SET group_name = ? WHERE channel_id = ?", (selected_group, channel_id))
            self.load_channels(self.current_group) # Odśwież obecną listę
            xbmcgui.Dialog().notification("IPTV 3.0", f"Przeniesiono do: {selected_group}", xbmcgui.NOTIFICATION_INFO, 2000)

    def toggle_favorite(self, channel_id):
        """Zmienia status Ulubionych i nadaje odpowiedni indeks na końcu listy."""
        res = self.engine.db.fetch_all("SELECT is_favorite FROM channels WHERE channel_id = ?", (channel_id,))
        if not res: return
        
        current_state = res[0]['is_favorite']
        new_state = 0 if current_state == 1 else 1
        
        if new_state == 1:
            # Wrzucamy kanał na sam dół listy ulubionych
            max_res = self.engine.db.fetch_all("SELECT MAX(fav_sort_index) as m FROM channels WHERE is_favorite = 1")
            m = (max_res[0]['m'] or 0) + 1
            self.engine.db.execute_query("UPDATE channels SET is_favorite = 1, fav_sort_index = ? WHERE channel_id = ?", (m, channel_id))
        else:
            # Usuwamy z ulubionych i zerujemy jego pozycję na tej liście
            self.engine.db.execute_query("UPDATE channels SET is_favorite = 0, fav_sort_index = 0 WHERE channel_id = ?", (channel_id,))
     
        self.load_channels(self.current_group)
        xbmcgui.Dialog().notification("IPTV 3.0", "Zaktualizowano Ulubione", xbmcgui.NOTIFICATION_INFO, 2000)