# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class Overlay(xbmcgui.WindowXMLDialog):
    """
    Moduł graficznych nakładek systemowych (Overlay).
    Pozwala na wyświetlanie niestandardowych elementów (zegar, logo, wskaźniki)
    bezpośrednio nad odtwarzanym materiałem wideo.
    """
    
    def __init__(self, *args, **kwargs):
        super(Overlay, self).__init__(*args, **kwargs)
        self.is_visible = False
        xbmc.log("[IPTV3] Zainicjowano moduł Overlay", xbmc.LOGINFO)

    def onInit(self):
        """Wywoływane przy inicjalizacji okna XML."""
        self.is_visible = True
        xbmc.log("[IPTV3] Overlay: Okno graficzne zainicjalizowane.", xbmc.LOGDEBUG)

    def update_clock(self):
        """
        Przykładowa metoda aktualizująca etykietę zegara w interfejsie.
        Wymaga odpowiedniego ID kontrolki w pliku XML skina.
        """
        # self.getControl(101).setLabel(xbmc.getInfoLabel('System.Time'))
        pass

    def show_logo(self, duration=5000):
        """
        Wyświetla logo wtyczki na określony czas.
        """
        xbmc.log("[IPTV3] Overlay: Wyświetlanie logotypu systemowego.", xbmc.LOGDEBUG)
        # Logika sterowania widocznością kontrolek obrazu
        pass

    def hide_all(self):
        """Ukrywa wszystkie elementy nakładki."""
        self.is_visible = False
        self.close()
        xbmc.log("[IPTV3] Overlay: Zamknięto nakładki graficzne.", xbmc.LOGDEBUG)

    def onAction(self, action):
        """Obsługa akcji użytkownika (np. naciśnięcie 'wstecz' zamyka overlay)."""
        if action.getId() in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
            self.hide_all()