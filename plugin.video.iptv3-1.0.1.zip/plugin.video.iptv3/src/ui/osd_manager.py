# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class OsdManager:
    """
    Menedżer nakładki ekranowej (On-Screen Display - OSD).
    Odpowiada za wyświetlanie informacji o kanale i audycji podczas odtwarzania.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł OsdManager", xbmc.LOGINFO)

    def update_info_tag(self, listitem, epg_now, epg_next=None):
        """
        Aktualizuje tagi informacyjne w obiekcie ListItem odtwarzacza.
        
        :param listitem: Aktywny obiekt xbmcgui.ListItem
        :param epg_now: Słownik z danymi aktualnej audycji
        :param epg_next: Słownik z danymi następnej audycji
        """
        if not epg_now:
            return

        # Ustawianie informacji wideo dla OSD
        video_info = {
            'title': epg_now.get('title', 'Brak tytułu'),
            'plot': epg_now.get('description', 'Brak opisu'),
            'genre': epg_now.get('genre', ''),
            'duration': epg_now.get('duration', 0)
        }
        
        listitem.setInfo('video', video_info)
        
        # Jeśli mamy informacje o następnym programie, możemy je dodać do specjalnych właściwości
        if epg_next:
            listitem.setProperty('NextProgram.Title', epg_next.get('title', ''))
            listitem.setProperty('NextProgram.Start', epg_next.get('start_time_str', ''))

    def show_custom_message(self, title, message, timeout=3000):
        """
        Wyświetla małe powiadomienie (toast) w prawym górnym rogu ekranu.
        Przydatne do komunikatów o błędach lub statusie nagrywania.
        
        :param title: Nagłówek powiadomienia
        :param message: Treść wiadomości
        :param timeout: Czas wyświetlania w milisekundach
        """
        dialog = xbmcgui.Dialog()
        dialog.notification(title, message, xbmcgui.NOTIFICATION_INFO, timeout)

    def refresh_osd(self):
        """
        Wymusza odświeżenie interfejsu graficznego.
        Wywoływane np. przy zmianie audycji w trakcie oglądania.
        """
        xbmc.executebuiltin('Container.Refresh')
        xbmc.log("[IPTV3] OsdManager: Wymuszono odświeżenie interfejsu.", xbmc.LOGDEBUG)