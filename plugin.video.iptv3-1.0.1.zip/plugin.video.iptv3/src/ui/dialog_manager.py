# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

class DialogManager:
    """
    Menedżer okien dialogowych i interakcji (Dialog Manager).
    Obsługuje komunikaty, potwierdzenia, klawiaturę oraz okna wyboru.
    """
    
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        xbmc.log("[IPTV3] Zainicjowano moduł DialogManager", xbmc.LOGINFO)

    def show_ok(self, title, message):
        """Wyświetla proste okno informacyjne z przyciskiem OK."""
        return self.dialog.ok(title, message)

    def show_yes_no(self, title, message):
        """
        Wyświetla okno pytania Tak/Nie.
        :return: True jeśli wybrano Tak, False jeśli Nie lub zamknięto okno.
        """
        return self.dialog.yesno(title, message)

    def show_keyboard(self, default_text="", heading="Wprowadź tekst", hidden=False):
        """
        Wyświetla systemową klawiaturę Kodi.
        
        :param default_text: Tekst domyślnie wpisany w pole
        :param heading: Nagłówek okna klawiatury
        :param hidden: Czy tekst ma być ukryty (np. dla hasła)
        :return: Wprowadzony tekst lub pusty string
        """
        keyboard = xbmc.Keyboard(default_text, heading, hidden)
        keyboard.doModal()
        if keyboard.isConfirmed():
            return keyboard.getText()
        return ""

    def show_numeric_input(self, heading="Wprowadź numer"):
        """Wyświetla klawiaturę numeryczną (np. do wprowadzania PINu lub godziny)."""
        return self.dialog.numeric(0, heading)

    def show_select_list(self, title, options):
        """
        Wyświetla listę wyboru.
        
        :param title: Tytuł okna
        :param options: Lista opcji (stringi)
        :return: Indeks wybranej opcji lub -1 jeśli anulowano
        """
        return self.dialog.select(title, options)

    def show_progress(self, title, message):
        """
        Tworzy i zwraca obiekt paska postępu (np. przy pobieraniu EPG).
        :return: Instancja xbmcgui.DialogProgress
        """
        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create(title, message)
        return p_dialog