# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import time

class TimelineUI:
    """
    Moduł odpowiedzialny za wizualizację osi czasu (Timeline UI).
    Zajmuje się renderowaniem pasków postępu i znaczników czasowych w interfejsie.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł TimelineUI", xbmc.LOGINFO)

    def format_time(self, seconds):
        """Konwertuje sekundy na czytelny format HH:MM:SS."""
        return time.strftime('%H:%M:%S', time.gmtime(seconds))

    def get_progress_percentage(self, start_time, end_time):
        """
        Oblicza procentowy postęp aktualnej audycji.
        
        :param start_time: UNIX timestamp rozpoczęcia
        :param end_time: UNIX timestamp zakończenia
        :return: Wartość od 0 do 100 (float)
        """
        current_time = int(time.time())
        total_duration = end_time - start_time
        
        if total_duration <= 0:
            return 0.0
            
        elapsed = current_time - start_time
        progress = (float(elapsed) / float(total_duration)) * 100
        
        # Ograniczamy do zakresu 0-100
        return max(0.0, min(100.0, progress))

    def draw_timeline_bar(self, start_time, end_time, title=""):
        """
        W przyszłości: metoda do rysowania niestandardowego paska postępu 
        na dedykowanym oknie XML (Custom Window).
        """
        progress = self.get_progress_percentage(start_time, end_time)
        xbmc.log(f"[IPTV3] TimelineUI: Renderowanie paska dla '{title}' - Postęp: {progress:.1f}%", xbmc.LOGDEBUG)
        
    def get_time_labels(self, start_time, end_time):
        """Zwraca słownik z sformatowanymi etykietami czasu."""
        return {
            'start': self.format_time(start_time),
            'end': self.format_time(end_time),
            'current': self.format_time(int(time.time()))
        }