# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import sys
import traceback

class DebugCenter:
    """
    Zaawansowany moduł diagnostyczny (Debug Center).
    Zajmuje się zbieraniem logów, monitorowaniem błędów i wyświetlaniem statystyk.
    """
    
    def __init__(self):
        self.is_active = False
        xbmc.log("[IPTV3] Zainicjowano pełny moduł DebugCenter", xbmc.LOGINFO)

    def capture_exception(self, error_msg="Wystąpił nieoczekiwany błąd"):
        """
        Przechwytuje wyjątek Pythona i formatuje go do czytelnego logu.
        """
        exc_type, exc_value, exc_traceback = sys.exc_info()
        full_trace = traceback.format_exception(exc_type, exc_value, exc_traceback)
        
        xbmc.log(f"[IPTV3 ERROR] {error_msg}", xbmc.LOGERROR)
        for line in full_trace:
            xbmc.log(f"[IPTV3 TRACE] {line.strip()}", xbmc.LOGERROR)
            
        # Powiadomienie użytkownika na ekranie
        xbmcgui.Dialog().notification("IPTV 3.0 - Błąd", error_msg, xbmcgui.NOTIFICATION_ERROR, 5000)

    def get_system_info(self):
        """
        Zbiera dane o środowisku Kodi (wersja, platforma).
        """
        info = {
            "Kodi Version": xbmc.getInfoLabel('System.BuildVersion'),
            "Platform": sys.platform,
            "IPTV 3.0 Mode": "Premium" if self.is_active else "Standard",
            "Screen Resolution": xbmc.getInfoLabel('System.ScreenResolution')
        }
        return info

    def show_debug_info(self, stats_dict=None):
        """
        Wyświetla okno ze statystykami systemowymi i danymi strumienia.
        """
        combined_stats = self.get_system_info()
        if stats_dict:
            combined_stats.update(stats_dict)

        title = "[COLOR yellow]IPTV 3.0 - Diagnostyka Systemu[/COLOR]"
        message = ""
        for key, value in combined_stats.items():
            message += f"[B]{key}:[/B] {value}\n"
            
        xbmcgui.Dialog().ok(title, message)

    def log_to_screen(self, message, level="INFO"):
        """Wyświetla szybkie powiadomienie debugera na ekranie."""
        color = "white"
        if level == "ERROR": color = "red"
        elif level == "WARNING": color = "orange"
        
        formatted_msg = f"[COLOR {color}][IPTV3 {level}][/COLOR] {message}"
        xbmcgui.Dialog().notification("Debug Center", formatted_msg, xbmcgui.NOTIFICATION_INFO, 3000)

    def toggle_console(self):
        """Przełącza stan widoczności konsoli diagnostycznej."""
        self.is_active = not self.is_active
        xbmc.log(f"[IPTV3] DebugCenter: Stan diagnostyki zmieniony na: {self.is_active}", xbmc.LOGINFO)
        return self.is_active