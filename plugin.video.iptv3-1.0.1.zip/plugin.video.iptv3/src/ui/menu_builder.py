# -*- coding: utf-8 -*-
import sys
import xbmcgui
import xbmcplugin
import xbmc

class MenuBuilder:
    """
    Kreator interfejsu użytkownika (UI).
    Odpowiada za generowanie menu, folderów i elementów wideo w Kodi.
    """
    
    def __init__(self, addon_handle):
        """
        :param addon_handle: Uchwyt wtyczki (często sys.argv[1]) wymagany przez Kodi do budowy UI.
        """
        # Upewniamy się, że handle jest liczbą całkowitą
        self.handle = int(addon_handle)
        xbmc.log("[IPTV3] Zainicjowano moduł MenuBuilder", xbmc.LOGINFO)

    def add_dir(self, name, url, iconimage="DefaultFolder.png", plot=""):
        """
        Dodaje wirtualny folder (kategorię) do menu wtyczki.
        
        :param name: Nazwa folderu (np. "Telewizja na żywo", "Ustawienia")
        :param url: Wewnętrzny adres URL wtyczki wywołujący odpowiednią akcję
        :param iconimage: Ścieżka do ikony
        :param plot: Opcjonalny opis wyświetlany w interfejsie
        """
        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon': iconimage, 'thumb': iconimage})
        listitem.setInfo('video', {'title': name, 'plot': plot})
        
        # isFolder=True informuje Kodi, że po kliknięciu ma otworzyć kolejny poziom menu
        xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=listitem, isFolder=True)

    def add_item(self, name, url, iconimage="DefaultVideo.png", plot="", is_playable=True):
        """
        Dodaje element końcowy (np. konkretny kanał, nagranie lub materiał z catchupu).
        
        :param name: Nazwa kanału lub filmu
        :param url: Adres URL strumienia lub akcja odtwarzania
        :param iconimage: Logotyp stacji (Picon) lub plakat
        :param plot: Opis z przewodnika EPG
        :param is_playable: Flaga określająca, czy kliknięcie ma od razu uruchomić odtwarzacz
        """
        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon': iconimage, 'thumb': iconimage})
        listitem.setInfo('video', {'title': name, 'plot': plot})
        
        if is_playable:
            # Flaga IsPlayable mówi Kodi, że to jest bezpośredni strumień wideo do odtworzenia
            listitem.setProperty('IsPlayable', 'true')
            
        xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=listitem, isFolder=False)

    def end_directory(self):
        """
        Zamyka aktualnie budowany katalog i przekazuje go do wyrysowania w interfejsie Kodi.
        Tę metodę należy wywołać zawsze na końcu po dodaniu wszystkich elementów (add_dir / add_item).
        """
        xbmcplugin.endOfDirectory(self.handle)