# -*- coding: utf-8 -*-
import sqlite3
import xbmc
import xbmcvfs
import os

class DbEngine:
    """
    Silnik bazy danych (Database Engine).
    Zarządza lokalnym magazynem danych SQLite dla kanałów i EPG.
    """

    def __init__(self, db_path):
        self.db_path = xbmcvfs.translatePath(db_path)
        self.connection = None
        self._connect()
        xbmc.log(f"[IPTV3] Zainicjowano moduł DbEngine: {self.db_path}", xbmc.LOGINFO)

    def _connect(self):
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.row_factory = sqlite3.Row
        except sqlite3.Error as e:
            xbmc.log(f"[IPTV3] DbEngine: Błąd połączenia z bazą: {str(e)}", xbmc.LOGERROR)

    # ---------------------------------------------------------
    # INICJALIZACJA + MIGRACJE
    # ---------------------------------------------------------
    def initialize(self):
        """
        Tworzy tabele, jeśli nie istnieją.
        Dodaje brakujące kolumny (migracja).
        """
        try:
            cursor = self.connection.cursor()

            # --- Tabela kanałów ---
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS channels (
                    channel_id INTEGER PRIMARY KEY,
                    name TEXT,
                    stream_url TEXT
                )
            """)

            # --- Tabela EPG (nieużywana, ale zostawiamy dla kompatybilności) ---
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS epg (
                    id INTEGER PRIMARY KEY,
                    channel_id INTEGER,
                    title TEXT,
                    start_time TEXT,
                    end_time TEXT
                )
            """)

            # --- MIGRACJA: dodanie tvg_name ---
            try:
                cursor.execute("ALTER TABLE channels ADD COLUMN tvg_name TEXT")
                xbmc.log("[IPTV3] DbEngine: Dodano kolumnę tvg_name", xbmc.LOGINFO)
            except:
                pass  # kolumna już istnieje

            # --- MIGRACJA: dodanie tvg_id ---
            try:
                cursor.execute("ALTER TABLE channels ADD COLUMN tvg_id TEXT")
                xbmc.log("[IPTV3] DbEngine: Dodano kolumnę tvg_id", xbmc.LOGINFO)
            except:
                pass  # kolumna już istnieje

            self.connection.commit()
            xbmc.log("[IPTV3] DbEngine: Tabele gotowe + migracje OK.", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[IPTV3] DbEngine: Błąd inicjalizacji: {e}", xbmc.LOGERROR)
            return False

        return True

    # ---------------------------------------------------------
    # ZAPYTANIA
    # ---------------------------------------------------------
    def execute_query(self, query, params=()):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params)
            self.connection.commit()
            return cursor.lastrowid
        except sqlite3.Error as e:
            xbmc.log(f"[IPTV3] DbEngine: Błąd zapytania: {str(e)}", xbmc.LOGERROR)
            return None

    def fetch_all(self, query, params=()):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params)
            return cursor.fetchall()
        except sqlite3.Error as e:
            xbmc.log(f"[IPTV3] DbEngine: Błąd pobierania danych: {str(e)}", xbmc.LOGERROR)
            return []

    # ---------------------------------------------------------
    # ZAMKNIĘCIE
    # ---------------------------------------------------------
    def close(self):
        if self.connection:
            self.connection.close()
            xbmc.log("[IPTV3] DbEngine: Zamknięto połączenie z bazą.", xbmc.LOGDEBUG)
