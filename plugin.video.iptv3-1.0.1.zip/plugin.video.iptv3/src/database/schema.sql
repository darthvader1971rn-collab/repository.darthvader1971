-- Schemat bazy danych dla wtyczki IPTV 3.0

-- Tabela kanałów
CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT UNIQUE,
    name TEXT NOT NULL,
    stream_url TEXT NOT NULL,
    group_name TEXT,
    logo_url TEXT,
    is_hidden INTEGER DEFAULT 0
);

-- Tabela danych EPG (Electronic Program Guide)
CREATE TABLE IF NOT EXISTS epg_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT,
    title TEXT,
    start_time INTEGER,
    end_time INTEGER,
    description TEXT,
    FOREIGN KEY (channel_id) REFERENCES channels(channel_id) ON DELETE CASCADE
);

-- Tabela ulubionych kanałów
CREATE TABLE IF NOT EXISTS favorites (
    channel_id TEXT PRIMARY KEY,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (channel_id) REFERENCES channels(channel_id) ON DELETE CASCADE
);

-- Tabela metadanych i statusów systemowych
CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- Indeksy dla przyspieszenia wyszukiwania w EPG
CREATE INDEX IF NOT EXISTS idx_epg_time ON epg_data (start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_channel_id ON channels (channel_id);