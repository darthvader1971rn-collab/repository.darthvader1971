# -*- coding: utf-8 -*-
import xbmc

class DriftCorrection:
    """
    Moduł odpowiedzialny za korygowanie dryfu czasu (Drift Correction).
    Analizuje i niweluje mikrosekundowe rozjazdy między czasem rzeczywistym
    a timestampami segmentów wideo w strumieniach na żywo.
    """
    
    def __init__(self):
        # Aktualna wartość wyliczonego dryfu
        self.current_drift = 0.0
        xbmc.log("[IPTV3] Zainicjowano moduł DriftCorrection", xbmc.LOGINFO)

    def calculate_drift(self, expected_time, actual_presentation_time):
        """
        Oblicza różnicę (dryf) między oczekiwanym a rzeczywistym czasem wyświetlania segmentu/klatki.
        
        :param expected_time: Oczekiwany czas (np. na podstawie TimelineEngine)
        :param actual_presentation_time: Rzeczywisty czas odczytany ze strumienia
        :return: Wartość dryfu w sekundach (float)
        """
        drift = actual_presentation_time - expected_time
        self.current_drift = drift
        
        # Logowanie ukryte pod poziomem DEBUG, aby nie spamować logów przy prawidłowym odtwarzaniu
        xbmc.log(f"[IPTV3] DriftCorrection: Wyliczono dryf segmentu: {drift:.3f}s", xbmc.LOGDEBUG)
        return drift

    def needs_correction(self, threshold=0.5):
        """
        Sprawdza, czy dryf przekroczył dopuszczalną granicę i wymaga akcji naprawczej.
        
        :param threshold: Próg tolerancji w sekundach (domyślnie 0.5s)
        :return: True, jeśli wymagana jest interwencja systemu (np. AudioSync)
        """
        if abs(self.current_drift) > threshold:
            xbmc.log(f"[IPTV3] DriftCorrection: Dryf ({self.current_drift:.3f}s) przekroczył próg ({threshold}s). Wymagana korekta!", xbmc.LOGWARNING)
            return True
        return False

    def reset(self):
        """
        Resetuje zapisaną wartość dryfu do zera.
        Metoda wywoływana np. podczas przełączania kanałów (zappingu).
        """
        self.current_drift = 0.0
        xbmc.log("[IPTV3] DriftCorrection: Zresetowano stan dryfu.", xbmc.LOGDEBUG)