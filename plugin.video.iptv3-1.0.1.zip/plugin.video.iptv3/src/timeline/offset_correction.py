# -*- coding: utf-8 -*-
import xbmc

class OffsetCorrection:
    """
    Moduł odpowiedzialny za korektę przesunięć czasowych (Offset Correction).
    Zarządza globalnymi i lokalnymi różnicami czasu między dostawcą, EPG a systemem.
    """
    
    def __init__(self):
        # Przechowuje aktualnie wyliczony offset dostawcy
        self.provider_offset = 0
        xbmc.log("[IPTV3] Zainicjowano moduł OffsetCorrection", xbmc.LOGINFO)

    def apply_epg_shift(self, epg_time_unix, shift_hours):
        """
        Aplikuje ręczne przesunięcie czasu zdefiniowane dla EPG (np. z settings.xml).
        
        :param epg_time_unix: Oryginalny czas audycji z XMLTV (UNIX timestamp)
        :param shift_hours: Wartość przesunięcia w godzinach (dodatnia lub ujemna)
        :return: Skorygowany czas w sekundach
        """
        if shift_hours == 0:
            return epg_time_unix
            
        shift_seconds = shift_hours * 3600
        corrected_time = epg_time_unix + shift_seconds
        
        xbmc.log(f"[IPTV3] OffsetCorrection: Skorygowano czas EPG o {shift_hours}h", xbmc.LOGDEBUG)
        return corrected_time

    def calculate_provider_offset(self, local_time_unix, provider_time_unix):
        """
        Oblicza i zapisuje różnicę czasu między Kodi a serwerem dostawcy IPTV.
        
        :param local_time_unix: Aktualny czas systemu lokalnego
        :param provider_time_unix: Czas zwrócony przez serwer dostawcy
        :return: Wyliczony offset w sekundach
        """
        offset = provider_time_unix - local_time_unix
        self.provider_offset = offset
        
        xbmc.log(f"[IPTV3] OffsetCorrection: Zaktualizowano offset dostawcy: {offset}s", xbmc.LOGINFO)
        return offset

    def get_corrected_provider_time(self, local_time_unix):
        """
        Zwraca czas lokalny skorygowany o wcześniej wyliczony offset dostawcy.
        """
        return local_time_unix + self.provider_offset