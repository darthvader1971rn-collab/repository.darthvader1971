# -*- coding: utf-8 -*-
import xbmc
import time

class TimelineEngine:
    """
    Główny silnik zarządzający osią czasu (Timeline 3.0).
    Odpowiada za globalną synchronizację czasu między systemem lokalnym, 
    dostawcą (Provider) a przewodnikiem (EPG).
    """
    
    def __init__(self):
        # Globalne przesunięcie czasu w sekundach (domyślnie 0)
        self.global_offset = 0
        xbmc.log("[IPTV3] Zainicjowano moduł TimelineEngine", xbmc.LOGINFO)

    def get_synchronized_time(self):
        """
        Zwraca aktualny czas UNIX skorygowany o globalne przesunięcia.
        Wszystkie inne moduły (Catchup, Recording, EPG) powinny pytać o czas właśnie tutaj.
        
        :return: Skorygowany czas UNIX (int)
        """
        current_time = int(time.time())
        sync_time = current_time + self.global_offset
        return sync_time

    def set_global_offset(self, offset_seconds):
        """
        Ustawia globalne przesunięcie czasu (np. pobrane z settings.xml lub z Providera).
        
        :param offset_seconds: Przesunięcie w sekundach (dodatnie lub ujemne)
        """
        self.global_offset = offset_seconds
        xbmc.log(f"[IPTV3] TimelineEngine: Ustawiono globalny offset na {offset_seconds}s", xbmc.LOGINFO)

    def sync_with_provider(self, provider_time_unix):
        """
        Automatycznie kalibruje lokalną oś czasu na podstawie czasu serwera dostawcy.
        
        :param provider_time_unix: Czas zwrócony przez API dostawcy
        """
        local_time = int(time.time())
        calculated_offset = provider_time_unix - local_time
        self.set_global_offset(calculated_offset)
        xbmc.log(f"[IPTV3] TimelineEngine: Zsynchronizowano czas z dostawcą. Wyliczony offset: {calculated_offset}s", xbmc.LOGINFO)