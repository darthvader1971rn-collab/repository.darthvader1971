# -*- coding: utf-8 -*-
import xbmc
from src.cache.local_cache import LocalCache

class MetadataCache(LocalCache):
    """
    Specjalistyczny cache dla metadanych (EPG, ikony, opisy).
    Pozwala na błyskawiczne odzyskiwanie informacji o audycjach.
    """
    
    def __init__(self):
        super(MetadataCache, self).__init__()
        xbmc.log("[IPTV3] Zainicjowano MetadataCache", xbmc.LOGINFO)

    def cache_epg_entry(self, channel_id, entry_data):
        """Zapisuje pojedynczy wpis EPG do szybkiego odczytu."""
        key = f"epg_{channel_id}"
        return self.set(key, entry_data)

    def get_cached_epg(self, channel_id):
        """Pobiera zbuforowane dane EPG dla kanału."""
        return self.get(f"epg_{channel_id}")