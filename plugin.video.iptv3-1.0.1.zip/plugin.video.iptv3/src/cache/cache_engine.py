# -*- coding: utf-8 -*-
import xbmc
import time

class CacheEngine:
    """
    Główny silnik pamięci podręcznej (Cache Engine).
    Zarządza cyklem życia tymczasowych danych, zapobiegając nadmiarowym
    zapytaniom do serwerów dostawcy.
    """
    
    def __init__(self):
        xbmc.log("[IPTV3] Zainicjowano moduł CacheEngine", xbmc.LOGINFO)

    def is_expired(self, timestamp, ttl_seconds):
        """Sprawdza, czy dane w cache są już przestarzałe."""
        now = int(time.time())
        return (now - timestamp) > ttl_seconds

    def wrap_data(self, data):
        """Pakuje surowe dane w strukturę z timestampem."""
        return {
            'timestamp': int(time.time()),
            'payload': data
        }