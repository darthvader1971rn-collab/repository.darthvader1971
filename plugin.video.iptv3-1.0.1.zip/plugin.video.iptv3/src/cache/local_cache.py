# -*- coding: utf-8 -*-
import xbmc
import xbmcvfs
import json
import os

class LocalCache:
    """
    Lokalny magazyn plików cache (Local Cache).
    Zapisuje dane w formacie JSON w dedykowanym folderze tymczasowym.
    """
    
    def __init__(self):
        self.cache_dir = xbmcvfs.translatePath('special://temp/iptv3_cache/')
        if not xbmcvfs.exists(self.cache_dir):
            xbmcvfs.mkdir(self.cache_dir)

    def _get_file_path(self, key):
        """Zamienia klucz (np. nazwę kanału) na bezpieczną ścieżkę pliku."""
        return os.path.join(self.cache_dir, f"{key}.json")

    def set(self, key, data):
        """Zapisuje dane do pliku."""
        file_path = self._get_file_path(key)
        try:
            with xbmcvfs.File(file_path, 'w') as f:
                f.write(json.dumps(data))
            return True
        except Exception as e:
            xbmc.log(f"[IPTV3] LocalCache Error: {str(e)}", xbmc.LOGERROR)
            return False

    def get(self, key):
        """Pobiera dane z pliku. Jeśli nie istnieje, zwraca None."""
        file_path = self._get_file_path(key)
        if xbmcvfs.exists(file_path):
            with xbmcvfs.File(file_path, 'r') as f:
                return json.loads(f.read())
        return None