# -*- coding: utf-8 -*-
import xbmc

class SegmentCache:
    """
    Bufor segmentów wideo.
    Zarządza krótkotrwałym przechowywaniem kawałków strumienia 
    w celu zapewnienia płynności przejść między segmentami HLS/DASH.
    """
    
    def __init__(self):
        self.segments = []
        xbmc.log("[IPTV3] Zainicjowano SegmentCache", xbmc.LOGINFO)

    def add_segment(self, segment_data):
        """Dodaje segment do kolejki bufora."""
        self.segments.append(segment_data)
        if len(self.segments) > 10:  # Trzymamy max 10 ostatnich segmentów
            self.segments.pop(0)

    def clear_cache(self):
        """Czyści bufor segmentów (np. przy zmianie kanału)."""
        self.segments = []