# -*- coding: utf-8 -*-
import xbmc

class RedisManager:
    """
    Manager pamięci operacyjnej (In-Memory Cache).
    Symuluje działanie bazy Redis, przechowując dane w aktywnej pamięci RAM 
    wtyczki dla błyskawicznego dostępu.
    """
    
    def __init__(self):
        self._memory_db = {}
        xbmc.log("[IPTV3] Zainicjowano RedisManager (In-Memory)", xbmc.LOGINFO)

    def set(self, key, value):
        """Zapisuje wartość w pamięci RAM."""
        self._memory_db[key] = value
        return True

    def get(self, key):
        """Pobiera wartość z pamięci RAM."""
        return self._memory_db.get(key)

    def delete(self, key):
        """Usuwa klucz z pamięci."""
        if key in self._memory_db:
            del self._memory_db[key]

    def flush_all(self):
        """Czyści całą pamięć podręczną."""
        self._memory_db.clear()
        xbmc.log("[IPTV3] RedisManager: Pamięć RAM wyczyszczona.", xbmc.LOGDEBUG)