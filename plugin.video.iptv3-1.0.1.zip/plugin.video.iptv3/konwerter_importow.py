import os
import re
import tkinter as tk
from tkinter import filedialog, scrolledtext
import threading
from pathlib import Path

class ImportConverterApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Konwerter Importów (Kodi Plugin)")
        self.root.geometry("700x550")
        
        self.selected_dir = tk.StringVar()
        
        # Elementy interfejsu
        tk.Label(
            root, 
            text="Wybierz główny folder wtyczki (korzeń, np. plugin.video.iptv3):", 
            font=("Arial", 10, "bold")
        ).pack(pady=(15, 5), anchor=tk.W, padx=10)
        
        frame_dir = tk.Frame(root)
        frame_dir.pack(pady=5, fill=tk.X, padx=10)
        
        self.entry_dir = tk.Entry(frame_dir, textvariable=self.selected_dir, state='readonly', font=("Arial", 10))
        self.entry_dir.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        
        tk.Button(frame_dir, text="Przeglądaj...", command=self.browse_folder).pack(side=tk.RIGHT)
        
        self.btn_start = tk.Button(
            root, 
            text="Uruchom Konwersję w folderze 'src'", 
            command=self.start_conversion, 
            state=tk.DISABLED, 
            bg="#2E8B57", 
            fg="white", 
            font=("Arial", 11, "bold")
        )
        self.btn_start.pack(pady=15)
        
        tk.Label(root, text="Logi z operacji:").pack(anchor=tk.W, padx=10)
        
        self.log_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=20, bg="#F5F5F5")
        self.log_area.pack(padx=10, pady=(0, 10), fill=tk.BOTH, expand=True)
        self.log_area.config(state=tk.DISABLED)

    def browse_folder(self):
        folder = filedialog.askdirectory(title="Wybierz korzeń wtyczki")
        if folder:
            self.selected_dir.set(folder)
            self.btn_start.config(state=tk.NORMAL)
            self.log_message(f"Wybrano folder główny: {folder}")

    def log_message(self, message):
        # Aktualizacja GUI z poziomu osobnego wątku musi być delegowana przez root.after
        self.root.after(0, self._log_message_safe, message)

    def _log_message_safe(self, message):
        self.log_area.config(state=tk.NORMAL)
        self.log_area.insert(tk.END, message + "\n")
        self.log_area.see(tk.END)
        self.log_area.config(state=tk.DISABLED)

    def start_conversion(self):
        root_dir = self.selected_dir.get()
        if not root_dir:
            return
        
        self.btn_start.config(state=tk.DISABLED)
        self.log_message("-" * 50)
        self.log_message("Rozpoczynam analizę i konwersję...")
        
        # Uruchamiamy logikę w tle, żeby nie zawiesić interfejsu graficznego
        thread = threading.Thread(target=self.process_directory, args=(root_dir,))
        thread.daemon = True
        thread.start()

    def process_directory(self, root_dir_str):
        root_path = Path(root_dir_str)
        src_path = root_path / "src"
        
        if not src_path.exists() or not src_path.is_dir():
            self.log_message("BŁĄD: Nie znaleziono podfolderu 'src' we wskazanym katalogu głównym!")
            self.root.after(0, lambda: self.btn_start.config(state=tk.NORMAL))
            return
            
        py_files = list(src_path.rglob("*.py"))
        self.log_message(f"Znaleziono {len(py_files)} plików .py do przeszukania w podfolderze 'src'.")
        
        files_modified = 0
        total_imports_changed = 0
        
        # Regex wyłapujący importy względne. Tłumaczenie grup:
        # 1: białe znaki (wcięcia), 2: kropki, 3: ścieżka po kropkach (jeśli istnieje), 4: importowane obiekty
        import_pattern = re.compile(r'^(\s*)from\s+(\.+)(.*?)\s+import\s+(.*)')

        for file_path in py_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                new_lines = []
                file_changed = False
                
                # Ustalenie ścieżki względem katalogu głównego (np. src/api/auth_manager.py)
                rel_to_root = file_path.relative_to(root_path)
                parent_parts = rel_to_root.parent.parts
                
                for i, line in enumerate(lines):
                    match = import_pattern.match(line)
                    if match:
                        indent = match.group(1)
                        dots = match.group(2)
                        module_after_dots = match.group(3)
                        imports = match.group(4)
                        
                        num_dots = len(dots)
                        levels_up = num_dots - 1
                        
                        # Zabezpieczenie przed importami wychodzącymi poza korzeń wtyczki
                        if levels_up > len(parent_parts):
                            self.log_message(f"OSTRZEŻENIE: Import '{line.strip()}' w pliku {rel_to_root} wykracza poza główny folder. Pomijam ten import.")
                            new_lines.append(line)
                            continue
                            
                        # Określanie korzenia dla absolutnego importu
                        if levels_up == 0:
                            base_parts = parent_parts
                        else:
                            base_parts = parent_parts[:-levels_up]
                            
                        base_module = ".".join(base_parts)
                        
                        # Łączenie z resztą ścieżki
                        if base_module and module_after_dots:
                            full_module = f"{base_module}.{module_after_dots}"
                        elif base_module:
                            full_module = base_module
                        else:
                            full_module = module_after_dots
                            
                        # Składanie nowej linijki kodu
                        new_line = f"{indent}from {full_module} import {imports}\n"
                        
                        if line != new_line:
                            file_changed = True
                            total_imports_changed += 1
                            new_lines.append(new_line)
                            self.log_message(f"[{rel_to_root}] linia {i+1}:")
                            self.log_message(f"  - Było: {line.strip()}")
                            self.log_message(f"  + Jest: {new_line.strip()}")
                        else:
                            new_lines.append(line)
                    else:
                        new_lines.append(line)
                        
                if file_changed:
                    # Zapisujemy plik tylko w przypadku faktycznego dokonania zmian
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(new_lines)
                    files_modified += 1
                    
            except Exception as e:
                self.log_message(f"BŁĄD: Problem z przetwarzaniem pliku {file_path.name}. Szczegóły: {e}")
                
        self.log_message("-" * 50)
        self.log_message("Proces zakończony powodzeniem!")
        self.log_message(f"Zaktualizowano {total_imports_changed} importów w {files_modified} plikach.")
        self.root.after(0, lambda: self.btn_start.config(state=tk.NORMAL))

if __name__ == "__main__":
    root = tk.Tk()
    app = ImportConverterApp(root)
    root.mainloop()