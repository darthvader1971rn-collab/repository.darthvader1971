# -*- coding: utf-8 -*-
import sys
import os
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
xbmcvfs.translatePath(addon.getAddonInfo('path'))

xbmc.log("[IPTV3] main.py — START", xbmc.LOGINFO)

addon_path = os.path.dirname(os.path.abspath(__file__))
src_path = os.path.join(addon_path, "src")

if src_path not in sys.path:
    sys.path.append(src_path)

try:
    from core.main_engine import MainEngine
    from ui.live_tv_window import LiveTVWindow
    from ui.channel_editor_window import ChannelEditorWindow
except Exception as e:
    xbmc.log(f"[IPTV3] Błąd importu modułów: {e}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok("IPTV 3.0", "Błąd inicjalizacji silnika lub interfejsu.")
    raise

def parse_params():
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    query = sys.argv[2][1:]
    return dict(urllib.parse.parse_qsl(query))

# ---------------------------------------------------------
# MENU GŁÓWNE
# ---------------------------------------------------------
def show_main_menu():
    handle = int(sys.argv[1])
    addon = xbmcaddon.Addon()

    items = [
        (addon.getLocalizedString(30100), "live_tv"),
        (addon.getLocalizedString(30101), "vod"),
        (addon.getLocalizedString(30102), "favorites"),
        (addon.getLocalizedString(30110), "epg"),
        (addon.getLocalizedString(30120), "catchup"),
        (addon.getLocalizedString(30130), "recordings"),
    ]

    for label, action in items:
        li = xbmcgui.ListItem(label=label or f"[{action}]")
        url = f"{sys.argv[0]}?action={action}"
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

# ---------------------------------------------------------
# LIVE TV - NOWE OKNO XML
# ---------------------------------------------------------
def show_live_tv(engine):
    handle = int(sys.argv[1])
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    
    while True:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        ui_window = LiveTVWindow("LiveTV.xml", addon_path, "Default", "720p")
        ui_window.engine = engine
        ui_window.doModal()
        
        if hasattr(engine, 'playing_channel_id') and engine.playing_channel_id:
            while engine.player.isPlaying() or engine.player.is_active:
                xbmc.sleep(500)
            engine.playing_channel_id = None
            del ui_window
        else:
            del ui_window
            break

    xbmcplugin.endOfDirectory(handle, succeeded=False)

# ---------------------------------------------------------
# VOD – LOGIKA FILTROWANIA TWOJEJ LISTY
# ---------------------------------------------------------
def show_vod(engine):
    handle = int(sys.argv[1])
    try:
        # Przeszukujemy Twoją listę 21k pozycji pod kątem filmów
        query = """
            SELECT DISTINCT group_name FROM channels 
            WHERE stream_url LIKE '%.mp4%' 
               OR stream_url LIKE '%.mkv%' 
            ORDER BY group_name ASC
        """
        rows = engine.db.fetch_all(query)
        if not rows:
            xbmcgui.Dialog().notification("VOD", "Brak filmów w obecnej liście.")
            xbmcplugin.endOfDirectory(handle); return

        for row in rows:
            group = row["group_name"] or "Inne filmy"
            li = xbmcgui.ListItem(label=group)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            url = f"{sys.argv[0]}?action=vod_list&group={urllib.parse.quote(group)}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    except Exception as e:
        xbmc.log(f"[IPTV3] Błąd VOD: {e}", xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(handle)

def show_vod_list(engine, group):
    handle = int(sys.argv[1])
    group_name = urllib.parse.unquote(group)
    
    query = "SELECT * FROM channels WHERE group_name = ? AND is_vod = 1 ORDER BY name ASC"
    rows = engine.db.fetch_all(query, (group_name,))

    for row in rows:
        name = row["name"]
        li = xbmcgui.ListItem(label=name)
        
        provider_logo = row["logo"] or ""
        icon = provider_logo or "DefaultVideo.png"
        poster = provider_logo or "DefaultVideo.png"
        fanart = icon
        plot = "Film VOD"
        
        # BARDZO WAŻNE: use_network=False gwarantuje, że Kodi nigdy nie zamarznie!
        tmdb_data = engine.tmdb.get_movie_info(name, use_network=False)
        
        if tmdb_data:
            name = tmdb_data.get('title', name)
            plot = tmdb_data.get('plot', plot)
            
            if not provider_logo and tmdb_data.get('poster'):
                poster = tmdb_data['poster']
                icon = poster
                
            if tmdb_data.get('fanart'):
                fanart = tmdb_data['fanart']
                
            rating = tmdb_data.get('rating', 0.0)
            year = tmdb_data.get('year', '')
            
            li.setInfo("video", {
                "title": name, 
                "plot": plot,
                "rating": float(rating) if rating else 0.0,
                "year": int(year) if year and year.isdigit() else 0
            })
        else:
            li.setInfo("video", {"title": name, "plot": plot})

        li.setArt({
            'icon': icon, 
            'thumb': poster,
            'poster': poster,
            'fanart': fanart,
            'landscape': fanart
        })
        
        url = f"{sys.argv[0]}?action=play&channel_id={row['channel_id']}"
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def show_favorites(engine):
    show_epg_list(engine, sort_by="m3u", favorites_only=True)

# ---------------------------------------------------------
# LOGIKA SORTOWANIA (EPG)
# ---------------------------------------------------------
def show_epg(engine):
    addon = xbmcaddon.Addon()
    try: sort_setting = int(addon.getSetting("default_sort") or "0")
    except: sort_setting = 0
    
    if sort_setting == 0: show_epg_list(engine, sort_by="name")
    elif sort_setting == 1: show_epg_list(engine, sort_by="m3u")
    elif sort_setting == 2: show_epg_groups(engine)
    elif sort_setting == 3: show_epg_list(engine, sort_by="name", favorites_only=True)
    else: show_epg_list(engine, sort_by="name")

def show_epg_groups(engine):
    handle = int(sys.argv[1])
    try:
        rows = engine.db.fetch_all("SELECT DISTINCT group_name FROM channels ORDER BY group_name ASC")
        for row in rows:
            group = row["group_name"] or "Inne"
            li = xbmcgui.ListItem(label=group)
            url = f"{sys.argv[0]}?action=epg_list&group={urllib.parse.quote(group)}&sort=m3u"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    except: pass
    xbmcplugin.endOfDirectory(handle)

# ---------------------------------------------------------
# EPG – LISTA KANAŁÓW
# ---------------------------------------------------------
def show_epg_list(engine, sort_by="name", group=None, favorites_only=False):
    handle = int(sys.argv[1])
    query = "SELECT * FROM channels"
    params_sql = []
    conditions = []

    if group:
        conditions.append("group_name = ?")
        params_sql.append(urllib.parse.unquote(group))
    if favorites_only:
        conditions.append("is_favorite = 1")
    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    if favorites_only: query += " ORDER BY fav_sort_index ASC"
    elif sort_by == "m3u": query += " ORDER BY sort_index ASC"
    else: query += " ORDER BY name ASC"

    try:
        rows = engine.db.fetch_all(query, tuple(params_sql))
    except Exception as e:
        xbmc.log(f"[IPTV3] Błąd DB: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle); return

    now = int(time.time())

    for raw_ch in rows:
        ch = dict(raw_ch)
        name = ch.get("name", "Nieznany")
        current_title = "Brak danych"
        current_plot = ""
        current_image = ""  # Dodane: zmienna na grafikę audycji z EPG
        
        matched_id = engine.epg.match_epg_id(name=name, tvg_name=ch.get("tvg_name", ""), tvg_id=ch.get("tvg_id", ""))

        if matched_id:
            progs = engine.epg.get_programs_for_channel(matched_id)
            for p in progs:
                if p.get("start_time", 0) <= now <= p.get("end_time", 0):
                    current_title = p.get("title", "Brak tytułu")
                    current_plot = p.get("description", "")
                    current_image = p.get("image", "")  # Wyciąganie obrazka z ramówki
                    break

        li = xbmcgui.ListItem(label=f"{name} • {current_title}")
        li.setInfo('video', {'title': current_title, 'plot': current_plot})
        
        channel_logo = ch.get("logo") or ""
        
        # --- ROZDZIELENIE GRAFIK ---
        # icon / thumb: wymuszamy logo kanału (by na liście twardo siedział picon)
        # poster / fanart / landscape: grafika EPG (dla dużego panelu bocznego z detalami)
        li.setArt({
            'icon': channel_logo,
            'thumb': channel_logo,
            'poster': current_image if current_image else channel_logo,
            'fanart': current_image if current_image else channel_logo,
            'landscape': current_image if current_image else channel_logo
        })
        
        li.addContextMenuItems([
            ("▶ Odtwórz kanał", f"RunPlugin({sys.argv[0]}?action=play&channel_id={ch['channel_id']})"),
            ("⭐ Dodaj/Usuń Ulubione", f"RunPlugin({sys.argv[0]}?action=toggle_fav&channel_id={ch['channel_id']})")
        ])
        url = f"{sys.argv[0]}?action=epg_channel&channel_id={ch['channel_id']}"
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

# ---------------------------------------------------------
# EPG – SZCZEGÓŁY KANAŁU
# ---------------------------------------------------------
def show_epg_channel(engine, channel_id):
    handle = int(sys.argv[1])
    try:
        rows = engine.db.fetch_all("SELECT * FROM channels WHERE channel_id = ?", (channel_id,))
        if not rows: xbmcplugin.endOfDirectory(handle); return
        ch_row = dict(rows[0])
        matched_id = engine.epg.match_epg_id(name=ch_row.get("name"), tvg_name=ch_row.get("tvg_name"), tvg_id=ch_row.get("tvg_id"))
        if not matched_id: xbmcplugin.endOfDirectory(handle); return

        channel_programs = engine.epg.get_programs_for_channel(matched_id)
        now_time = int(time.time())
        
        # Pobieramy logo kanału
        channel_logo = ch_row.get("logo", "")

        for p in channel_programs:
            st, en = int(p.get("start_time", 0)), int(p.get("end_time", 0))
            title = p.get('title', 'Brak tytułu')
            start_str = time.strftime("%d.%m %H:%M", time.localtime(st))
            li = xbmcgui.ListItem(label=f"{start_str}  •  {title}")
            li.setInfo("video", {"title": title, "plot": p.get('description', '')})
            
            # --- ROZDZIELENIE GRAFIK ---
            program_image = p.get("image", "")
            
            li.setArt({
                'icon': channel_logo,
                'thumb': channel_logo,
                'poster': program_image if program_image else channel_logo,
                'fanart': program_image if program_image else channel_logo,
                'landscape': program_image if program_image else channel_logo
            })
            
            if en < now_time and en > 0:
                url = f"{sys.argv[0]}?action=play_catchup&channel_id={channel_id}&start={st}&end={en}&title={urllib.parse.quote_plus(title)}"
            else:
                url = f"{sys.argv[0]}?action=play&channel_id={channel_id}"
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    except: pass
    xbmcplugin.endOfDirectory(handle)

# ---------------------------------------------------------
# CATCHUP – ODTWARZANIE (NAPRAWIONE DLA HLS I NAGŁÓWKÓW)
# ---------------------------------------------------------
def play_catchup(engine, channel_id, start_time, end_time=None, title="Brak tytułu", desc=""):
    """
    Buduje playlistę dla archiwum z poprawnymi nagłówkami, łącznikami URL
    oraz pełnymi metadanymi (opisy i grafiki z EPG).
    """
    start_ts = int(start_time)
    # Domyślnie 3-godzinne bloki, jeśli brak czasu zakończenia
    actual_end_ts = min(int(end_time or start_ts + 10800), int(time.time()))
    
    # Zmieniono zapytanie na SELECT *, aby pobrać tvg_id i tvg_name potrzebne do EPG
    rows = engine.db.fetch_all("SELECT * FROM channels WHERE channel_id = ?", (channel_id,))
    if not rows:
        return

    ch_row = dict(rows[0])
    base_url = ch_row.get('stream_url')
    channel_logo = ch_row.get('logo') or ""

    # --- WYSZUKIWANIE METADANYCH Z EPG ---
    current_plot = desc
    current_image = ""
    
    matched_id = engine.epg.match_epg_id(name=ch_row.get("name"), tvg_name=ch_row.get("tvg_name"), tvg_id=ch_row.get("tvg_id"))
    
    if matched_id:
        channel_programs = engine.epg.get_programs_for_channel(matched_id)
        for p in channel_programs:
            # Szukamy audycji po czasie startu
            if p.get("start_time", 0) <= start_ts < p.get("end_time", 0) or p.get("start_time", 0) == start_ts:
                current_plot = p.get("description", desc)
                current_image = p.get("image", "")
                title = p.get("title", title)  # Upewniamy się, że tytuł jest dokładny
                break

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    # Rozdzielamy URL od starych nagłówków
    clean_url = str(base_url).split('|')[0]
    
    # INTELIGENTNY ŁĄCZNIK: Sprawdzamy czy w URL jest już '?'
    connector = "&" if "?" in clean_url else "?"
    
    # POBIERANIE NAGŁÓWKÓW Z SILNIKA (UA + Referer)
    ua = getattr(engine, 'user_agent', 'TiviMate/4.7.0 (Linux; Android 11)')
    parsed_host = urllib.parse.urlparse(clean_url)
    host_url = f"{parsed_host.scheme}://{parsed_host.netloc}/"
    
    # Budowa pancernego nagłówka dla archiwum
    headers = f"|User-Agent={urllib.parse.quote(ua)}&Referer={urllib.parse.quote(host_url)}&verify=false"

    current_utc = start_ts
    interval = 3600 # 1h bloki

    while current_utc < actual_end_ts:
        block_end = min(current_utc + interval, actual_end_ts)
        
        # Tworzenie finalnego adresu bloku archiwum
        block_url = f"{clean_url}{connector}utc={current_utc}&lutc={block_end}{headers}"
        
        li = xbmcgui.ListItem(label=f"{title} (Archiwum)")
        
        # --- ROZDZIELENIE GRAFIK (OSD) ---
        li.setArt({
            'icon': channel_logo,
            'thumb': channel_logo,
            'poster': current_image if current_image else channel_logo,
            'fanart': current_image if current_image else channel_logo,
            'landscape': current_image if current_image else channel_logo
        })
        
        # --- WSTRZYKNIĘCIE OPISU DO OSD ---
        li.setInfo('video', {'title': title, 'plot': current_plot})
        
        # WYMUSZENIE FFMPEG DLA ARCHIWUM (Rozwiązuje błąd 406 i SSL)
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('inputstream.ffmpegdirect.is_continuous', 'true')
        
        playlist.add(url=block_url, listitem=li)
        current_utc += interval

    xbmc.Player().play(playlist)

# ---------------------------------------------------------
# GŁÓWNA LOGIKA
# ---------------------------------------------------------
def main():
    handle = int(sys.argv[1])
    params = parse_params()
    action = params.get("action")

    # 1. SZYBKIE ŁADOWANIE MENU (Odblokowuje Kodi na starcie - start w milisekundę)
    if not action:
        xbmc.log("[IPTV3] Szybkie ładowanie menu głównego.", xbmc.LOGINFO)
        show_main_menu()
        return

    # 2. ŁADOWANIE SILNIKA TYLKO DLA KONKRETNYCH AKCJI
    try:
        engine = MainEngine()
        if action != "update_epg":
            if not engine.startup():
                xbmc.log("[IPTV3] Startup bazy przerwany lub z błędem.", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[IPTV3] Krytyczny błąd MainEngine: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # 3. KIEROWANIE RUCHEM
    try:
        if action == "live_tv": show_live_tv(engine)
        elif action == "vod": show_vod(engine)
        elif action == "vod_list": show_vod_list(engine, params.get("group"))
        elif action == "favorites": show_favorites(engine)
        elif action == "epg": show_epg(engine)
        elif action == "epg_list":
            show_epg_list(engine, sort_by=params.get("sort", "name"), group=params.get("group"), favorites_only=(params.get("favs")=="1"))
        elif action == "epg_channel": show_epg_channel(engine, params.get("channel_id"))
        elif action == "play": engine.play_channel(params.get("channel_id"))
        elif action == "catchup": 
            rows = engine.db.fetch_all("SELECT * FROM channels WHERE tvg_id != '' ORDER BY sort_index ASC")
            for row in rows:
                li = xbmcgui.ListItem(label=row["name"])
                li.setArt({'icon': row["logo"], 'thumb': row["logo"]})
                url = f"{sys.argv[0]}?action=catchup_list&channel_id={row['channel_id']}"
                xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(handle)
        elif action == "catchup_list":
            now = int(time.time())
            rows = engine.db.fetch_all("SELECT * FROM channels WHERE channel_id = ?", (params.get("channel_id"),))
            if rows:
                ch_row = dict(rows[0])
                matched_id = engine.epg.match_epg_id(name=ch_row.get("name"), tvg_name=ch_row.get("tvg_name"), tvg_id=ch_row.get("tvg_id"))
                if matched_id:
                    progs = engine.epg.get_programs_for_channel(matched_id)
                    for p in [x for x in progs if x.get("end_time", 0) < now][::-1][:50]:
                        st, en = int(p.get("start_time", 0)), int(p.get("end_time", 0))
                        label = f"{time.strftime('%d.%m %H:%M', time.localtime(st))} • {p.get('title')}"
                        li = xbmcgui.ListItem(label=label)
                        url = f"{sys.argv[0]}?action=play_catchup&channel_id={ch_row['channel_id']}&start={st}&end={en}&title={urllib.parse.quote_plus(p.get('title', ''))}"
                        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
            xbmcplugin.endOfDirectory(handle)
        elif action == "play_catchup":
            play_catchup(engine, params.get("channel_id"), params.get("start"), params.get("end"), urllib.parse.unquote_plus(params.get("title", "Archiwum")))
        elif action == "toggle_fav":
            cid = params.get("channel_id")
            res = engine.db.fetch_all("SELECT is_favorite FROM channels WHERE channel_id = ?", (cid,))
            if res:
                new_st = 0 if res[0]['is_favorite'] == 1 else 1
                engine.db.execute_query("UPDATE channels SET is_favorite = ?, fav_sort_index = 0 WHERE channel_id = ?", (new_st, cid))
                xbmc.executebuiltin("Container.Refresh")
        elif action == "recordings":
            xbmcgui.Dialog().notification("IPTV 3.0", "W przygotowaniu", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(handle)
        elif action == "update_epg":
            engine.force_update()
        else: 
            show_main_menu()
    except Exception as e:
        xbmc.log(f"[IPTV3] Błąd wykonania akcji {action}: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

# --- TE DWIE LINIJKI SĄ KLUCZOWE DLA URUCHOMIENIA WTYCZKI ---
if __name__ == "__main__":
    main()