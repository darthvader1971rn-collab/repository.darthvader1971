# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import time

class LiveTVWindow(xbmcgui.WindowXML):
    """
    Niestandardowe okno dla telewizji na żywo (Live TV).
    Łączy plik LiveTV.xml z silnikiem wtyczki (MainEngine).
    """

    def __init__(self, *args, **kwargs):
        super(LiveTVWindow, self).__init__(*args, **kwargs)
        self.engine = None
        self.list_control = None
        self.epg_list = None

    def onInit(self):
        """Metoda wywoływana automatycznie po załadowaniu okna."""
        xbmc.log("[IPTV3] LiveTVWindow: Otwieranie okna...", xbmc.LOGINFO)
        
        # Pobieramy uchwyty do naszych list z pliku XML
        self.list_control = self.getControl(1000) # Lewa strona (Kanały)
        self.epg_list = self.getControl(2000)     # Prawa strona (Programy)
        
        # Ładujemy kanały do lewej listy
        self.populate_channels()
        
        # Od razu ładujemy EPG dla pierwszego podświetlonego kanału
        self.load_epg_for_channel()

        # --- ZŁOTY ŚRODEK NA ZAMROŻENIE ANDROIDA ---
        # Wymuszamy, aby Kodi "złapało" lewą listę kanałów pilotem PO załadowaniu danych.
        # Bez tego pilot na Android TV nie reaguje na żadne kliknięcia.
        try:
            self.setFocusId(1000)
        except Exception as e:
            xbmc.log(f"[IPTV3] Błąd ustawiania focusu: {e}", xbmc.LOGERROR)

    def populate_channels(self):
        """Pobiera kanały z bazy i wrzuca do ListControl, ukrywając VOD i uwzględniając sortowanie."""
        addon = xbmcaddon.Addon()
        
        # 1. Odczytujemy wybraną opcję sortowania z ustawień
        try:
            sort_setting = int(addon.getSetting("default_sort") or "0")
        except ValueError:
            sort_setting = 0

        # 2. Budujemy zapytanie SQL na podstawie ustawienia
        query = "SELECT * FROM channels"
        
        # Zawsze filtrujemy VOD (chcemy tylko czyste kanały TV)
        conditions = ["is_vod = 0"]

        # Filtr ulubionych (Opcja 3)
        if sort_setting == 3: 
            conditions.append("is_favorite = 1")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # Logika kolejności (zabezpieczona)
        if sort_setting == 3: # Tylko ulubione
            query += " ORDER BY name ASC"  # Usunięto fav_sort_index dla bezpieczeństwa
        elif sort_setting == 1: # Kolejność dostawcy (M3U)
            query += " ORDER BY sort_index ASC"
        elif sort_setting == 2: # Kategorie (Grupy)
            query += " ORDER BY group_name ASC, sort_index ASC"
        else: # Alfabetycznie
            query += " ORDER BY name ASC"

        try:
            rows = self.engine.db.fetch_all(query)
            
            for raw_row in rows:
                row = dict(raw_row)
                name = row.get("name", "Brak nazwy")
                li = xbmcgui.ListItem(label=name)
                
                li.setProperty("channel_id", str(row.get("channel_id", "")))
                li.setProperty("tvg_name", row.get("tvg_name", ""))
                li.setProperty("tvg_id", row.get("tvg_id", ""))
                li.setProperty("stream_url", row.get("stream_url", ""))
                
                logo_url = row.get("logo") or row.get("tvg_logo") or row.get("tvg-logo") or ""
                
                if logo_url:
                    li.setArt({'icon': logo_url, 'thumb': logo_url})
                
                self.list_control.addItem(li)
                
        except Exception as e:
            import xbmc
            xbmc.log(f"[IPTV3] LiveTVWindow: Błąd ładowania kanałów: {e}", xbmc.LOGERROR)

        # --- PRZYWRACANIE KURSORA PO ZATRZYMANIU WIDEO ---
        # Sprawdzamy, czy w silniku jest zapisany ostatni kanał
        last_channel = getattr(self.engine, 'last_focused_channel', None)
        if last_channel and self.list_control.size() > 0:
            # Przeszukujemy listę w poszukiwaniu zapisanego ID
            for i in range(self.list_control.size()):
                item = self.list_control.getListItem(i)
                if item.getProperty("channel_id") == last_channel:
                    # Znaleziono! Wymuszamy zaznaczenie tego elementu
                    self.list_control.selectItem(i)
                    break

    def onAction(self, action):
        """Nasłuchiwanie naciśnięć klawiszy na pilocie/klawiaturze."""
        action_id = action.getId()
        
        # Akcje powrotu (klawisz Back, Escape) -> zamykamy okno
        if action_id in (9, 10, 92):
            self.close()
            
        # Akcje nawigacji po liście (Góra: 3, Dół: 4, PageUp: 7, PageDown: 8, Lewo: 1, Prawo: 2)
        elif action_id in (1, 2, 3, 4, 7, 8):
            # Czekamy minimalną chwilę, aby Kodi zdążyło przenieść "focus" na nowy element
            xbmc.sleep(50)
            focused_id = self.getFocusId()
            
            if focused_id == 1000:
                # Nawigacja po kanałach (lewa lista) -> ładujemy nową ramówkę po prawej
                self.load_epg_for_channel()
            elif focused_id == 2000:
                # Nawigacja wewnątrz ramówki (prawa lista) -> odświeżamy tylko górny opis
                self.update_details_panel()

    def onClick(self, controlId):
        """Obsługa kliknięcia (Zatwierdzenie/OK)."""
        if controlId == 1000:
            selected_item = self.list_control.getSelectedItem()
            if selected_item:
                channel_id = selected_item.getProperty("channel_id")
                
                # ZAPISUJEMY STAN PRZED WYJŚCIEM
                self.engine.last_focused_channel = channel_id  # Do przywrócenia kursora
                self.engine.playing_channel_id = channel_id    # Do pętli w main.py
                
                # Zamykamy okno i uruchamiamy wideo
                self.close()
                self.engine.play_channel(channel_id)
                
        elif controlId == 2000:
            # OBSŁUGA KLIKNIĘCIA W ARCHIWUM (CATCHUP)
            selected_epg = self.epg_list.getSelectedItem()
            selected_channel = self.list_control.getSelectedItem()
            
            if selected_epg and selected_channel:
                channel_id = selected_channel.getProperty("channel_id")
                title = selected_epg.getLabel()
                
                # Szukamy tego programu w bazie EPG, by poznać jego dokładny czas startu
                rows = self.engine.db.fetch_all(
                    "SELECT start_time FROM epg_programs WHERE channel_id = ? AND title = ? ORDER BY start_time ASC LIMIT 1", 
                    (channel_id, title)
                )
                
                if rows:
                    start_str = rows[0]['start_time']
                    from datetime import datetime
                    import time
                    import xbmc
                    import xbmcgui
                    
                    try:
                        # Zamiana tekstu z bazy na UNIX timestamp
                        dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
                        start_unix = int(time.mktime(dt.timetuple()))
                    except Exception as e:
                        xbmc.log(f"[IPTV3] Błąd konwersji czasu: {e}", xbmc.LOGERROR)
                        start_unix = 0
                        
                    if start_unix > 0:
                        xbmc.log(f"[IPTV3] Kliknięto archiwum: Kanał={channel_id}, Program={title}, Start={start_unix}", xbmc.LOGINFO)
                        
                        # Pobieramy dane kanału (link i flagę catchup)
                        ch_rows = self.engine.db.fetch_all("SELECT url, name, is_catchup FROM channels WHERE channel_id = ?", (channel_id,))
                        if ch_rows:
                            is_catchup = ch_rows[0]['is_catchup']
                            
                            if is_catchup == 1:
                                base_url = ch_rows[0]['url']
                                ch_name = ch_rows[0]['name']
                                
                                # Generujemy link przez lokalne Proxy
                                from src.catchup.catchup_proxy import CatchupProxy
                                proxy_url = CatchupProxy().get_proxy_url(base_url, start_unix)
                                
                                li = xbmcgui.ListItem(label=f"[ARCHIWUM] {ch_name} - {title}")
                                li.setInfo("video", {"title": f"Archiwum: {title}"})
                                
                                xbmc.log(f"[IPTV3] Przekazanie do Proxy URL: {proxy_url}", xbmc.LOGINFO)
                                
                                # Zamykamy okno i uruchamiamy wideo z przeszłości (domyślny odtwarzacz Kodi)
                                self.close()
                                xbmc.Player().play(proxy_url, li)
                            else:
                                import xbmcgui
                                xbmcgui.Dialog().notification("Archiwum", "Ten kanał nie posiada archiwum.", xbmcgui.NOTIFICATION_WARNING)
                        else:
                            import xbmc
                            xbmc.log("[IPTV3] Nie znaleziono kanału w bazie dla archiwum.", xbmc.LOGERROR)
                else:
                    import xbmc
                    import xbmcgui
                    xbmc.log("[IPTV3] Nie znaleziono czasu startu dla tego programu.", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Błąd", "Brak dokładnego czasu w EPG", xbmcgui.NOTIFICATION_ERROR)

    def load_epg_for_channel(self):
        """Ładuje listę programów do dolnego panelu po prawej stronie po najechaniu na kanał."""
        if not self.list_control or not self.epg_list:
            return
            
        selected_item = self.list_control.getSelectedItem()
        if not selected_item:
            return

        self.epg_list.reset()

        name = selected_item.getLabel()
        tvg_name = selected_item.getProperty("tvg_name")
        tvg_id = selected_item.getProperty("tvg_id")

        matched_epg_id = self.engine.epg.match_epg_id(name=name, tvg_name=tvg_name, tvg_id=tvg_id)
        
        if matched_epg_id:
            now = int(time.time())
            all_progs = self.engine.epg.get_programs_for_channel(matched_epg_id)
            
            for p in all_progs:
                p_end = p.get("end_time", 0)
                
                if p_end > now:
                    p_start = p.get("start_time", 0)
                    title = p.get("title", "Brak tytułu")
                    desc = p.get("description", "Nie znaleziono opisu dla tego programu.")
                    image_url = p.get("image", "") # POBIERAMY OBRAZEK
                    
                    start_str = time.strftime("%H:%M", time.localtime(p_start)) if p_start else ""
                    end_str = time.strftime("%H:%M", time.localtime(p_end)) if p_end else ""
                    time_str = f"{start_str} - {end_str}"
                    
                    li = xbmcgui.ListItem(label=title)
                    li.setProperty("TimeStr", time_str)
                    li.setProperty("Plot", desc)
                    
                    # Wrzucamy grafikę do ListItemu EPG
                    if image_url:
                        li.setArt({'icon': image_url, 'thumb': image_url})
                    
                    self.epg_list.addItem(li)

        self.update_details_panel()

    def update_details_panel(self):
        """Wyciąga dane z podświetlonego elementu na PRAWEJ liście i wrzuca do panelu wyżej."""
        title = "Brak danych EPG"
        time_str = ""
        desc = "Nie znaleziono opisu dla tego programu."
        image_url = ""

        if self.epg_list.size() > 0:
            selected_epg = self.epg_list.getSelectedItem()
            if selected_epg:
                title = selected_epg.getLabel()
                time_str = selected_epg.getProperty("TimeStr")
                desc = selected_epg.getProperty("Plot")
                image_url = selected_epg.getArt("icon") or "" # POBIERAMY Z LISTY
        
        self.getControl(2001).setLabel(title)
        self.getControl(2002).setLabel(time_str)
        self.getControl(2003).setText(desc)
        
        # Wysłanie grafiki do nowej kontrolki z obrazkiem (ID: 2005)
        try:
            # Jeśli url jest pusty, wpadnie fallback zdefiniowany w XML
            self.getControl(2005).setImage(image_url) 
        except Exception:
            pass